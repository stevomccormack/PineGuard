# .NET fixtures

The semantic contract is [shared/fixtures.md](../../shared/fixtures.md). This file owns its C# representation.

## File responsibilities

```text
Fixtures/RangeFixture.cs       named inputs and VIBE scenarios
TestData/RangeTestData.cs      Expected/Case adaptation and native rows
RangeTests.cs                 subject invocation and assertions
```

Share neutral fixtures when contracts reuse the inputs. Keep expected-result types specific to the contract: a boolean predicate, returned object, state transition and thrown error are not all one `IsValid` outcome. Records should describe the assertion completely without computing it.

Use immutable records for scalar case data and factory methods for mutable inputs. `static readonly` does not make a list or mock immutable. Do not construct a shared subject or real provider in static TestData initialization.

Use `nameof` for named fixture values; include the operation or VIBE group when needed to make IDs unique. Group rows by operation and VIBE focus, with nonempty rollups only. Boundary and edge classifications can apply to valid or invalid inputs. Document non-applicable categories instead of empty enumerables.

Use compiler-supported current syntax for the target compiler. A .NET 8 project may use a newer installed SDK but still have an explicitly limited language version; verify before using features.

## Framework boundary

- NUnit: keep typed Case records and adapt them to `TestCaseData<TCase>` where supported by the installed stable release.
- xUnit: use `TheoryData<...>` always. Case records may be flattened to serializable typed scalar columns for robust row discovery, or use documented custom serialization. Do not suppress discovery/analyzer problems to preserve a preferred shape.
- Both: fixture input definitions and expectation values remain the same. Framework attributes and assertion APIs stay in their own adapters.

See [examples.md](examples.md) for the fixture-to-case-to-framework pattern. Expected values come from a stated contract, not the production calculation.
