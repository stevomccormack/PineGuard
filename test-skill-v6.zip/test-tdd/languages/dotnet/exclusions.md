# .NET exclusions

The decision policy is [shared/exclusions.md](../../shared/exclusions.md). This file owns .NET-specific mechanisms only.

The standard attribute is `System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverageAttribute`, normally written `[ExcludeFromCodeCoverage]`. A class-level attribute excludes its members and can hide future handwritten logic. Use only the narrowest justified scope, and verify the target framework supports the chosen attribute target and `Justification` property.

`[IgnoreCoverage]` is not a universal standard. Locate any project-specific definition and verify that the actual collector recognizes it. A compiling custom attribute can have no effect on coverage.

Coverlet and dotCover use different filter capabilities. Read their adapters before translating configuration. An exclusion in production source can affect other suites' reports, while a selected-scope report can leave overall instrumentation intact.

Do not blanket-exclude `CompilerGeneratedAttribute`: async/iterator state machines may represent handwritten behaviour. A verified generated regex implementation may warrant a narrow generated-type/file exclusion, while its public wrapper and declared pattern contract remain tested.

Reference: [ExcludeFromCodeCoverageAttribute](https://learn.microsoft.com/en-us/dotnet/api/system.diagnostics.codeanalysis.excludefromcodecoverageattribute).
