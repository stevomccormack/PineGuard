# API projects

This file owns application in APIs, including a solution with only API and model projects. Project count is not a testability verdict. Work within current boundaries and avoid unrelated architecture changes.

## Inspect behaviour, not folders

| Code encountered | Local test opportunity | Separate boundary evidence |
|---|---|---|
| Controller / endpoint | Explicit guards, local transformations, result decisions | Routing, binding, filters, middleware, serialized response |
| Model | Validation methods, calculations, state transitions | ORM mapping and serialization contract |
| Validator | Actual rule invocation with supplied rules | Whether the request pipeline invokes it |
| Repository | Extracted/in-memory calculations over materialized data | Query translation, transactions, constraints |
| Middleware | Accessible pure helper decisions | Pipeline order, exception handling as hosted |
| DI setup | Rare embedded local calculations | Real container setup and representative resolution/scopes |
| Authorization | Pure predicate with approved policy | Authentication, claims mapping, pipeline enforcement |
| HTTP adapter | Pure request/response transformation | Transport, real serialization settings, contract compatibility |

Calling a controller method directly bypasses ASP.NET Core's request pipeline. It cannot prove `[ApiController]` validation, authorization attributes, HTTP status serialization, model binding, or middleware. Returning a `BadRequest` object proves that local branch only.

## A mixed method

For an endpoint that validates an ID, loads an entity, calculates a price and saves:

1. Test an explicit early ID guard directly if no infrastructure is executed.
2. If loading uses an existing simple abstraction, supply a known entity and assess whether the calculation/result can be tested without scripting orchestration.
3. If the method directly invokes EF queries, do not create fake query semantics to reach the calculation.
4. If a small behaviour-preserving extraction of the calculation fits a requested implementation/refactor task, keep it in the same project and test it. No new domain project or repository layer is necessary.
5. In tests-only work, prefer existing seams; describe an optional extraction rather than changing production structure solely to increase coverage.
6. Record database and transaction behaviour for integration testing. Retain the method's mixed coverage residual under [coverage.md](../../shared/coverage.md).

Do not move logic or introduce an interface solely because the current code is called a controller. Do not test private helpers with reflection or bypass constructors with uninitialized objects.

## Specific traps

- `IQueryable` enumeration may execute provider logic later. Materialized `IEnumerable` does not prove query translation.
- EF's in-memory provider and SQLite substitutes do not establish behaviour of another database engine. Test provider-sensitive behaviour against the relevant engine in an isolated test environment. [EF testing guidance](https://learn.microsoft.com/en-us/ef/core/testing/choosing-a-testing-strategy)
- A DTO with auto-properties is usually trivial. A DTO with computed totals or custom conversion has logic; do not exclude the entire model project.
- A serialization round-trip can miss incorrect field names on both sides. Wire-format contracts need accepted examples and real serializer configuration.
- An options object passed directly tests a consumer's decision; it does not test configuration binding or startup validation.
- Resolving one service from a container does not validate every conditional registration, open generic, scope or environment. Record representative composition scenarios.
- Business BDD ownership does not automatically cover composition or provider compatibility. Record the appropriate test type without prescribing a new organizational owner.
