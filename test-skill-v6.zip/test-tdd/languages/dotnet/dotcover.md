# dotCover

Collection mechanics and metric limitations are owned by [test:coverage dotCover](../../../test-coverage/languages/dotnet/dotcover.md). Test eligibility and denominator policy remain in [coverage](../../shared/coverage.md). Statement coverage cannot establish branch coverage.
