# .NET examples

These documentation patterns show the same fixture concept in NUnit and xUnit. Adapt names and versions to the repository; execution validation remains a separate implementation milestone in [PLAN.md](../../PLAN.md).

Accepted contract for this example: `RangeRule.Contains(value, min, max)` returns true inside inclusive bounds and false outside. Reversed bounds throw the independently specified error; add a separate error case source in a complete suite. No production implementation is included here to avoid deriving the oracle from it.

## Neutral fixture inputs

```csharp
public sealed record RangeInput(int Value, int Min, int Max);

public static class RangeFixture
{
    public static RangeInput Ordinary => new(5, 0, 10);
    public static RangeInput AtMinimum => new(0, 0, 10);
    public static RangeInput BelowMinimum => new(-1, 0, 10);
    public static RangeInput SingleValue => new(4, 4, 4);
}

public sealed record RangeExpected(bool Accepted);
public sealed record RangeCase(string Id, RangeInput Input, RangeExpected Expected);
```

Keep `RangeFixture.cs` separate from each suite's `RangeTestData.cs` and `RangeTests.cs`. The scalar input record is immutable; a fixture with mutable collections would need fresh construction for each test. Full VIBE inventory must also consider upper boundaries, invalid bounds and other contract-relevant cases.

## NUnit TestData and test

Use a current stable NUnit release supporting generic `TestCaseData<T>`. This example presents three cases; a real suite completes the approved VIBE inventory.

```csharp
using NUnit.Framework;
using F = RangeFixture;

public static class RangeTestData
{
    public static IEnumerable<TestCaseData<RangeCase>> Cases
    {
        get
        {
            var ordinary = new TestCaseData<RangeCase>(new(
                nameof(F.Ordinary), F.Ordinary, new(true)));
            ordinary.SetName("Range.Valid.Ordinary").SetCategory("VIBE.Valid");
            yield return ordinary;

            var atMinimum = new TestCaseData<RangeCase>(new(
                nameof(F.AtMinimum), F.AtMinimum, new(true)));
            atMinimum.SetName("Range.Valid.Boundary.AtMinimum")
                .SetCategory("VIBE.Valid").SetCategory("VIBE.Boundary");
            yield return atMinimum;

            var belowMinimum = new TestCaseData<RangeCase>(new(
                nameof(F.BelowMinimum), F.BelowMinimum, new(false)));
            belowMinimum.SetName("Range.Invalid.Boundary.BelowMinimum")
                .SetCategory("VIBE.Invalid").SetCategory("VIBE.Boundary");
            yield return belowMinimum;
        }
    }
}

[TestFixture]
public sealed class RangeTests
{
    [TestCaseSource(typeof(RangeTestData), nameof(RangeTestData.Cases))]
    public void Contains_obeys_contract(RangeCase tc)
    {
        // Arrange
        var input = tc.Input;

        // Act
        var actual = RangeRule.Contains(input.Value, input.Min, input.Max);

        // Assert
        Assert.That(actual, Is.EqualTo(tc.Expected.Accepted), tc.Id);
    }
}
```

Metadata is set on typed locals before yielding, so fluent methods returning a base TestCaseData do not weaken the declared source type. The implementation milestone must compile this pattern against the resolved published package.

## xUnit TestData and test

Use typed scalar rows as the runner adapter for reliable individual-row serialization. A richer internal Case model is optional; the fixture inputs remain shared and expected values stay explicit.

```csharp
using Xunit;
using F = RangeFixture;

public static class RangeTestData
{
    public static TheoryData<string, int, int, int, bool> Cases => new()
    {
        { "Valid." + nameof(F.Ordinary), F.Ordinary.Value, F.Ordinary.Min, F.Ordinary.Max, true },
        { "Valid.Boundary." + nameof(F.AtMinimum), F.AtMinimum.Value, F.AtMinimum.Min, F.AtMinimum.Max, true },
        { "Invalid.Boundary." + nameof(F.BelowMinimum), F.BelowMinimum.Value, F.BelowMinimum.Min, F.BelowMinimum.Max, false }
    };
}

public sealed class RangeTests
{
    [Theory]
    [MemberData(nameof(RangeTestData.Cases), MemberType = typeof(RangeTestData))]
    public void Contains_obeys_contract(string id, int value, int min, int max, bool expected)
    {
        // Act
        var actual = RangeRule.Contains(value, min, max);

        // Assert
        Assert.Equal(expected, actual);
    }
}
```

The case ID appears among the discovered theory arguments. These examples are alternative framework adapters, not files to put together into the same namespace/project unchanged.
