# Coverlet

Collection mechanics are owned by [test:coverage Coverlet](../../../test-coverage/languages/dotnet/coverlet.md). Test eligibility and denominator policy remain in [coverage](../../shared/coverage.md). Use the companion skill; do not maintain another collector here.
