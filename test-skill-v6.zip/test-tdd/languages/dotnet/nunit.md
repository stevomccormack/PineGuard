# NUnit

NUnit is the default for the immediate .NET use case. Follow [shared/fixtures.md](../../shared/fixtures.md) and [.NET fixtures](fixtures.md); do not use xUnit types in NUnit tests.

## Data and assertions

- Use `[TestCaseSource]` with a named static source in a separate TestData file for every generated test, including a single case. Do not substitute literal `[TestCase]` attributes or standalone `[Test]` examples.
- Prefer `IEnumerable<TestCaseData<TCase>>` with a typed record on a compatible current stable NUnit release. Set stable names and VIBE categories on each row.
- Use `Assert.That(actual, Is.EqualTo(expected))` and appropriate constraints. Compare meaningful fields/state, not just non-null or result type.
- Keep valid-result and exception cases in separate sources/methods unless a verified narrow helper clearly handles both.
- Use fresh subject/input construction in each invocation. NUnit's fixture lifecycle can reuse class instances; use local state or a compatible `FixtureLifeCycle(LifeCycle.InstancePerTestCase)` when appropriate. Shared immutable data is fine; shared mutable mocks are not.
- Async test methods return `Task`. Check the installed major's exception-assertion signature: NUnit 5 documentation describes awaitable assertion changes that must not be copied into NUnit 4 code. Ordinary async result assertions should await production operations.
- Keep NUnit analyzers active and investigate fixture/discovery warnings. Do not mute them globally.

## Execution

Verify NUnit, the test adapter, test SDK and collector as a tuple. `NUnit3TestAdapter` is the package name even for modern NUnit versions; the name alone does not imply NUnit 3.

For a VSTest project, use its normal `dotnet test` command with the selected framework. For MTP, verify the installed NUnit integration and collector support rather than reusing VSTest switches.

Check that all data rows are discovered, no source is empty, invalid cases run, and test process failures propagate to the invoking gate. See [examples.md](examples.md) for the fixture-backed pattern.

References: [TestCaseSource](https://docs.nunit.org/articles/nunit/writing-tests/attributes/testcasesource.html), [NUnit release notes](https://docs.nunit.org/articles/nunit/release-notes/framework.html). Resolve the published stable package separately from unreleased release-note sections.

NUnit 4.6.1 with the net8.0 compiler can make lambda overload selection ambiguous. For exception constraints, use an explicitly typed Action or TestDelegate instead of relying on lambda inference. This was observed and compiled in the local NUnit smoke test.
