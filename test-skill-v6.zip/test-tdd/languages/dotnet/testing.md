# .NET testing

Read the shared rules through [SKILL.md](../../SKILL.md). This adapter owns .NET runtime and test-project mechanics. Default framework for new work is NUnit; xUnit has equal support when selected or established in the relevant suite.

## Setup

Inspect `global.json`, project target frameworks, `LangVersion`, central package files, manifests and current tests. Distinguish .NET target from SDK and C# language version. `dotnet8.0+` selects existing qualifying targets; it does not retarget the application.

Use the existing test project where appropriate. For a new one, reference only needed production projects. An API/model solution does not require extra production layers. Reference test packages only from test infrastructure. Add a shared fixture project only when multiple suites actually reuse it.

Use [fixtures.md](fixtures.md), then [nunit.md](nunit.md) or [xunit.md](xunit.md). Use [api.md](api.md) for mixed application code. Coverage is collected through [coverlet.md](coverlet.md) or [dotcover.md](dotcover.md); test framework and coverage engine are separate choices.

## Runtime hazards

- Nullable annotations do not prove a runtime guard. Deliberate null contracts differ from accidental dereferences.
- `TimeProvider` or an existing clock abstraction can control time. Use fake time for decisions, not real sleeps for timer scheduling.
- `IEnumerable`/`IAsyncEnumerable` executes lazily; enumerate and await the behaviour being asserted.
- `Task` faults and cancellation must be observed. Do not use `async void`, `.Result` or arbitrary delays in generated async tests.
- Static state, culture, environment and shared fixture instances can undermine parallelism. Prefer local inputs and per-case objects; isolate unavoidable process-level tests and restore state.
- `CallerArgumentExpression` captures the actual expression: extract fixture input to a meaningfully named local before checking a guard's parameter-name contract. Do not expect `value` when passing `tc.Value` unless explicitly overriding the name.
- A tuple or record containing a null member is not itself null. Explicitly identify which member violates the contract.
- Inverted guards reverse acceptance relative to a predicate. Their Expected adapter must declare that mapping; do not auto-map a shared validity boolean incorrectly.
- Generated regex internals and compiler-generated async machinery are different exclusion candidates. Inspect provenance and source mapping.

Prefer constraint/value assertions with explicit diagnostics. Custom assertion helpers must execute all required checks and propagate failures. A narrow helper for one result shape is preferable to a universal Expected hierarchy unrelated to the application.

Read [examples.md](examples.md) for framework-specific code patterns. These are documentation examples; execution validation is tracked separately. For exclusions read [exclusions.md](exclusions.md). For optional mutation testing, use current compatible [Stryker.NET](https://stryker-mutator.io/docs/stryker-net/introduction/) configuration and keep the run bounded.

## Architecture and domain modeling

Use [architecture](../../docs/architecture.md) for Clean Architecture, DDD and pattern discovery. Classify actual code, not project suffixes or DI usage. A domain service using real objects or a fixed TimeProvider can be strong; container registration and HTTP/provider behavior remain separate evidence.

Use one NUnit TestCaseSource or xUnit TheoryData adapter over named VIBE cases for the relevant rule, following fixtures.md. Histories and aggregate commands can be fixture inputs; construct fresh real aggregates for each row. Keep rule/context identity in case metadata or the rule inventory. Do not copy a BDD scenario wholesale just to add unit coverage.

For observability, a null logger is suitable when logs are incidental. A real scoped in-memory logger/ActivityListener capture can verify an explicit instrumentation obligation, but does not prove export/propagation. Read the shared observability boundary before deciding whether that is strong local transformation, opt-in interaction or component evidence.
