# xUnit

xUnit is fully supported. Follow [shared/fixtures.md](../../shared/fixtures.md) and [.NET fixtures](fixtures.md); selecting NUnit by default does not reduce xUnit capability.

## Data and assertions

- Every generated test uses `[Theory]` and named `[MemberData]` or `[ClassData]` backed by strongly typed `TheoryData<...>`. Do not generate `[Fact]`, `[InlineData]` or untyped `object[]` rows.
- Prefer current stable xUnit packages for new unconstrained work. Verify the package identity and major: the `xunit.v3` package can have a version major different from its name.
- Use typed Case records in fixture adaptation; either flatten to supported serializable scalar columns or implement documented serialization for custom records. Confirm individual row discovery and rerun support. Do not suppress serialization warnings globally or disable discovery enumeration just to hide them.
- Use meaningful `Assert.Equal`, collection/state assertions, and precise error assertions. Await asynchronous production operations and async assertions where required.
- A class/collection fixture has a resource lifetime, not the same meaning as case data. Avoid sharing mutable subjects or mocks through `IClassFixture`/collection fixtures. Construct them per invocation.
- A test can assert several properties of one coherent outcome. Do not use a production formula to compute expected values.

## Execution

Inspect the runner separately from xUnit's framework package. Respect VSTest versus MTP support and pair with compatible coverage tooling. For existing xUnit v2 code, report the version constraint; do not silently migrate a suite in a coverage task.

Confirm all rows run independently and the required VIBE categories are represented. See [examples.md](examples.md) for the fixture-backed pattern.

Reference: [xUnit getting started](https://xunit.net/docs/getting-started/v3/getting-started) and [data/serialization changes](https://xunit.net/docs/getting-started/v3/whats-new). Verify release packages rather than copying preview versions from examples.
