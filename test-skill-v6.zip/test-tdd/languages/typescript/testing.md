# TypeScript testing

This adapter implements the shared VIBE/fixture/scope rules for TypeScript. Default new-work framework: current stable Vitest with a matched coverage package. Verify Node/TypeScript/Vite compatibility and lock versions; reuse the project's package manager.

## Files and typed cases

```text
fixtures/range.fixture.ts       named readonly inputs and fresh factories
test-data/range.cases.ts        typed expectations and VIBE case rows
range.test.ts                  test.each and assertions
```

Define an explicit `Case` type including `id`, input, VIBE fields and expected outcome. Export case arrays using `satisfies readonly Case[]` or a compatible explicit type. Use `test.each(cases)('$id', ({ input, expected }) => ...)` for every generated test, including one-row sources. Do not hide cases inside a single test's loop.

Use discriminated unions for distinct result/error expectations; separate test groups where that avoids branching in the test. Keep factories pure; create mutable objects per invocation. Readonly is a type restriction, not deep runtime freezing.

Example test-body shape, with rows imported from a separate typed TestData module:

```typescript
import { expect, test } from 'vitest';
import { rangeCases } from './test-data/range.cases';
import { inRange } from '../src/range';

test.each(rangeCases)('$id', ({ input, expected }) => {
  expect(inRange(input.value, input.min, input.max)).toBe(expected);
});
```

## Strength boundary

Pure parsers, formatters, transformations, predicates and reducers fit the shared strong gates. Test `undefined` versus `null`, absent versus explicit fields, zero/empty values, Unicode and specified numeric boundaries. `NaN`, infinities, floating-point tolerance, locale and object key ordering need defined expectations. TypeScript types disappear at runtime; test runtime validation only where a contract requires it, and keep compiler/type tests separate.

Control time with supported fake timers when testing local policy; restore them and verify no pending work leaks. Await async assertions. Module mocks, import-time side effects, DOM/browser APIs, fetch contracts and database clients require separate classification; mocking a module does not prove its boundary works. jsdom-style environments do not prove real-browser behaviour.

## Coverage

Use Vitest's matched V8 provider by default in supported environments, or Istanbul where needed. Include inventoried production sources explicitly so unimported files remain visible. Verify TypeScript source remapping and inspect raw branch counts. Collect fresh JSON/detail plus a human report; apply the shared exact-count rules to selected scope. Native threshold configuration is useful only when its include set matches that scope.

Provider-specific ignore comments must satisfy [shared/exclusions.md](../../shared/exclusions.md). Do not add ignore comments to satisfy a percentage or replace runtime behaviour with TypeScript assertions.

References: [Vitest coverage](https://vitest.dev/guide/coverage), [Vitest test API](https://vitest.dev/api/test.html). Typechecking and linting remain additional evidence, not coverage.

## Architecture and domain modeling

Clean Architecture and DDD apply to TypeScript. They concern responsibilities, dependencies and domain semantics, not C# assemblies. A domain can use classes, immutable records/unions and functions, or a mixture. Modules/package imports provide boundaries, but names such as domain or services do not establish purity.

Use [architecture](../../docs/architecture.md) and [business rules](../../shared/business-rules.md) without changing the six gates. A reducer, aggregate method, policy function or use-case handler can all be strong. An async function returning a Promise can still be deterministic when its inputs and dependency outcomes are controlled. Async syntax alone is not an I/O boundary.

TypeScript types are erased; a typed network payload is not runtime validation. Test the actual decoder/validator with accepted input/error contracts, and keep transport enforcement separate. This language behavior is documented in [the TypeScript handbook](https://www.typescriptlang.org/docs/handbook/2/basic-types.html).

Use the existing typed named fixture rows. Keep business rules for number precision, NaN/infinity, undefined versus null, object aliasing, timezone and serialization explicit where relevant. Do not assume a .NET decimal example has identical JavaScript number semantics. Real local model objects are usually more useful than module-level mocks of domain collaborators. Use fake timers only when time/scheduling is actually the claim; supplying a fixed instant to a policy is simpler.
