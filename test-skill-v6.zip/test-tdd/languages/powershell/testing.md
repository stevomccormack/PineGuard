# PowerShell testing

Use current stable PowerShell and Pester for new unconstrained work; verify their compatibility. The current Pester documentation is v6, while existing repositories may still use v5. Follow [shared/tooling.md](../../shared/tooling.md) rather than copying an old example or silently migrating.

## Fixture translation

```text
fixtures/Range.Fixture.ps1      pure named inputs/factories
test-data/Range.Cases.ps1       explicit case hashtables/objects and expected values
Range.Tests.ps1                Pester discovery, subject setup, It -ForEach
```

Use named case data with consistent fields: `Id`, `Input`, `Expected`, `Validity`, `Focus`, and linked authority. Validate field shape in a reusable loader if data is external. Use `BeforeDiscovery` for data needed by discovery, and `BeforeAll`/`BeforeEach` for subject import and runtime setup. Each file must discover independently.

Every generated `It` uses named `-ForEach` case data, even a single row. Separate success and error cases. Do not put a fixture-dependent source in `BeforeAll` and expect it to exist at discovery time. Do not execute operational scripts merely to import helper functions.

For Pester v6, a representative body is:

```powershell
BeforeDiscovery {
    . (Join-Path $PSScriptRoot 'test-data/Range.Cases.ps1')
    $rangeCases = Get-RangeCases
}
BeforeAll {
    . (Join-Path $PSScriptRoot '../src/Range.ps1')
}
Describe 'Test-Range' {
    It '<Id>' -ForEach $rangeCases {
        Test-Range -Value $Value -Min $Min -Max $Max | Should-Be $Expected
    }
}
```

Here the named data factory supplies `Id`, `Value`, `Min`, `Max`, `Expected` and VIBE metadata. Use fresh mutable inputs per invocation. Current v6 assertions differ in some semantics from classic `Should`; verify exact boolean/null/collection assertions instead of mass rewriting.

## Strength boundary

Pure string parsing, path-string normalization and input-to-command-plan decisions are strong when specified. Real path existence, registry, environment, process invocation and network calls are boundary behaviour. Fixed fixture files and TestDrive provide controlled filesystem tests but do not magically make them pure; classify file parsing separately from file access.

Consider scalar-versus-array unrolling, empty collections, `$null`, terminating versus non-terminating errors, streams, culture and pipeline enumeration. Assert the intended output stream and error contract. Do not globally change `$ErrorActionPreference` in a way that changes the subject contract; isolate/restore state where needed.

Pester mocks providing simple data can support local outcome tests. Call-count assertions remain collaboration scope. Inspect module scope and current-version mock fallback behaviour; do not let an unmatched mock unexpectedly execute an external command.

## Coverage

Use `New-PesterConfiguration` with explicit test path and production `CodeCoverage.Path`, enable collection, and inspect fresh results and executed case counts. Pester reports analyzed-command coverage; do not infer branch coverage from a JaCoCo/Cobertura container or a 100% command result. Report the actual available counters and branch verification unsupported unless separately demonstrated by a branch-capable tool.

Pester v6 documents `[ExcludeFromCodeCoverage()]` on functions/scriptblocks. Apply [shared/exclusions.md](../../shared/exclusions.md) before using it. Keep PSScriptAnalyzer findings separate from test results.

References: [data-driven tests](https://pester.dev/docs/usage/data-driven-tests), [coverage](https://pester.dev/docs/usage/code-coverage), [v6 migration and compatibility](https://pester.dev/docs/migrations/v5-to-v6).

## Modules and operational policies

PowerShell can implement business and operational rules: retention eligibility, deployment selection, access decisions, migration plans and configuration precedence. These require accepted policy just as application rules do. The language does not make them trivial or self-evident.

Prefer testing existing functions/modules that transform supplied objects or compute a plan. For example, an accepted retention rule plus fixed time and supplied file metadata can support strong deletion-eligibility tests. Those tests do not prove correct enumeration, permissions or deletion of real files. Inspect the actual command boundary and use separate filesystem/process evidence.

A module is an organizational unit, not a certificate of isolation. Discovery/import side effects, profiles, environment variables, culture, provider paths and pipeline/error-stream behavior may affect fidelity. Pester mocks supplying a simple fact can serve as stubs; Should-Invoke-style obligations remain collaboration tests under the same default policy as .NET.

Use [patterns](../../docs/patterns.md) to recognize planner/executor and transformation boundaries. Do not impose domain/application/infrastructure folders on a small script repository. Preserve named VIBE fixtures and the native discovery/runtime separation already documented here. Command coverage still cannot be renamed line-and-branch coverage.
