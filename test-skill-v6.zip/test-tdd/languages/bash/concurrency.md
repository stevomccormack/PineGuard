# Bash concurrency

Bats remains selected. Read [shared concurrency](../../shared/concurrency.md) for case isolation, readiness, cleanup and strength classification, and [environment](../../../test-coverage/languages/bash/environment.md) for WSL2 and Git Bash performance guidance. This file owns Bash runner and process details, including alternatives when a framework comparison is requested.

## Parallel Bats cases

Bats runs serially by default and supports bounded parallel jobs through its native `--jobs` option. Resolve the installed version's help and an available supported backend: GNU parallel or shenwei356/rush. The skill installer currently does not install or check that backend.

Example inside the chosen Bash environment, after confirming the backend:

```bash
bats --jobs 4 --formatter tap tests/unit
```

Four is illustrative, not a default to impose on every host. This is a native Bats invocation, not a new switch on test:tdd or test:coverage. Missing parallel tooling does not prevent a serial Bats run. Keep Bats, its backend and child tools native to the selected environment.

| Situation | Action |
|---|---|
| Cases have isolated mutable resources | Validate serial results, then enable and measure bounded jobs |
| Tests within a file share a resource that cannot be isolated | Use a verified native serialization option, such as `--no-parallelize-within-files`; files still need isolation from one another |
| Resource is shared across files | Isolate it or serialize the affected suite; within-file serialization is insufficient |
| Coverage is requested too | Follow the companion's [collection requirements](../../../test-coverage/languages/bash/testing.md#parallel-collection); runner parallelism alone is not collection support |

Keep every VIBE case separately discoverable. A loop doing many assertions inside one test remains one reported case, even if that loop launches background jobs. Process isolation does not isolate a shared filesystem, port or external service.

## Background fixture work

Bash provides background processes and `wait`, not JavaScript-style async/await. Setup can start work and synchronize with it, but that requires an explicit process lifecycle:

- Start an owned child from the setup/test process that will manage it; save `$!` immediately. Do not start it inside Bats `run` and assume its PID or variable changes persist in the parent: `run` uses a subshell.
- For a long-lived child that does not write Bats diagnostics, close inherited Bats descriptor 3 at launch (`command 3>&- &`). Redirect its stdout/stderr to case-owned logs. An inherited descriptor or output pipe can otherwise keep a runner waiting after the test seems finished.
- Use the shared readiness/deadline rule. Keep readiness diagnostics and detect early child failure; do not treat process existence as service readiness.
- Wait for each owned finite child and inspect its exit status. `wait` with no operands does not aggregate child failures. Handle nonzero statuses explicitly instead of relying on `set -e`.
- Register teardown/cleanup for partial setup as well as completed tests. Stop and reap only owned children, with a bounded shutdown procedure. If children spawn descendants, define ownership and cancellation for that process tree; killing only the immediate PID may leave work behind. Do not use broad process-name kills or `kill 0` in a shared session.

Use the runner's lifecycle hooks and preserve its signal/trap handling. Do not overwrite Bats internals with a generic trap snippet. Framework cleanup helps manage fixtures; it does not turn real process/service behaviour into a strong local unit claim.

## Alternatives to Bats

| Option | VIBE fixtures and concurrency | Decision |
|---|---|---|
| ShellSpec | Native `Parameters` data-driven examples and `--jobs` parallel execution | Preferred alternative to evaluate if a framework change is requested; not currently selected, installed or integrated into the convenience coverage collector |
| Plain Bash harness | Named fixture arrays/functions; `&` and per-PID `wait` for concurrent cases | Possible, but a new harness must implement case discovery, outcomes, isolation, deadlines and cleanup; prefer an established framework for new application suites |

A sequential harness can invoke sourceable functions within one shell to reduce process creation, while taking responsibility for restoring shell state after each case. Concurrent shell cases introduce processes again. Keep an existing suitable harness when the task does not require migration; a switch to ShellSpec or a new harness needs its own coverage integration verification.

Changing framework or adding parallelism does not remove Git Bash's underlying process costs. Keep the WSL2 recommendation, reduce unnecessary fixture subprocesses, and benchmark the actual suite before claiming a framework is faster. The package's existing Bash validation harnesses are not evidence that a framework-free application suite is preferable.

Sources checked 2026-09-10: [Bats execution options](https://bats-core.readthedocs.io/en/stable/usage.html), [Bats hooks, subshells and descriptor 3](https://bats-core.readthedocs.io/en/stable/writing-tests.html), [ShellSpec parameters and jobs](https://github.com/shellspec/shellspec), [Bash wait](https://www.gnu.org/software/bash/manual/html_node/Job-Control-Builtins.html).
