# Bash testing

Use bats-core as the selected framework with the current stable compatible Bash/tool versions. For full suites on Windows, prefer Ubuntu on WSL2; follow the shared [Bash environment](../../../test-coverage/languages/bash/environment.md) for filesystem placement, native tools and separate Git Bash compatibility checks. The shared scope, expectations and VIBE rules apply; Bash does not have C#'s type system or native TheoryData.

## Fixture translation

```text
fixtures/range.bash          literal named inputs and expected case values
range.bats                  separately discovered tests referencing fixture cases
```

Use a pure named fixture loader or dedicated functions that populate case-specific variables/arrays. Treat fixture text as data; never use `eval` to turn fixture strings into commands. Represent arguments with arrays, preserve empty strings, and quote expansions. Validate fixture shape and fail on unknown case IDs.

Each independently discovered Bats test selects a named VIBE case. A single loop inside one Bats test is not equivalent to separately discoverable theory rows: it obscures failure counts and may stop early. For a large matrix, only use a verified deterministic generator that produces separate tests and validates case count; do not introduce one for a small suite.

```bash
@test "Range Valid Boundary at minimum" {
  load_range_case at_minimum
  run in_range "$case_value" "$case_min" "$case_max"
  [ "$status" -eq "$expected_status" ]
  [ "$output" = "$expected_output" ]
}
```

The loader is fixture code; `in_range` is the real subject. Expected status/output come from the accepted contract, not from invoking it during setup. Use fixture-defined cases even for one test. Separate stderr where the contract distinguishes it, using installed Bats options.

## Strength boundary

For parallel case execution, background fixture work or a requested framework comparison, read [concurrency](concurrency.md). Bats stays selected; alternative frameworks and native runner options are not additional skill switches.

Functions transforming provided strings/numbers into stdout/status can be strong. Process installation, permissions, actual filesystem access, command availability, external utilities and networking need boundary evidence. PATH stubs can provide controlled command responses; asserting their call choreography is collaboration scope.

Account for unset versus empty, whitespace/newlines, globs, leading hyphens, locale, integer parsing and quoting. Binary/NUL data cannot be faithfully held in ordinary shell variables; test byte-oriented contracts with appropriate files/tools and classify the resulting boundary.

`run` executes in a subshell, so changes to caller variables do not persist. Check state inside the relevant process when state is the contract. Source library functions without running a script's main program. `set -e`, pipelines and subshells have context-sensitive failure behaviour; assertions must check actual status rather than assume errexit proves failure handling.

## Coverage

kcov supports Bash coverage in supported environments. Verify the installed tool, OS and source tracing on a known fixture before relying on it. Use its actual line evidence with explicit source scope. Do not promise branch coverage from traced lines or infer it from report format. If a reliable branch-capable setup is absent, mark branch target unsupported while reporting VIBE cases and available coverage.

ShellCheck and shfmt are useful separate checks, not runtime tests. On Windows, do not silently run Bash commands in PowerShell or require WSL/container provisioning without task context.

References: [bats-core stable documentation](https://bats-core.readthedocs.io/en/stable/writing-tests.html), [kcov](https://github.com/SimonKagstrom/kcov).

## Functions and operational policies

Bash can encode operational policy, including configuration precedence, eligibility filters, version selection and planned actions. A known operational rule can support strong local tests; 'this is only a script' does not supply expected answers.

Look for sourceable functions that transform supplied strings, arguments or metadata without import-time effects. A deployment planner returning the defined argument vector can be strong. Actually launching the process, preserving exit status, invoking a shell and performing filesystem/network effects are separate claims. Avoid comparing a shell command string when the real obligation is a correctly separated argument vector.

Bats runs tests through processes; classify the behavior being tested, not the existence of a process alone. A controlled invocation of a deterministic function can be local evidence. Host utility differences, glob expansion, permissions, pipelines, locale and external executable behavior require the relevant shell/platform tests. A file containing both pure decisions and execution is mixed regardless of its filename.

Use [patterns](../../docs/patterns.md) for planner/executor and parser/policy candidates. Do not add DDD scaffolding to a small functions library. Keep fixtures named and each Bats case independently discoverable. The Bash orchestration requirement does not force production TypeScript or PowerShell tests to be written in Bash. kcov remains line-only evidence for this skill.
