# Installation

Install complete `test-tdd` and `test-coverage` folders as siblings in the agent skills directory (Codex: `$HOME/.codex/skills/`). Reload skill discovery if required.

The root `install.sh` delegates to the companion installer, which owns all dependency selection and installation. See [coverage installation](../test-coverage/INSTALL.md) for macOS and Windows prerequisites, supported providers, cache paths and exit codes. Use macOS Bash or Windows Git Bash; quote paths containing spaces.

```bash
bash "$HOME/.codex/skills/test-tdd/install.sh" --language csharp --dry-run
bash "$HOME/.codex/skills/test-tdd/install.sh" --language csharp
bash "$HOME/.codex/skills/test-tdd/install.sh" --language typescript --project "$PWD"
```

Agent equivalent: `$test-tdd --install --language csharp`. Add `--dry-run` for a dependency preview. This does not create tests. NUnit and xUnit remain project-owned; installation does not switch frameworks. All other languages and installer switches are inherited from the companion installer.

For full Bash suites on Windows, use the selected Bats framework inside Ubuntu WSL2. Follow [Bash environment](../test-coverage/languages/bash/environment.md), including Linux-filesystem placement, Linux-native tool setup and separate Git Bash compatibility checks.
