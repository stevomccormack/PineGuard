# Coverage skill boundary

The companion [test:coverage](../test-coverage/SKILL.md) is implemented and installed. Its [PLAN.md](../test-coverage/PLAN.md) owns outstanding measurement work; [options](../test-coverage/shared/options.md) owns the actual Bash interface.

TDD owns eligibility, assertion authority, VIBE fixtures, test generation, authorized production changes and the next justified case. Coverage owns coverage-tool installation, collection, native metric interpretation and JSON/HTML evidence. Neither coverage percentages nor a script decide business intent.

The shared loop is defined once in [coverage-handoff.md](shared/coverage-handoff.md). All delivered scripts are Bash for macOS and Windows Git Bash. Native framework commands remain native; no duplicate Python or PowerShell orchestration core is planned.
