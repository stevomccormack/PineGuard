# PineGuard reference

Inspected read-only on 2026-09-09 at local revision `139677d950093cc648598fce5016ca72fda84887`. This was a documentation and selected-source inspection, not a fresh verification of PineGuard's coverage claims. Local work may differ from the committed revision.

Repository: [PineGuard](https://github.com/stevomccormack/pineguard).

The later full-tree discovery considered all 240 files under `docs/ai` and found 160 matching Markdown files: 15 testing specifications, 6 workflows, 2 command contracts, 3 skill/exemplar documents, 6 rules/memory/templates, 32 scoped agent wrappers, 11 historical plans and 85 related references. The [full inventory](pineguard-inventory.md) records paths, search criteria and content-hit locations. This distinguishes discovery of all matches from close reading of the canonical subset.

## Material inspected

- `docs/ai/specs/testing/fixture.md`: neutral rule scenarios, layer-specific Expected/Case types and typed scenario conversion.
- `docs/ai/specs/testing/unit-test.md`: mandatory TheoryData, separate TestData/tests, operation groups and assertion helpers.
- `docs/ai/specs/testing/gold-standard.md`: populated datasets, fixture adoption and dated coverage evidence.
- `docs/ai/specs/testing/coverage.md`: collection, filtered analysis and coverage gate responsibilities.
- `tests/PineGuard.Testing/Fixtures/DecimalRulesFixtures.cs`: named values, ordinary/edge valid/invalid groups and rollups.
- `tests/PineGuard.Core.UnitTests/Rules/DecimalRulesTestData.cs` and `DecimalRulesTests.cs`: fixture-to-case conversion and small assertion-focused tests.
- `tools/testing/Test-Tools.ps1`, `tools/.tests/Cobertura-Parser.Tests.ps1` and `Dotenv-Parser.Tests.ps1`: PowerShell quality checks and report/parser fixtures.
- `tools/code-coverage/Test-Coverage.ps1`, `coverlet.runsettings`, and the beginning of `tools/.shared/coverage.ps1`: report gating, filters and artifact conventions.
- `Directory.Packages.props`: actual package pins, including xUnit v2; not a prescription for new current-stable projects.

## Adopt

| PineGuard pattern | Portable adaptation |
|---|---|
| Fixtures -> scenarios -> layer Expected/Case -> TheoryData -> assertion | Neutral fixtures -> contract expectation -> native data source -> test |
| Valid/invalid plus valid-edge/invalid-edge groups | VIBE validity and focus are explicit dimensions |
| Named fixture values and `nameof` references | Stable native case IDs with no scattered test-body literals |
| Separate data definitions and tests | Keep fixture inputs, contract TestData and assertions separate |
| Shared input scenarios across library layers | Reuse inputs across contracts; do not share incorrect expectations |
| Coverage generator separate from analyzer/gate | Collector adapters feed one validated evidence model |
| Known-count coverage XML fixtures | Verify arithmetic, scope mapping and failure modes before trusting gates |
| Dated verification evidence | Separate observed evidence from structural conformance |

## Deliberate improvements for this skill

1. **Do not generalize PineGuard's library architecture.** Its multiple validation layers justify shared infrastructure that a small API may not need.
2. **Do not copy current filters blindly.** Its runsettings include broad compiler-generated exclusions. This skill requires inspecting whether such filters hide handwritten async/iterator logic.
3. **Do not treat a percentage as test quality.** Add expectation authority and explicit unresolved scope to the report.
4. **Do not copy a Windows-only path normalization convention.** The inspected parser test records current backslash behaviour; a portable implementation needs OS-aware path/source identities.
5. **Do not infer branchless from absent branch capability.** Zero branches in a real branch-capable report differs from a statement-only producer.
6. **Do not let constants move the oracle.** Reference published boundaries for relative cases, but independently verify specification-defined constant values.
7. **Do not widen private helpers just to close a percentage.** Existing internal test seams can be useful; production visibility changes need an actual design/task justification.
8. **Do not copy old package versions as best practice.** Use current stable compatible packages for new work; explicitly retain constraints in existing projects.
9. **Do not assume every format has only ordinary valid/invalid cases.** Delimiters, empty input, Unicode and token lengths can be boundaries or edges.
10. **Do not universalize PineGuard's dotCover failure.** Its gate explicitly rejects dotCover because of a documented local/version-specific collection problem. This skill separately records dotCover's general statement-coverage limit and the actual installed tool's collection capability.

The inspected `Test-Coverage.ps1` header contains older wording about both engines producing gateable output, while its parameter description and code explicitly reject dotCover. This illustrates why scripts, current configuration and observed execution must be checked together. No PineGuard files were changed.

## Additional extraction from docs/ai

| Source | Useful lesson | Destination |
|---|---|---|
| `commands/test.md`, `commands/coverage.md`, `commands/fix.md` references | Executing/measuring is distinct from repairing | [Coverage skill plan](../COVERAGE-PLAN.md) |
| `workflows/test.md` | One project/scope registry prevents duplicated path maps | Coverage discovery and validated project selection |
| `workflows/coverage.md` | One parameterized workflow is better than a separate implementation per scope | Thin language/provider adapters |
| `workflows/fix-test.md` | Diagnose whether the test or production expectation is wrong | [Workflow](../shared/workflow.md) |
| `workflows/fix-coverage.md` | Fresh baseline -> gap -> targeted case -> fresh verification | TDD owns remediation; reporting owns measurement |
| `workflows/verify-coverage.md` | Dependency order can reduce duplicated downstream failure noise | Use known dependency ordering when relevant; never assume PineGuard's library order |
| `workflows/test-last.md` | Reproduce a prior run with explicit parameters | Run manifests; do not replay arbitrary remembered shell text |
| `meta/template-coverage.md` and domain coverage addenda | Child docs own exceptions only; global policy is single-source | Shared policy and narrow language/provider docs |
| `specs/testing/project.md` | A test-support library is not necessarily an executable test project; shared helpers need real consumers | Test discovery and minimal fixture infrastructure |
| `memory/test-writer.md` | Successful guard tests should assert passthrough values, not just absence of an exception | [Test cases](../shared/test-cases.md) |
| `memory/coverage-analyst.md` | Preserve selected engine and consult current command documentation | Tooling and adapter compatibility |
| `skills/scaffold-unit-test/references/README.md` | Read real exemplars but do not blindly copy them | Native fixtures and deliberate portability |
| `specs/guard-clauses/unit-test.md` | Inverted predicates, null cases and parameter capture need explicit mapping | [.NET adapter](../languages/dotnet/testing.md) |
| `specs/data-annotations/unit-test.md` | A shared input can have different valid/error results in another contract | [Fixture architecture](../shared/fixtures.md) |

Some documents contain conflicting historical dotCover claims, and a coverage verification workflow includes "fix immediately" despite being a measuring workflow. Preserve the valuable separation from the command contracts instead of copying that ambiguity. Coverage must report a failure without silently repairing source.

The short coverage-improvement recipe says to stop at 100% and permits some unreachable/platform exclusions. The new skill adds stronger prerequisites: justified authority, explicit source inventory, no false empty-scope success, no arbitrary unreachable-state tests, and no denominator changes merely to meet the target.

Scoped agent wrappers are routing data, not 32 independent testing methods. Historical completed plans are reference history, not current constraints. Related documents mentioning tests are inventoried for traceability but are not all loaded into the test builder's context.
