# PineGuard testing inventory

Scanned 2026-09-09, read-only. Source root: `docs/ai` in the local PineGuard checkout. All 240 files were considered, including code exemplars; readable text was matched by path or testing vocabulary. This is an exhaustive match inventory for the documented search, not a claim that every match is a canonical testing rule.

Search: case-insensitive words `test`, `tests`, `testing`, `coverage`, `fixture`, `fixtures`, `xunit`, `nunit`, `pester`, `vibe`, `coverlet`, `dotcover`, plus paths containing test/coverage/fixture/gold-standard. No matched document was modified.

Found **160 matching files**, including **160 Markdown files**. Dedicated path matches: **67**. File hashes are retained in the adjacent JSON inventory to identify this snapshot; they do not certify correctness.

The design extraction is in [pineguard.md](pineguard.md); the proposed reporting-skill split is in [COVERAGE-PLAN.md](../COVERAGE-PLAN.md).

## Categories

| Category | Files |
|---|---:|
| Command contract | 2 |
| Historical plan | 11 |
| Related reference | 85 |
| Rule, memory or template | 6 |
| Scoped agent wrapper | 32 |
| Skill or exemplar | 3 |
| Testing specification | 15 |
| Workflow | 6 |

## Command contract

| Path relative to docs/ai | Title | Content hits | First hit |
|---|---|---:|---:|
| `commands/coverage.md` | Command: Coverage | 17 | 3 |
| `commands/test.md` | Command: Test | 18 | 3 |

## Historical plan

| Path relative to docs/ai | Title | Content hits | First hit |
|---|---|---:|---:|
| `plans/completed/adapter-naming-collision-review.md` | Adapter Naming Collision Review | 6 | 366 |
| `plans/completed/fixture-architecture-v2-infrastructure.md` | Plan: Migrate Infrastructure (Fixture Architecture v2) | 16 | 3 |
| `plans/completed/fixture-architecture-v2-rule-group-1.md` | Plan: Fixture Architecture v2 — Rule Group 1 | 23 | 3 |
| `plans/completed/fixture-architecture-v2-rule-group-2.md` | Plan: Fixture Architecture v2 — Rule Group 2 | 18 | 3 |
| `plans/completed/guard-exception-policy-uplift.md` | Guard Exception Policy Uplift | 41 | 33 |
| `plans/completed/multi-target-framework.md` | Multi-Target Framework Support for PineGuard | 27 | 18 |
| `plans/completed/naming-convention-rename.md` | Naming Convention Rename Plan | 18 | 21 |
| `plans/completed/nuget-publishing.md` | NuGet Publishing Plan for PineGuard | 28 | 15 |
| `plans/completed/refactor-nullability-ordering.md` | Plan: Nullability and Method Ordering Refactor | 2 | 35 |
| `plans/completed/v2-masterplan.md` | PineGuard v2 — Master Plan | 6 | 40 |
| `plans/completed/v2-pineguard.md` | PineGuard — Repo Plan (v2 Pruning) | 14 | 37 |

## Related reference

| Path relative to docs/ai | Title | Content hits | First hit |
|---|---|---:|---:|
| `agents/ask-council.md` | Agent: Ask Council (Pressure-Test a Decision) | 2 | 7 |
| `agents/audit-cli.md` | Agent: Run Audit CLI (Library / Testing / Docs / All) | 8 | 7 |
| `agents/audit-gap.md` | Agent: Analyze Coverage Gaps (Autonomous) | 13 | 7 |
| `agents/clean-artifact.md` | Agent: Clean Artifacts | 1 | 18 |
| `agents/clean-log.md` | Agent: Clean Logs | 1 | 18 |
| `agents/document-all.md` | Agent: Generate XML Docs for All Projects | 4 | 23 |
| `agents/scaffold-vertical-slice.md` | Agent: Implement a feature vertical slice (Core -> Must -> Guard -> Adapters -> Tests) | 9 | 7 |
| `business-units/engineering.md` | Engineering Department | 3 | 15 |
| `commands/audit.md` | Command: Audit | 2 | 15 |
| `commands/clean.md` | Command: Clean | 2 | 16 |
| `commands/commit.md` | Command: Commit | 6 | 16 |
| `commands/council.md` | Command: Council | 2 | 16 |
| `commands/fix.md` | Command: Fix | 21 | 17 |
| `commands/format.md` | Command: Format | 1 | 21 |
| `commands/scaffold.md` | Command: Scaffold | 2 | 15 |
| `commands/scan.md` | Command: Scan | 2 | 21 |
| `memory/code-reviewer.md` | Code Reviewer Memory | 10 | 23 |
| `memory/migration-checker.md` | Migration Checker Memory | 6 | 7 |
| `memory/validation-builder.md` | Validation Builder Memory | 2 | 25 |
| `meta/taxonomy.md` | AI Brain Taxonomy (PineGuard) | 22 | 44 |
| `meta/template-agent.md` | Agent Playbook Template | 2 | 78 |
| `meta/template-spec.md` | Brain Document Template | 5 | 21 |
| `meta/tooling.md` | AI Tooling Alignment (GitHub + Microsoft) | 15 | 40 |
| `plans/audit-cli-rebuild.md` | Plan — Audit CLI: Review, Verdict and Rebuild as `pineguard audit` (TypeScript, `apps/cli`) | 110 | 30 |
| `plans/code-scan-tooling.md` | Plan: Code-Scan Tooling — one contract, twenty tools, `pineguard scan` | 58 | 7 |
| `plans/competitive-analysis.md` | PineGuard Competitive Analysis | 12 | 21 |
| `plans/core-common-api-decisions.md` | Core / Common API Decisions | 2 | 419 |
| `plans/cross-platform-tools-migration.md` | Plan: Cross-Platform Tools Migration (PowerShell → Bash) | 11 | 24 |
| `plans/future-language.md` | PineGuard — Future Language Considerations (Must/Guard) | 5 | 151 |
| `plans/library-expansion-roadmap.md` | Plan: Library Expansion Roadmap | 11 | 32 |
| `plans/new-surfaces-missing-validation-cases-00-program.md` | Plan 00 — New Surfaces Program: Charter & Shared Standards | 81 | 51 |
| `plans/new-surfaces-missing-validation-cases-01-structural-validation.md` | Plan 01 — Phase 1: Structural Validation | 60 | 47 |
| `plans/new-surfaces-missing-validation-cases-02-options.md` | Plan 02 — Phase 2: `PineGuard.Extensions.Options` | 25 | 36 |
| `plans/new-surfaces-missing-validation-cases-03-aspnetcore.md` | Plan 03 — Phase 3: `PineGuard.AspNetCore`, `PineGuard.Extensions.DependencyInjection` and the async seam | 25 | 119 |
| `plans/new-surfaces-missing-validation-cases-04-mediatr-result-bridges.md` | Plan 04 — Phase 4: `PineGuard.MediatR` and the result-pattern bridges | 13 | 214 |
| `plans/new-surfaces-missing-validation-cases-05-rule-batches.md` | Plan 05 — Phase 5: Rule-level batches (non-ISO) | 38 | 20 |
| `plans/new-surfaces-missing-validation-cases-06-analyzers.md` | Plan 06 — Phase 6: `PineGuard.Analyzers` | 14 | 56 |
| `plans/new-surfaces-missing-validation-cases.md` | Plan: New Surfaces & Missing Validation Cases | 3 | 125 |
| `plans/new-surfaces-orchestration.md` | New Surfaces Program — Orchestration, Model-Routing and Progress Tracker | 57 | 39 |
| `plans/tools-review-and-standardisation.md` | Plan: `tools/` Review and Standardisation | 177 | 18 |
| `README.md` | PineGuard AI Brain (docs/ai) | 17 | 26 |
| `roles/builder.md` | Role: Software Engineer | 6 | 27 |
| `roles/business-analyst.md` | Role: Business Analyst | 1 | 23 |
| `roles/lead-engineer.md` | Role: Lead Engineer | 4 | 22 |
| `roles/owner.md` | Role: Senior Engineer | 10 | 17 |
| `roles/planner.md` | Role: Test Analyst | 12 | 7 |
| `roles/reviewer.md` | Role: Code Reviewer | 1 | 23 |
| `roles/shipper.md` | Role: DevOps Engineer | 3 | 27 |
| `roles/verifier.md` | Role: Test Engineer | 14 | 7 |
| `rules/coordination.md` | Coordination Rules | 5 | 12 |
| `rules/global.md` | Global Rules | 3 | 18 |
| `rules/tools.md` | Tools & Scripts | 1 | 11 |
| `skills/ask-council/SKILL.md` | Skill: Ask Council | 1 | 8 |
| `skills/document/SKILL.md` | Skill: Generate XML Documentation | 1 | 286 |
| `skills/fix-roslyn/SKILL.md` | Skill: Fix Roslyn Compiler Diagnostics | 1 | 11 |
| `skills/format-code/SKILL.md` | Skill: Format Code | 2 | 8 |
| `skills/INDEX.md` | PineGuard Skills Catalog | 12 | 21 |
| `skills/new-validation/SKILL.md` | Skill: New Validation (Vertical Slice) | 7 | 7 |
| `skills/scaffold-quality-tool/SKILL.md` | Skill: Scaffold Quality Tool | 15 | 13 |
| `skills/scan-roslyn/SKILL.md` | Skill: Run Roslyn Compiler Diagnostics | 2 | 13 |
| `skills/scan-sonar/SKILL.md` | Skill: Run SonarQube Analysis | 3 | 19 |
| `specs/coding-standard.md` | Coding Standards & Static Analysis Rules | 4 | 12 |
| `specs/core/project.md` | PineGuard.Core Project Spec (Rules & Utils) | 3 | 31 |
| `specs/council.md` | LLM Council (Normative) | 1 | 29 |
| `specs/data-annotations/project.md` | PineGuard.DataAnnotations Project Spec | 2 | 36 |
| `specs/dependencies.md` | PineGuard AI Spec Dependencies | 3 | 62 |
| `specs/fluent-validation/project.md` | PineGuard.FluentValidation Project Spec | 2 | 36 |
| `specs/guard-clauses/project.md` | PineGuard.GuardClauses Project Spec | 12 | 28 |
| `specs/must-clauses/project.md` | PineGuard.MustClauses Project Spec | 3 | 29 |
| `specs/orchestration.md` | AI Working Instructions (PineGuard) | 11 | 31 |
| `specs/project.md` | Base Project Spec (Production Code) | 2 | 22 |
| `specs/protocol.md` | Universal Agent Protocol | 2 | 71 |
| `specs/safety.md` | Destructive Operations Safety | 17 | 205 |
| `specs/spec.md` | PineGuard AI Root Spec (Cascading) | 21 | 15 |
| `specs/tools/audit-cli/spec.md` | PineGuard Audit CLI Specification (`pineguard audit`) | 36 | 29 |
| `specs/tools/code-diagnostics/spec.md` | Code Diagnostics Specification (Roslyn Compiler Warnings) | 1 | 56 |
| `specs/tools/spec.md` | PineGuard Tools Specification | 9 | 37 |
| `workflows/audit.md` | Workflow: Audit | 7 | 30 |
| `workflows/build-all.md` | Workflow: Build All | 4 | 10 |
| `workflows/commit.md` | Workflow: Commit | 2 | 22 |
| `workflows/fix-roslyn.md` | Workflow: Fix Roslyn | 1 | 23 |
| `workflows/format.md` | Workflow: Format | 1 | 21 |
| `workflows/plan-with-council.md` | Workflow: Plan with Council | 1 | 10 |
| `workflows/scan-qodana.md` | Workflow: Scan Qodana | 1 | 22 |
| `workflows/scan-roslyn.md` | Workflow: Scan Roslyn | 1 | 22 |

## Rule, memory or template

| Path relative to docs/ai | Title | Content hits | First hit |
|---|---|---:|---:|
| `memory/coverage-analyst.md` | Coverage Analyst Memory | 20 | 1 |
| `memory/test-writer.md` | Test Writer Memory | 14 | 1 |
| `meta/template-coverage.md` | AI Spec Template — Code Coverage Spec (Addendum) | 15 | 3 |
| `meta/template-unit-test.md` | AI Spec Template — Unit Tests Spec (Addendum) | 17 | 3 |
| `rules/fixture-conventions.md` | Fixture Architecture v2 — Rules | 14 | 1 |
| `rules/testing.md` | Unit Tests | 11 | 1 |

## Scoped agent wrapper

| Path relative to docs/ai | Title | Content hits | First hit |
|---|---|---:|---:|
| `agents/commit-testing.md` | Agent: Commit Testing | 5 | 3 |
| `agents/coverage-all.md` | Agent: Run Code Coverage for All Projects | 19 | 3 |
| `agents/coverage-annotation.md` | Agent: Run Code Coverage for PineGuard.DataAnnotations | 3 | 3 |
| `agents/coverage-core.md` | Agent: Run Code Coverage for PineGuard.Core | 3 | 3 |
| `agents/coverage-fluent.md` | Agent: Run Code Coverage for PineGuard.FluentValidation | 3 | 3 |
| `agents/coverage-guard.md` | Agent: Run Code Coverage for PineGuard.GuardClauses | 3 | 3 |
| `agents/coverage-must.md` | Agent: Run Code Coverage for PineGuard.MustClauses | 3 | 3 |
| `agents/coverage-testing.md` | Agent: Run Code Coverage for PineGuard.Testing | 4 | 3 |
| `agents/fix-coverage-all.md` | Agent: Fix coverage gaps for All | 4 | 3 |
| `agents/fix-coverage-annotation.md` | Agent: Fix coverage gaps for DataAnnotations | 3 | 3 |
| `agents/fix-coverage-core.md` | Agent: Fix coverage gaps for Core | 3 | 3 |
| `agents/fix-coverage-fluent.md` | Agent: Fix coverage gaps for FluentValidation | 3 | 3 |
| `agents/fix-coverage-guard.md` | Agent: Fix coverage gaps for GuardClauses | 3 | 3 |
| `agents/fix-coverage-must.md` | Agent: Fix coverage gaps for MustClauses | 3 | 3 |
| `agents/fix-coverage-testing.md` | Agent: Fix coverage gaps for Testing | 4 | 3 |
| `agents/fix-test-all.md` | Agent: Fix Unit Tests for All | 4 | 3 |
| `agents/fix-test-annotation.md` | Agent: Fix Unit Tests for DataAnnotations | 3 | 3 |
| `agents/fix-test-core.md` | Agent: Fix Unit Tests for Core | 3 | 3 |
| `agents/fix-test-fluent.md` | Agent: Fix Unit Tests for FluentValidation | 3 | 3 |
| `agents/fix-test-guard.md` | Agent: Fix Unit Tests for GuardClauses | 3 | 3 |
| `agents/fix-test-must.md` | Agent: Fix Unit Tests for MustClauses | 3 | 3 |
| `agents/fix-test-testing.md` | Agent: Fix Unit Tests for Testing | 4 | 3 |
| `agents/format-testing.md` | Agent: Format Code for PineGuard.Testing | 3 | 3 |
| `agents/scan-qodana-testing.md` | Agent: Run JetBrains Qodana for Testing | 3 | 3 |
| `agents/scan-roslyn-testing.md` | Agent: Run Roslyn Compiler Diagnostics for Testing | 3 | 3 |
| `agents/test-all.md` | Agent: Run Unit Tests for All Projects | 21 | 3 |
| `agents/test-annotation.md` | Agent: Run Unit Tests for DataAnnotations | 3 | 3 |
| `agents/test-core.md` | Agent: Run Unit Tests for Core | 3 | 3 |
| `agents/test-fluent.md` | Agent: Run Unit Tests for FluentValidation | 3 | 3 |
| `agents/test-guard.md` | Agent: Run Unit Tests for GuardClauses | 3 | 3 |
| `agents/test-must.md` | Agent: Run Unit Tests for MustClauses | 3 | 3 |
| `agents/test-testing.md` | Agent: Run Unit Tests for Testing | 4 | 3 |

## Skill or exemplar

| Path relative to docs/ai | Title | Content hits | First hit |
|---|---|---:|---:|
| `skills/improve-coverage/SKILL.md` | Skill: Improve Code Coverage | 22 | 1 |
| `skills/scaffold-unit-test/references/README.md` | Reference Files: scaffold-unit-test | 7 | 1 |
| `skills/scaffold-unit-test/SKILL.md` | Skill: Implement Unit Tests | 42 | 1 |

## Testing specification

| Path relative to docs/ai | Title | Content hits | First hit |
|---|---|---:|---:|
| `specs/core/coverage.md` | PineGuard.Core Code Coverage (Addendum) | 19 | 3 |
| `specs/core/unit-test.md` | PineGuard.Core Unit Tests (Addendum) | 41 | 3 |
| `specs/data-annotations/coverage.md` | PineGuard.DataAnnotations Code Coverage (Addendum) | 20 | 3 |
| `specs/data-annotations/unit-test.md` | PineGuard.DataAnnotations Unit Tests (Addendum) | 61 | 3 |
| `specs/fluent-validation/coverage.md` | PineGuard.FluentValidation Code Coverage (Addendum) | 19 | 3 |
| `specs/fluent-validation/unit-test.md` | PineGuard.FluentValidation Unit Tests (Addendum) | 45 | 3 |
| `specs/guard-clauses/coverage.md` | PineGuard.GuardClauses Code Coverage (Addendum) | 19 | 3 |
| `specs/guard-clauses/unit-test.md` | PineGuard.GuardClauses Unit Tests (Addendum) | 34 | 3 |
| `specs/must-clauses/coverage.md` | PineGuard.MustClauses Code Coverage (Addendum) | 19 | 3 |
| `specs/must-clauses/unit-test.md` | PineGuard.MustClauses Unit Tests (Addendum) | 33 | 3 |
| `specs/testing/coverage.md` | PineGuard Code Coverage (Global Spec) | 66 | 3 |
| `specs/testing/fixture.md` | Unified Fixture Architecture v2 | 40 | 3 |
| `specs/testing/gold-standard.md` | GOLD-STANDARD Compliance Index | 38 | 3 |
| `specs/testing/project.md` | PineGuard.Testing Project Spec (Shared Test Infrastructure) | 32 | 3 |
| `specs/testing/unit-test.md` | PineGuard Unit Tests (Global Spec) | 149 | 3 |

## Workflow

| Path relative to docs/ai | Title | Content hits | First hit |
|---|---|---:|---:|
| `workflows/coverage.md` | Workflow: Coverage | 14 | 3 |
| `workflows/fix-coverage.md` | Workflow: Fix Coverage | 13 | 3 |
| `workflows/fix-test.md` | Workflow: Fix Test | 13 | 3 |
| `workflows/test-last.md` | Workflow: Test Last | 9 | 3 |
| `workflows/test.md` | Workflow: Test | 15 | 3 |
| `workflows/verify-coverage.md` | Workflow: Verify Coverage | 24 | 3 |
