# Evaluation scenarios

This file owns acceptance scenarios for future skill execution. The expected decisions below are reviewer material: do not include them in the raw task given to an independent execution model. Use isolated sample repositories, not the user's API or PineGuard working tree.

## Classification and scope

| ID | Raw task / setup | Expected observable result |
|---|---|---|
| S01 | Add coverage to a pure inclusive range predicate with accepted vectors | Typed VIBE cases and meaningful true/false assertions; strong classification |
| S02 | Add tests for explicit null guard and accidental dereference in different methods | Explicit guard receives local-contract test; incidental exception is not promoted to intent |
| S03 | Tax method with no specification | Missing rates/rounding flagged; no invented business expectations |
| S04 | Same method with supplied decision table | Local rule tests generated without recreating BDD scenarios |
| S05 | API/model solution with direct EF access and an early guard | Guard tested; provider path deferred; no new architecture project or blanket exclusion |
| S06 | Simple stub supplies record to mapping logic | Allowed by default if outcome and setup gates pass |
| S07 | Six ordered internal calls with no outward order requirement | Deferred/rejected as brittle; no interaction assertions by default |
| S08 | Required no-payment-command on rejection, collaboration extension enabled | Narrow outward obligation asserted; no distributed exactly-once claim |
| S09 | Same task with legacy --all alias | Same behaviour as --include-interaction-tests, no scope widening |
| S10 | Model auto-properties plus computed value | Computed logic remains in inventory; no whole-model exclusion |
| S11 | Published boundary constant is wrong versus an accepted specification | Independent expected value detects drift; relative fixtures do not hide defect |
| S12 | Mixed method with shared-line instrumentation | Unresolved attribution retained; no silent denominator reduction |
| S13 | Missing spec plus all extensions | Characterization labelled separately; no claim intent has been established |

## Fixtures and platform adapters

| ID | Raw task / setup | Expected observable result |
|---|---|---|
| F01 | One valid case only | Still named fixture-backed parameterized case; other VIBE dimensions assessed |
| F02 | Total clamp accepting every integer | No invented invalid input; outside values valid boundary cases |
| F03 | Two frameworks consume same rule | Same neutral fixture inputs and contract results; native NUnit/xUnit rows |
| F04 | Mutable list supplied to several cases | Fresh list per invocation; order-independent tests |
| F05 | Custom xUnit case record is not serializable | Correct serialization or typed scalar adapter; no blanket warning suppression |
| F06 | NUnit version pinned below an example API | Version mismatch reported; no unreleased API inserted |
| F07 | Null nested inside tuple; inverted guard | Correct member/null/error mapping and explicit inversion |
| F08 | TypeScript undefined, missing field, null | Distinct contract-backed native fixtures; no lossy JSON consolidation |
| F09 | Pester data accidentally initialized in runtime setup | Data available during discovery; self-contained file |
| F10 | Bash matrix and arguments with spaces/globs | Separate discoverable tests, quoted arrays/literals, no eval |
| F11 | Assertion helper omits expected field checks | Helper defect detected; high coverage alone does not pass quality review |

## Coverage and commands

| ID | Raw task / setup | Expected observable result |
|---|---|---|
| C01 | Exact 100/100 counts in nonempty fully reconciled strong scope | Gate passes with denominator, source identity and overall disclosure |
| C02 | Rounded 100% display but one missed raw branch | Gate fails |
| C03 | No tests discovered or no eligible symbols measured | No false success |
| C04 | Branchless method from branch-capable producer | Branch not applicable; supported zero distinguished from unknown |
| C05 | dotCover 100% statements, branch=100 requested | Unsupported branch result, not a green conversion |
| C06 | Pester 100% commands or Bash line trace | Actual metric preserved; no inferred branch percentage |
| C07 | Old and new report files coexist | Only identified current-run evidence used |
| C08 | Different TFM/source revision reports | Separate evidence; no unsafe merged percentage |
| C09 | Uncalled source module missing from report | Inventory reconciliation flags missing measurement |
| C10 | Proposed CompilerGenerated exclusion hides async logic | Rejected or narrowed with evidence; residual retained |
| C11 | --coverage-tool and aliases conflict | Configuration error before dependent edits |
| C12 | Paths contain spaces and command-substitution characters | Literal path/argument handling; no shell execution |
| C13 | Current docs describe unreleased framework APIs | Published stable registry checked; stable compatible API used |
| C14 | --runtime minimum cannot match repository target | Mismatch reported; no automatic retargeting |
| C15 | Coverage skill runs standalone with no TDD manifest | Reports explicit source scope, does not invent strong classification |
| C16 | TDD submits an incompatible handoff schema | Explicit compatibility error; no silent field loss |
| C17 | --suite all combines unit and BDD execution | Suite provenance retained; no claim combined hits are unit-only evidence |
| C18 | Coverage measurement finds failing tests or gaps | Reports failure without modifying test/production code |

## Evaluation procedure

First test deterministic components with synthetic input fixtures. Then run the skill against small compilable sample repositories. Use a separate execution context/model where available and authorized; give only the user request, skill and raw repository. Inspect code, case discovery, actual assertions, exact coverage and report omissions.

Record each result as passed/failed/not-run with artifact evidence. A prose walkthrough is not a passed execution test. Fix observed defects in the owning document or script, then rerun the affected scenarios. Do not claim reliability for a specific model without evaluating that model.

## Architecture extension: contrast cases

For each case, the evaluator must state assertion authority, default classification, observable outcome and remaining boundary evidence. Matching a layer name without explaining the claim is a failure.

| Case | Expected decision |
|---|---|
| DomainService allocates supplied amounts by an accepted decision table | Strong candidate; no blanket service exception |
| The same pure method has only an unexplained threshold in code | Needs specification or explicit characterization; purity is insufficient |
| Application handler receives a faithful stubbed account and returns a policy rejection | Strong local decision; no blanket ban on stubs |
| Same handler test asserts only paymentGateway.Charge was not called | Valuable opt-in collaboration obligation when specified; separate target |
| Aggregate exposes a list of recorded domain events after a command | Can be strong observable output with real members |
| Listener records one ACK call after a fake commit | Opt-in ordering obligation; no durability or delivery claim |
| Two sequential aggregate calls preserve balance | Local history can be strong; does not prove concurrent storage enforcement |
| A repository LINQ predicate passes in a list | Local predicate evidence only; no SQL/provider guarantee |
| Infrastructure helper builds a contract-backed sanitized telemetry record | Strong candidate; does not prove pipeline redaction everywhere |
| Domain project contains only generated DTO properties and port declarations | No runtime padding to reach 100%; inspect scope policy |
| TypeScript class validates a compile-time interface but receives unchecked JSON | Require the actual runtime validation/host evidence; types are insufficient |
| PowerShell retention planner receives metadata and fixed time | Strong if accepted policy is complete; real deletion remains separate |
| Bash function chooses an action but executes rm during source/import | Controlled-execution/setup issue; do not infer purity from helper filename |
| Saga returns next state and command values from supplied event/history | Can be strong; durable distributed workflow remains separate |
| Mixed API file contains both eligible policy and framework effects | Test reachable strong cases, preserve method inventory; current file reporter cannot certify that subset |

Do not treat this answer key as evidence that an independent model has executed the scenarios. New examples need a real future execution evaluation before reliability claims.

## Help and guided entry acceptance cases

- Bare invocation or --help: show concise use cases and stop; no discovery, installation or execution. Help wins over --interactive.
- Interactive with explicit repo/framework: preserve those choices and ask only unresolved fields using the host question tool.
- Default test choice: generated invocation has no interaction flag. Extended choice: contains --include-interaction-tests. No additional test-scope selector exists.
- Silent/preselected asynchronous choice: do not run; wait for an actual response.
- Unsupported requested metrics: explain capability, preserve the request unless the user explicitly changes it.
- Change an upstream answer: retain unrelated choices and re-resolve dependent values.
- Command-only or cancel: no tests, installations or production edits.
- Legacy interaction alias: normalize to the canonical flag in displayed commands.

These are acceptance scenarios, not evidence of a completed live user wizard session.

## Fixture concurrency acceptance cases

| ID | Raw task / setup | Expected observable result |
|---|---|---|
| P01 | Speed up independent Bash VIBE cases on Windows | Retains Bats; routes to WSL2 environment guidance; checks native parallel backend before suggesting bounded jobs |
| P02 | Parallel tests write the same temporary file across two test files | Isolates resources or serializes the affected suite; within-file serialization alone is insufficient |
| P03 | Setup launches a child successfully, but it exits before becoming ready | Setup fails with diagnostics, owned resources are cleaned up, no false test success |
| P04 | Background child fails while the last child succeeds | Individual child failure is propagated; a bare wait is not treated as aggregate evidence |
| P05 | User requests parallel Bats coverage through collect.sh --jobs 4 | Explains unsupported collector argument; uses documented serial collection or separately verified native collection/import |
| P06 | User asks whether removing Bats enables async fixtures | Explains ShellSpec and plain Bash options, separates jobs from background setup, retains Bats unless framework scope changes |
| P07 | Parallel aggregate tests all pass against fake storage | Local outcomes remain local evidence; no race-freedom or concurrent database enforcement claim |

These are future behavioural evaluation cases. Documentation review alone does not count as an executed pass.
