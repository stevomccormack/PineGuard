#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
installer="$ROOT/../test-coverage/install.sh"
[ -f "$installer" ] || { printf '%s\n' 'Install test-coverage beside test-tdd; see INSTALL.md.' >&2; exit 2; }
exec bash "$installer" "$@"
