---
name: test-tdd
description: Build deterministic unit tests with mandatory VIBE fixtures, using TDD for changes or coverage-guided testing for existing code. Classify strong local logic separately from collaboration, infrastructure and unknown intent. Supports C#/.NET with NUnit and xUnit, TypeScript, PowerShell and Bash; .NET/NUnit is the default.
---

# test:tdd
## Entry modes

Resolve [execution modes](../test-coverage/shared/execution.md) before any workflow step. Help stops immediately; interactive gathers choices; dry-run previews without writes; install-only sets up dependencies and stops. These modes must not fall through to test creation or collection.

Read [INSTALL.md](INSTALL.md) for setup and [options](shared/options.md) for supported switches.


Target 100% measured line and branch coverage of explicitly selected strong logic. Use VIBE fixtures in every language. Consume BDD specifications as assertion authority; leave ownership of business scenarios to the BDD suite. Work within existing project structure.

## Read and execute

1. Read [options](shared/options.md) and [tooling](shared/tooling.md). Resolve the invocation, current stable tooling, repository constraints and language adapter.
2. Read [scope](shared/scope.md) and [expectations](shared/expectations.md). Inventory behaviours and assertion authority before pursuing coverage.
   When accepted business policies or state transitions are involved, read [business rules](shared/business-rules.md). Use [architecture](docs/architecture.md) to route by actual layers, DDD concepts, patterns and external boundaries; names do not grant eligibility.
3. Read [workflow](shared/workflow.md), [fixtures](shared/fixtures.md) and [test-cases](shared/test-cases.md). Follow the selected language adapter to generate fixture-backed tests.
4. Read [coverage](shared/coverage.md). Read [exclusions](shared/exclusions.md) before adding, changing or relying on any coverage omission.
5. Consult [test-doubles](shared/test-doubles.md) when controlling dependencies and [examples](shared/examples.md) when classification is uncertain.
6. Complete the [report](shared/report.md). Record partial results and missing capability honestly.

Use the installed companion [test:coverage](../test-coverage/SKILL.md) for collection and JSON/HTML reports. Follow the [coverage handoff](shared/coverage-handoff.md) after each meaningful batch of new tests until the target passes or the remaining gaps have explicit blockers. All orchestration scripts live in that skill and are Bash for macOS, Windows Git Bash and Linux/WSL2, subject to the companion's platform capabilities.

## Language routing

Read only the relevant adapter(s), plus the shared rules above.

| Language | Entry point | Required additional reading |
|---|---|---|
| C#/.NET (default) | [dotnet/testing.md](languages/dotnet/testing.md) | [fixtures](languages/dotnet/fixtures.md), [NUnit](languages/dotnet/nunit.md) or [xUnit](languages/dotnet/xunit.md); [API](languages/dotnet/api.md) for API work; [Coverlet](languages/dotnet/coverlet.md) or [dotCover](languages/dotnet/dotcover.md) for measurement |
| TypeScript | [typescript/testing.md](languages/typescript/testing.md) | Native fixtures and coverage are defined there |
| PowerShell | [powershell/testing.md](languages/powershell/testing.md) | Native fixtures and coverage are defined there |
| Bash | [bash/testing.md](languages/bash/testing.md) | [Concurrency](languages/bash/concurrency.md) for parallel cases, background fixtures or framework alternatives |

## Essential rules

- VIBE means Valid, Invalid, Boundary, Edge. All generated tests use named fixtures and data-driven cases, even one-row tests. No disable switch.
- Unit strength depends on expected-result authority, controlled execution, observable outcomes, setup fidelity, reachability and value. Do not infer it from project/class names.
- Known business rules can make local policy strong in any layer, including domain services and handlers. They do not establish provider, host, concurrency or delivery fidelity. An aggregate or several real local objects can be one unit.
- Default scope includes simple boundary stubs for local outcomes; interaction assertions require `--include-interaction-tests` and a justified contract.
- Unknown business intent stays unknown under `--include-interaction-tests`. `--characterize` labels implementation-only evidence separately.
- Outside the unit target does not mean excluded from coverage. Do not manufacture 100% by removing gaps.
- Tool capability is factual: statement or command coverage cannot be renamed line-and-branch coverage.
- Preserve existing architecture. An API and model project can contain strong logic without creating more production projects.

## Ownership and maintenance

`shared/` owns language-independent rules. `docs/` owns architecture/pattern discovery and boundary-specific examples; it never defines another eligibility policy. `languages/<platform>/` owns syntax, framework APIs and runtime hazards. Collection mechanics live in test:coverage. Language documents may specialize implementation but cannot weaken the shared rules. [sources.md](shared/sources.md) contains provenance; [pineguard.md](research/pineguard.md) records the design reference and deliberate adaptations.

Each rule has one owning file: options = invocation; tooling = freshness; scope = eligibility; expectations = oracle; workflow = execution; fixtures = case architecture; [concurrency](shared/concurrency.md) = parallel isolation and fixture lifecycle; test-cases = case selection; test-doubles = replacement; coverage = metrics; exclusions = omissions; report = evidence. Examples illustrate these rules, not exceptions.

To assess this skill itself, use [evaluation/scenarios.md](evaluation/scenarios.md); [evaluation/results.md](evaluation/results.md) records actual validation and remaining limits. Do not treat documentation checks as proof an executing model will always classify correctly.

Check the companion’s [capabilities](../test-coverage/shared/capabilities.md) before promising a measured target, diff-only gate or report format.

For Bash work on Windows, read [Bash environment](../test-coverage/languages/bash/environment.md) before selecting a runtime. Bats is the framework; Ubuntu WSL2 is the recommended full-suite environment. This preference does not migrate .NET, TypeScript or PowerShell workflows.
