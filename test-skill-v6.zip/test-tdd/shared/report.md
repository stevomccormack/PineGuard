# Report

This file owns completion evidence. Keep one machine-readable source when scripts exist; render the human report from it. Until then, maintain a concise scope/report document alongside actual raw tool artifacts.

## Required evidence

1. Request and resolved options: repository, project, language, runtime, framework, runner, provider/version, mode, extension flags, scope and thresholds.
2. Source/build identity: commit plus dirty-file hashes or equivalent snapshot, target framework/configuration, timestamp and fresh artifact paths.
3. Scope inventory: symbol/behaviour, category, gate evidence, authority, action, measurement mapping and residual.
4. VIBE cases: stable case IDs, category/focus, expected source, not-applicable reasons and deferred specifications.
5. Test execution: commands, exit status, discovered/passed/failed/skipped counts and relevant required checks. Do not imply unrun BDD/integration tests passed.
6. Coverage: exact counts for each supported metric, strong scope and overall measurable scope separately, unsupported metrics, unresolved attribution and all effective exclusions.
7. Changes and handoffs: tests added/changed, authorized production changes, defects found, boundary tests needed, and precise next actions.

## Scope row template

| Symbol / behaviour | Classification | Authority | Planned action | VIBE cases | Measurement / residual |
|---|---|---|---|---|---|
| Qualified operation and source path | strong/mixed/etc. | kind + source location | generate/defer/characterize | IDs or reason | exact map or unresolved |

## Coverage row template

| Scope | Metric | Covered / total | Target | Status |
|---|---|---|---|---|
| Strong selected scope | line | actual counts | requested threshold | pass/gap/unresolved |
| Strong selected scope | branch | actual counts or unsupported | requested threshold | pass/gap/unsupported |
| Overall measurable scope | actual metric name | actual counts | existing repo gate if any | informational or gate outcome |

Report branchless code as not applicable only with a branch-capable producer. Include the number of selected symbols, unresolved mixed symbols and excluded symbols so the denominator is interpretable.

## Completion wording

Use "100% measured line and branch coverage of the listed measurable strong subset" only when its count and inventory checks pass. Task-level completion also requires every requested eligible behaviour to have resolved evidence. If strong methods in mixed files remain unattributable, report "Measurable subset passed; overall requested target unresolved" and list those residuals beside the percentage.

Use "Tests added; coverage target not met" when intent, measurement or execution is unresolved. Use "No eligible code in this scope" for an empty strong inventory. Use "Statement/command coverage measured; branch target unsupported" when that is the available evidence. Characterization is explicitly labelled, not presented as confirmation of business correctness.
