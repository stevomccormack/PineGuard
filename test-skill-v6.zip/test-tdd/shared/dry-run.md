# Dry run

Follow the shared [dry-run contract](../../test-coverage/shared/dry-run.md). Additionally show proposed VIBE fixtures, expected-result authority, local-outcome versus opted-in interaction scope, and cases deferred for missing specifications or integration fidelity. Do not write tests or production code, run tests, or launch the coverage iteration loop. A proposed test inventory is a plan, not proof of coverage.
