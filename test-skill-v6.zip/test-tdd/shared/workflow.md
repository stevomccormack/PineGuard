# Workflow

This file owns execution order and stopping rules. Eligibility is defined in [scope.md](scope.md), not inferred during coverage chasing.

## 1. Inspect and establish a baseline

- Read applicable repository instructions and inspect working-tree changes. Preserve user work.
- Identify requested scope, runtime/compiler targets, projects/modules, package management, test framework, runner, existing test categories, BDD specifications and coverage configuration.
- Inspect existing tests before adding another suite. Reuse framework, assertion library, builders and naming conventions unless they cause a concrete issue.
- Identify exclusions already in attributes, runsettings, project properties and CI commands. Use [exclusions.md](exclusions.md).
- Run the relevant existing test suite and retain failures. When possible collect initial coverage from the intended unit-test set. Do not repair unrelated failures silently.
- If no tests exist, use the language adapter to add compatible test infrastructure within current project boundaries. Do not create production architecture layers to host tests.

## 2. Record a scope inventory

Use the fields in [report.md](report.md). Enumerate candidates across requested files, including uncovered and uncalled types. Coverage reports can omit uninstrumented modules, so a report alone is not the inventory.

Resolve mode and extensions from [options.md](options.md). Audit mode performs inventory and assessment; it may run existing tests and create evidence artifacts, but creates no tests or production changes. Audit is not read-only dry-run: use `--dry-run` when no execution or artifact writes are wanted. Classify behaviours and resolve expectation sources before adding cases. Inventory should be compact enough to maintain, usually one row per method; split only where decisions differ.

## 3. Execute the selected mode

### TDD: a requested change

1. List the required local cases from the supplied behaviour.
2. Add one focused test. Run it and observe the relevant failure.
3. A missing API may initially fail compilation; add the minimal shape and observe an assertion failure where practical. Missing packages, broken fixtures and runner errors are not evidence of the intended red state.
4. Implement the smallest production change that satisfies the requirement, not a hard-coded fixture answer.
5. Run the focused tests; refactor only within authorized scope while keeping them green.
6. Repeat for remaining cases, then inspect coverage for missing executable paths.

Do not change working production code merely to manufacture a red result for a test of already-supported behaviour. Label that test as regression coverage within the change.

### Existing-code coverage

1. Add contract-backed cases through existing entry points.
2. Run them; passing on first run is expected and is not claimed as TDD.
3. Investigate failures against the expectation authority. Fix tests only when wrong; report production defects outside requested implementation scope.
4. Fill uncovered eligible paths using meaningful cases, preserving the inventory.

### Characterization extension

Keep implementation-derived expectations identifiable through existing categories or a clearly named test class and authority entry. Use this mode to preserve legacy behaviour before a requested refactor. Never count it as independently established intent.

## 4. Verify

- Run focused tests during edits, then the affected unit suite and repository-required checks.
- Run available relevant BDD/integration checks when production changes affect their boundary and their setup is within task scope. Report unavailable checks; never imply they passed.
- Read actual fresh coverage evidence using [coverage.md](coverage.md).
- Use [test:coverage](../../test-coverage/SKILL.md) through [coverage-handoff.md](coverage-handoff.md). Measurement returns facts; this workflow retains responsibility for deciding and writing the next test. Read its status and gap records after each new test batch; collect into a fresh run directory.
- For suspicious assertions, inspect a plausible defect they should catch: wrong comparison, removed guard, wrong mapped field, omitted state update. Ensure tests distinguish it.
- Use targeted mutation testing when requested, established in the repository, or materially useful for critical/complex logic. See [test-cases.md](test-cases.md).
- Re-run a fresh process when fixtures or ambient state could affect determinism. Do not repeatedly run unchanged successful checks without a reason.

## 5. Coverage iteration and stopping

For each remaining gap, classify it as missing case, defect, unclear intent, genuine boundary dependence, unreachable source path, or instrumentation problem. Add a test only for a justified reachable case.

After two materially different failed attempts, reassess the cause before retrying. Continue when evidence identifies a concrete fix; stop a specific gap only when a real scope, intent, environment or tool limitation prevents further justified progress. Record the failed approaches and needed next step; continue other gaps. Do not retry the same setup, add sleeps, corrupt private state, or insert exclusions to force completion.

Complete the task with an honest partial result when the target is impossible within scope. A blocker in one item does not block testing other eligible code. Do not claim the target was achieved when tool support or scope attribution is missing.

Produce the report and concrete next actions. Do not claim this skill can guarantee bug freedom, exhaustive input coverage, or identical test generation on repeated agent runs.
