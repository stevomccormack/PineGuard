# Boundary examples

These examples apply [scope.md](scope.md), [expectations.md](expectations.md) and [fixtures.md](fixtures.md). They illustrate decisions; they do not override the rules.

| Situation | Decision | Useful VIBE evidence | Do not do |
|---|---|---|---|
| Explicit public null guard | Strong local contract | Ordinary non-null; prohibited null; meaningful empty distinction | Invent rejection for empty input when only null is rejected |
| Accidental null dereference | Characterization only, or defect against a known contract | Record behaviour only when explicitly requested | Declare NullReferenceException a requirement |
| One-to-one mapping with a clear local contract | Strong regression evidence | Distinct source fields, optional fallback, supported empty values | Set every field to the same sentinel |
| Mapping customer data to a public response | Require field-disclosure authority | Approved exposed/omitted fields | Infer safe disclosure from current mapping |
| Named sorting algorithm | Strong if variant/ordering contract is established | Empty, one, duplicates, extremes; ordered output plus preserved multiset | Assert only that output is ordered |
| Tax formula without rate/rounding specification | Needs specification | List unresolved rate, rounding, negative-input rules | Copy the formula into TestData |
| Tax formula with accepted vectors | Strong local logic | Ordinary amounts, thresholds, rounding ties, applicable extreme values | Duplicate whole BDD purchase scenarios |
| Pure expiry predicate with a supplied instant | Strong | Before, exactly at, after expiry | Read current time inside fixture generation |
| Timer scheduling with actual waiting | Boundary/concurrency | Route scheduling behaviour to appropriate evidence | Sleep until the test usually passes |
| Controller guard before a database call | Strong guard in mixed method | Invalid ID exercising no I/O | Mark entire controller covered or excluded |
| Controller directly executing EF queries | Integration for provider behaviour | Record query/constraint scenarios for the right suite | Mock DbSet and claim SQL compatibility |
| Service gets a record through a simple stub and maps it | Strong if setup/outcome gates pass | Known record, specified missing-record result | Ban it just because a mock library supplies the stub |
| Service test verifies six internal calls in order | Collaboration; normally reject even under extension unless order is a contract | Seek a stable outward result | Freeze current choreography |
| Rejected payment must send no command | Collaboration; eligible with extension and explicit obligation | Rejection state + recorded absence of outward command | Claim distributed exactly-once semantics |
| DI registrations | Composition evidence | Resolve representative services/scopes with real container | Create a mock IServiceProvider to prove registration |
| Pure authorization predicate from approved policy | Strong locally; hosted enforcement separate | Allowed/denied claim combinations | Assume local predicate tests prove middleware enforcement |
| Auto-properties beside a computed total | Trivial properties, strong total if specified | Total calculation cases | Exclude whole model class |
| Source-generated regex implementation | Narrow generated-code exclusion may fit | Test wrapper contract and accepted vectors | Exclude all CompilerGenerated code indiscriminately |
| Impossible private state needed to hit a branch | Unresolved reachability | Explain invariant and residual | Reflection or uninitialized objects to manufacture a pass |
| Production constant defines a legal threshold | Strong with independently established value | At/below/above constant plus a contract check of its value | Let implementation and all expectations drift together |
| Pester reports 100% analyzed commands | Available metric only | VIBE cases and actual command counts | Report 100% branches |
| dotCover reports 100% statements | Available metric only | Actual statement counts; separate branch-capable run if available | Convert to Cobertura and declare branches measured |

## Worked mixed-method decision

An API method rejects a missing ID, loads a database record, computes an amount, writes a change and returns a response. It exists in the API project; the only other production project contains models.

Inventory the guard as local, persistence as integration, amount computation as potentially strong, and any undefined rate as needs-specification. If an existing entry point plus simple stub can exercise the amount calculation, test that outcome. If direct provider calls block it, record a mixed residual. A small extraction may fit an authorized implementation task; tests-only work must not become an architecture migration.

The method can receive useful guard tests without receiving a false whole-method strong designation. If coverage cannot attribute only the eligible portion, report whole-method coverage and unresolved strong attribution. Do not silently remove it from scope.

## Framework-neutral VIBE example

Accepted contract: a range predicate returns true inside inclusive bounds and false outside; reversed bounds are rejected with a specified error.

- Valid: an ordinary value inside the range.
- Invalid: a value outside the supported range returns false; reversed bounds use the error case contract.
- Boundary: at minimum/maximum and one unit outside each.
- Edge: a single-value range; integer extremes where arithmetic is not required; repeated invocation preserves no state.

The fixture owns named inputs. Predicate TestData owns true/false expectations; error TestData owns the specified error. NUnit, xUnit, Vitest, Pester and Bats consume the same logical matrix without sharing framework code.

Do not duplicate a row because it is both Invalid and Boundary. For a clamp that accepts every integer instead of a range validator, outside values are Valid + Boundary; category names follow the contract.
