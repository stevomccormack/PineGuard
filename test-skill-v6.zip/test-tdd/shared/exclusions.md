# Exclusions

This file owns permission to remove items from measurement. **An exclusion does not test code.** Omitting a unit test and omitting a coverage item are separate actions.

## Three actions, three meanings

| Action | Meaning | Typical use |
|---|---|---|
| Defer test generation | This skill does not own the needed evidence | I/O, DI composition, unknown business intent |
| Select strong scope in a derived report | Evaluate the targeted local subset; retain overall evidence | Mixed API/model solution |
| Exclude instrumentation/measurement | The item disappears from that report's denominator | Verified generated code or deliberate established policy |

Default to the first two for weak unit-test areas. Do not add production attributes merely because the strong target is narrower than the application.

## Decision table

| Candidate | Decision |
|---|---|
| Confirmed generated client or generator output with no handwritten logic | Narrow measurement exclusion may be justified; record generator and files |
| Pure auto-properties with no custom behaviour | A compatible auto-property filter may be justified; disclose effect |
| Third-party binaries or the test assembly | Keep outside production coverage scope |
| Composition root | Defer unit tests; retain visibility for composition/integration coverage |
| DTO/model class with custom getters or methods | Do not exclude the whole class |
| Controller containing a guard and I/O | Do not exclude the whole controller |
| Awkward exception path or defensive branch | Keep visible; investigate reachability and supported inputs |
| Existing coverage exclusion | Inspect provenance and hidden logic; report a concern if too broad |
| Unknown intent, many mocks, or costly setup | Not an exclusion justification |
| Compiler-generated async/iterator state machine | Do not blanket-exclude; it can represent handwritten logic |
| Alleged unreachable source path | Record evidence and residual; do not automatically add an attribute |

## Native mechanisms

Attributes, ignore comments, source filters and report selection differ by collector. Language adapters own syntax; this document owns justification. `[IgnoreCoverage]` has no portable meaning. Verify an existing custom marker is recognized by the actual collector. Broad markers can affect other suites and hide future handwritten logic.

For .NET syntax, read [dotnet/exclusions.md](../languages/dotnet/exclusions.md); other platform mechanisms are in their testing adapters.

## Before applying an exclusion

1. Identify the exact symbol/file and independent reason, unrelated to the percentage.
2. Check repository policy and existing session authorization. Routine justified changes within scope need no extra approval ritual; do not change organization-wide gates without authorization.
3. Prefer a narrow configuration for the relevant report over changing production source when that expresses the actual intent.
4. Record before/after item counts and which other reports may be affected.
5. Verify the installed tool recognizes the filter/attribute and that neighbouring handwritten logic remains measured.
6. Add a durable reason and condition for reconsidering it. `--include-interaction-tests` changes none of these requirements.

Never automatically add `CompilerGenerated`, `Obsolete`, controller, model, catch-block, or entire-assembly exclusions. Tool documentation's sample filter lists are syntax examples, not this skill's policy.
