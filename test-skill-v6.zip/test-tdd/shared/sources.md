# Sources

Research checked 2026-09-09. These links support technical facts and methods; the user's preferences define mandatory VIBE, fixtures and scope conventions. Official documentation may move ahead of published releases: verify stable package feeds before using version-specific APIs.

| Subject | Primary source |
|---|---|
| .NET unit-test quality and coverage limits | [Microsoft guidance](https://learn.microsoft.com/en-us/dotnet/core/testing/unit-testing-best-practices) |
| TDD process | [Martin Fowler: TDD](https://martinfowler.com/bliki/TestDrivenDevelopment.html) |
| Test double vocabulary | [Martin Fowler: Test Double](https://martinfowler.com/bliki/TestDouble.html) |
| Dependency-contract evidence | [Martin Fowler: Contract Test](https://martinfowler.com/bliki/ContractTest.html) |
| Coverlet metrics and drivers | [Coverlet repository](https://github.com/coverlet-coverage/coverlet) |
| VSTest collector | [Collector documentation](https://github.com/coverlet-coverage/coverlet/blob/master/Documentation/VSTestIntegration.md) |
| MSBuild collector and filters | [MSBuild documentation](https://github.com/coverlet-coverage/coverlet/blob/master/Documentation/MSBuildIntegration.md) |
| dotCover metric definition | [Basic terms](https://www.jetbrains.com/help/dotcover/dotCover__Basic_Concepts.html) |
| dotCover current CLI | [CLI coverage](https://www.jetbrains.com/help/dotcover/Coverage-Analysis-with-Command-Line-Tool.html) |
| .NET exclusion attribute | [Microsoft API reference](https://learn.microsoft.com/en-us/dotnet/api/system.diagnostics.codeanalysis.excludefromcodecoverageattribute) |
| SDK and target selection | [Microsoft version selection](https://learn.microsoft.com/en-us/dotnet/core/versions/selection) |
| EF provider test fidelity | [EF testing strategy](https://learn.microsoft.com/en-us/ef/core/testing/choosing-a-testing-strategy) |
| NUnit typed case sources | [TestCaseSource](https://docs.nunit.org/articles/nunit/writing-tests/attributes/testcasesource.html) |
| NUnit API changes | [Release notes](https://docs.nunit.org/articles/nunit/release-notes/framework.html) |
| xUnit data and serialization | [xUnit changes](https://xunit.net/docs/getting-started/v3/whats-new) |
| .NET mutation testing | [Stryker.NET](https://stryker-mutator.io/docs/stryker-net/introduction/) |
| TypeScript coverage | [Vitest coverage](https://vitest.dev/guide/coverage) |
| PowerShell fixtures | [Pester data-driven tests](https://pester.dev/docs/usage/data-driven-tests) |
| PowerShell coverage | [Pester coverage](https://pester.dev/docs/usage/code-coverage) |
| Pester current API differences | [v6 migration](https://pester.dev/docs/migrations/v5-to-v6) |
| Bash runner semantics | [bats-core stable docs](https://bats-core.readthedocs.io/en/stable/writing-tests.html) |
| Bash coverage | [kcov](https://github.com/SimonKagstrom/kcov) |
| Existing user design reference | [PineGuard inspection notes](../research/pineguard.md) |

## Published package snapshot

The official NuGet flat-container indexes were queried during this session, excluding prereleases. The latest returned stable versions were NUnit 4.6.1, NUnit3TestAdapter 6.3.0, NUnit.Analyzers 4.14.0, xunit.v3 4.0.0, xunit.runner.visualstudio 4.0.0, Microsoft.NET.Test.Sdk 18.10.0 and coverlet.collector 10.0.1.

This is a dated research result, not a permanently pinned recommendation or a verified compatible tuple. In particular, NUnit documentation included NUnit 5 API changes while the registry's latest stable was 4.6.1. Recheck at implementation time and validate the chosen tuple by execution.

## Architecture extension references — checked 2026-09-10

- [Robert C. Martin: Clean Architecture](https://blog.cleancoder.com/uncle-bob/2012/08/13/the-clean-architecture.html): dependency direction and responsibility boundaries; folder names in this skill are discovery conventions, not a prescribed implementation.
- [Eric Evans: DDD Reference](https://www.domainlanguage.com/wp-content/uploads/2016/05/DDD_Reference_2015-03.pdf): model and context vocabulary. The skill's testing classification is our synthesis, not a DDD coverage rule.
- [EF Core testing strategy](https://learn.microsoft.com/en-us/ef/core/testing/choosing-a-testing-strategy): provider fidelity and tradeoffs of repository test doubles.
- [Mocks Aren't Stubs](https://martinfowler.com/articles/mocksArentStubs.html): state versus interaction evidence; use the skill's explicit scope policy rather than treating a mocking-library name as a classification.
- [OpenTelemetry overview](https://opentelemetry.io/docs/specs/otel/overview/): instrumentation/export/propagation concepts.
- [TypeScript erased types](https://www.typescriptlang.org/docs/handbook/2/basic-types.html): compile-time checking is not runtime payload validation.

Examples of rules and test boundaries in the extension are illustrative design guidance. They do not assert the business policies of PineGuard or CBA.
