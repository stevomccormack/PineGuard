# test:tdd — choose and build useful unit tests

Use this skill to create tests. It uses test:coverage to measure progress and produce JSON/HTML reports.

| What do you want to do? | Choose |
|---|---|
| Build or fix behavior from known requirements | `--mode tdd` |
| Add tests to existing code | `--mode coverage` |
| Identify good test candidates and missing rules first | `--mode audit` |
| Be guided through the choices | `--interactive` |

**Three separate choices:**

- `--scope` says **where to look**: a source path or symbol.
- `--include-interaction-tests` optionally adds **dependency-interaction assertions**.
- `--coverage` says **the measured target for eligible local behavior**.

| Test scope | Meaning |
|---|---|
| No interaction flag — default | Test contract-backed results, state changes, exceptions and exposed event outputs. Simple stubs and real local objects are allowed. |
| `--include-interaction-tests` | Also test specified dependency calls, arguments, counts or ordering. |

Example: “returns a rejection” is a local outcome; “never calls the payment gateway” is an interaction obligation. Neither proves the gateway's real behavior.

The default `--coverage line=100,branch=100` targets the explicitly classified strong local subset, not the whole application. Deferred behavior stays visible. Interaction evidence is reported separately. Mixed-file method percentages cannot yet be certified by the reporter. Unsupported metrics are reported, never silently changed.

```text
$test-tdd --interactive
$test-tdd --mode coverage --nunit --scope "Api/Validation"
$test-tdd --mode tdd --scope CheckoutHandler --include-interaction-tests
```

Other controls: `--repo`, `--project`, `--language`, `--runtime`, `--framework` (or `--nunit` / `--xunit`), `--coverage-tool`, `--coverage`, `--output`. `--characterize` permits labelled legacy-behavior expectations; `--mutation` requests supported mutation analysis. See [all options](options.md) for values and aliases.

VIBE fixtures and meaningful assertions are always required. Known business rules help establish expectations; unknown intent and provider/host behavior are not made testable by a switch.

`--help` takes no value and only displays help. A bare `$test-tdd` also displays help. No test execution or installation occurs in help mode.

Dependency setup: `--install --language csharp` (or typescript/powershell/bash). Add `--dry-run` to list dependencies without installing. For normal testing/reporting, `--dry-run` previews scope, actions and outputs without running them.

Bash tests use Bats. On Windows, Ubuntu WSL2 is recommended for full suites; Git Bash is retained for focused Windows compatibility checks. Resolve the environment before running installation or tests.
