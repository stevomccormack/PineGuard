# Scope

This file owns classification. Use [expectations.md](expectations.md) for assertion authority. Do not use a weighted score: strength on one axis cannot compensate for unknown intent or uncontrolled execution.

## Four descriptive categories

| Category | Includes | Important boundary |
|---|---|---|
| Structural contracts | Explicit guards, null handling, deliberate exceptions, field transformations | A declared return type alone is compiler evidence, not a useful runtime test |
| Algorithms | Calculations, parsing, sorting, formatting, rule evaluation | Pure code can implement the wrong rule |
| Collaboration | Commands, dependency calls, ordering, retries across services | Externally meaningful obligations differ from internal choreography |
| Business intent | Rules, policies, acceptance outcomes | BDD owns scenario intent; supplied rules can be exercised locally |

Categories overlap. Tax calculation is both algorithmic and business-specific. Do not classify all business logic as weak, or all structural code as proven correct.

The classification concerns a testable claim, not a layer, class or pattern. Known business rules can resolve an expectation gap and permit strong local tests in services, handlers, listeners or infrastructure helpers. They cannot compensate for an unfaithful setup or missing provider evidence. Read [business rules](business-rules.md) for the decision table and [architecture](../docs/architecture.md) for discovery guides.

## Mandatory gates

For each method, or distinct behaviour inside a mixed method, answer each question with evidence.

| Gate | Pass | Fail or unknown |
|---|---|---|
| Expected result | Accepted authority or permitted explicit local contract | Ambiguous policy or only the implementation's computed answer |
| Controlled execution | Inputs, state, clock, randomness, culture and dependency outcomes are controlled | Real network, database, wall-clock waiting, scheduler race or ambient mutable state |
| Observable outcome | Value, state, explicit exception, or returned decision is observable through a stable entry point | Reflection into private state or a sequence of internal calls is the only assertion |
| Setup fidelity | Real in-memory objects or simple boundary responses; production logic actually executes | Recreating a database/provider/framework or scripting a collaborator chain |
| Reachability | Publicly valid setup reaches the behaviour, including explicitly supported invalid inputs | Corrupted private state or impossible dependency response is required |
| Value | The assertion protects a contract a compiler/framework does not already enforce | Getter/setter echoes, type declarations, or forwarding without a meaningful obligation |

Stable entry point means a supported method or component boundary, not necessarily a publicly exported API. An existing internal method accessible to the test assembly is acceptable. Avoid making private helpers public just for coverage.

A unit may include several real in-memory objects, an aggregate, or a sequence of operations. Deterministic does not mean stateless. A recorded domain event exposed as an output can satisfy the observable-outcome gate; a spy assertion about dispatch remains a collaboration claim. A meaningful outward-obligation test may be valuable even when excluded from the default strong coverage target. That exclusion is scope policy, not a declaration that the test is inherently brittle.

## Ordered decision procedure

1. Identify the exact behaviour and expected result source. Split mixed responsibilities in the inventory without changing production code yet.
2. If intent is unknown, mark `needs-specification`. Continue other behaviours. With `--characterize`, current behaviour may instead receive separate characterization evidence.
3. If correctness depends on a real provider, host, transport, container or scheduler, mark `integration`. Extracted local decisions can have separate entries.
4. If the only observation is a dependency interaction, mark `collaboration`. Default: defer. With `--include-interaction-tests`, require a documented outward obligation and follow [test-doubles.md](test-doubles.md).
5. If there is no meaningful runtime contract, mark `trivial`. Generated code is `generated` only with provenance.
6. If all gates pass, mark `strong`. Simple stub input does not automatically make it collaboration-heavy.
7. If some gates pass but setup or measurement cannot isolate them, mark `mixed`. Test reachable strong cases; retain the residual instead of claiming the whole method is strong.

## Classification outcomes

| Outcome | Default action | Counts in strong target? |
|---|---|---|
| strong | Generate and verify local tests | Yes |
| mixed | Test reachable strong behaviour; identify residual | Only precisely attributable strong coverage items |
| collaboration | Defer; reconsider under `--include-interaction-tests` | No; report separately even when tested |
| integration | Record required boundary evidence | No |
| needs-specification | Identify the exact unanswered rule | Unresolved inventory; never silently disappear |
| characterization | Preserve observed behaviour in explicit mode | Separate from contract-backed strong target |
| trivial / generated | Skip generation; assess measurement policy separately | No |

Inventory before coverage iteration. Keep eligible items that are difficult to cover in scope. A discovered classification mistake can be corrected with a reason and before/after denominator; low coverage is not a reason.

Critical code receives priority, not relaxed gates. Authorization logic may be strong locally with a supplied policy, while HTTP enforcement still requires host-level tests. Report missing boundary evidence prominently; do not assume a BDD suite covers it.

## Keep these axes separate

The six gates decide whether a claim has trustworthy unit evidence. The interaction opt-in is a scope preference, not an assertion that all interaction tests are technically weak. An ordinary stub supplies input facts; a spy supplies evidence about an outward obligation. Classify the assertion, not the mocking-library import.

| Concrete test claim | Default decision | Why |
|---|---|---|
| Given stored balance 20, withdrawal 25 returns the documented rejection | Strong if remaining gates pass | Simple balance stub; accepted rule; observable local result |
| Rejected withdrawal never calls the debit port | Interaction opt-in | Valuable negative obligation; requires explicit contract |
| Both concurrent withdrawals cannot commit | Integration | Serial stubs cannot reproduce transaction isolation |
| Given fixed time, token-expiry policy rejects exactly at expiry | Strong with an accepted inclusivity rule | Time is controlled input; boundary fixture has independent authority |
| HTTP pipeline rejects that expired token | Host/integration | Calling the policy cannot prove middleware wiring |
| Log payload excludes a prohibited personal-data field | Strong when testing an existing pure payload builder with a contract | Observable mapping; do not invent a builder just to reclassify a logging test |

Low maintenance comes from assertions on stable contracts, fresh fixture state and minimal setup. Purity alone does not guarantee it: snapshots of large incidental object shapes and copied algorithms remain poor oracles. Runtime/compiler contracts do not need redundant tests simply to fill a taxonomy category.
