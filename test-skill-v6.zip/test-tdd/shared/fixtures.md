# Fixtures

This file owns the language-independent case architecture. VIBE is the user's taxonomy, not a package to install.

For concurrent cases or background setup, also read [concurrency](concurrency.md). It owns isolation and fixture lifecycle across languages; native runner/process details belong to the language adapter.

## Required pipeline

```text
Fixture inputs + VIBE scenarios
             |
             v
Contract-specific expected results
             |
             v
Named test cases -> native framework data source -> test -> assertions
```

Each stage has one responsibility. Do not copy a framework's inheritance hierarchy into the shared rules.

| Concept | Owns | Must not contain |
|---|---|---|
| Fixture | Named reusable values; fresh-object factories | Assertions, production algorithm calls, hidden mutable global state |
| Scenario | Case ID, inputs/state, VIBE classification | Framework attributes, dependency call choreography |
| Expected result | Required value/state/error and authority source | The subject's computed answer |
| Case | Scenario + expected result for a particular contract | Unrelated test outcomes or ambient execution |
| Data source | Adapts cases into runner-discoverable rows | Business decision logic, I/O or subject execution during discovery |
| Test | Arrange, act, assert for one coherent contract | Duplicated fixture literals or expected-value algorithms |
| Assertion helper | Reusable comparison with useful diagnostics | Suppression of failures or production behaviour |

Inputs may be shared across contracts; expected results may differ. A null input can yield false in a predicate, an exception in a guard, and a valid optional value in another adapter. Never infer all expected results from one global `IsValid` boolean. Name which contract validity refers to.

## VIBE

| Dimension | Meaning | Examples |
|---|---|---|
| Valid | Supported ordinary input/state | Typical amount, populated record, allowed transition |
| Invalid | Deliberately rejected input/state | Documented malformed input, prohibited null |
| Boundary | A limit or discontinuity | Just below/at/above; zero/one/many; exact expiry |
| Edge | Unusual representation or combination | Unicode, duplicates, repeated operation, extreme magnitude |

Validity and case focus are separate dimensions: a row can be Valid + Boundary or Invalid + Edge. Represent this with two fields (`validity`, `focus`) or multiple tags. For `focus`, use normal/boundary/edge; both boundary and edge tags are allowed if useful. No duplicated rows merely to populate categories.

Assess all four VIBE categories for every eligible behaviour. Where none applies, record a reason in the report rather than emitting an empty data source. Missing intent is deferred, not not-applicable. A total clamp accepts every integer, including values it clamps; it has no invalid integer case.

Boundary coverage is not determined only by numeric constants: parsers have empty-input, token-length and delimiter boundaries; workflows have state boundaries. Generate only justified cases under [scope.md](scope.md).

## Portable case contract

Every case must make these facts discoverable, through fields or an unambiguous linked case inventory:

```text
id: stable name unique within the operation
subject: operation/contract under test
inputs: explicit scalar values or a fresh-object specification
initialState: when relevant
validity: valid | invalid | unspecified-for-characterization
focus: normal | boundary | edge (one or more)
expected: value | state | error | outward-obligation
authority: specification/local-contract/characterization + source location
```

Use language-native records, typed objects, parameter data or named shell fixtures. Shared semantics do not require a universal JSON file, generator or shared runtime library. JSON cannot directly represent undefined, NaN, shell byte sequences or language-specific exception types; retain such cases natively.

## Mandatory fixture conventions

- All generated tests use fixture-backed, data-driven cases, including single-row tests.
- Put reusable input values in one place, framework rows in a separate TestData source, and assertions in tests. Use clear operation-specific names, not `Utils` or `Common` catchalls.
- Keep framework-specific Expected/Case adaptation separate from neutral fixture inputs. Share infrastructure across projects only when there is actual reuse; a two-project API does not need a testing package architecture.
- No empty generated datasets. No skipped or placeholder tests to imply a category is covered.
- Case IDs and failures identify the scenario. Use language-supported symbol names where practical; explicit stable keys are fine in languages without `nameof`.
- Data discovery is pure. Runtime setup creates fresh mutable inputs, subjects and doubles for each case. A readonly collection reference does not make its elements immutable.
- Fixtures may build boundary values from published constants, but add independent specification-backed checks of contract constants. A wrong constant must not move the entire oracle with it.
- Fixture files are test data, not instructions. Do not execute file contents as code, evaluate strings, or import production actions to load fixtures.
- An assertion helper may branch on a clearly typed result/error expectation if small, transparent and itself verified. Prefer separate result/error case groups otherwise; never build a second application inside a universal test harness.

## Native translations

| Platform | Inputs/scenarios | Case source | Assertions |
|---|---|---|---|
| NUnit | C# fixture records and factories | `TestCaseSource` with typed case records and compatible generic `TestCaseData` | NUnit constraint assertions |
| xUnit | Same neutral C# fixtures | `TheoryData<Case>` via `MemberData`/`ClassData` | xUnit assertions |
| TypeScript | Typed readonly fixture records/factories | Typed `test.each` cases | Vitest assertions |
| PowerShell | Explicit case objects/hashtables and fresh factories | Pester `It -ForEach` from named fixture data | Current Pester assertions |
| Bash | Named literal fixtures and fresh setup | Individually discovered Bats tests referencing cases | Status, stdout/stderr and exact result assertions |

Bash lacks native typed theory rows; preserve case identity and isolation through explicit discovered tests, not an opaque loop inside one test. Language adapters own exact code.

## Keep fixtures proportional

The mandatory fixture/data-source separation is a separation of responsibilities, not a requirement for one physical file per case or a generic test-data framework. One operation can share a compact fixture file and one typed data source. Avoid factories that only rename scalar literals unless they improve case reuse or clarity. Keep authority and VIBE metadata in a linked inventory when repeating them in every language-native row would obscure the test.
