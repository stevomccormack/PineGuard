# Expectations

This file owns the test oracle: why an assertion's expected answer should be believed.

## Authority order

1. The user's current explicit requirement and accepted examples.
2. Versioned BDD specifications, API/domain contracts, decision tables or reference vectors applicable to this change.
3. Existing maintained contract tests and documentation consistent with those requirements.
4. Explicit local contracts in the code, limited as below.
5. Observed implementation behaviour, only in characterization mode.

A contradiction is not resolved by choosing whichever makes tests pass. Identify it, continue independent work, and request the missing decision only for affected behaviour. A test or comment can be stale. Record a precise source location, not merely "business rules".

For turning an accepted policy into local decisions, state histories and boundary residuals, use [business rules](business-rules.md). Authority can come from accepted requirements without a BDD implementation. A BDD suite's presence alone does not establish that a particular rule, environment or integration boundary is covered.

## What code alone can support

A deliberate `ArgumentNullException.ThrowIfNull(request)` supports a regression test that null is rejected. An explicit null fallback supports recording that fallback as a local contract. Label authority `local-contract`: it preserves a deliberate implemented contract, not independently validated business intent.

Do not promote incidental behaviour to a contract: a dereference causing `NullReferenceException`, enumeration order from an unspecified collection, culture from the executing machine, or an exception message from a framework version.

The distinction is semantic, not syntactic. `if (amount >= 100)` does not independently establish a discount policy. An explicit exception for a business threshold still needs policy authority. A clear one-to-one projection can support a mapping regression test, but does not prove fields are sufficient or safe for the external API. Security-sensitive field selection requires an approved contract.

Code-only calculations and mappings without a defensible local contract are characterization, not default strong evidence. Keep code-derived expectations visible in the report.

## Independent algorithm expectations

- Use accepted worked examples with literal expected results.
- Use an established specification or reference vectors for a named algorithm, after confirming the implementation intends that variant.
- Use justified properties: sorting preserves the multiset and produces ordered output; a clamp stays in range and fixes values already in range.
- Pair round-trip or idempotence properties with known examples. Two mutually incorrect functions can round-trip; a function returning a constant can be idempotent.
- Never compute expected values by calling the production method, copying its branch structure, or snapshotting its output and presenting it as verified truth.
- Numeric rounding, overflow, negative values, culture, timezone, inclusivity, missing values and ordering can be policy choices. Do not guess them from names.

## BDD handoff

Consume the BDD suite's scenario IDs, accepted examples and rules. Unit tests add local boundaries and failure cases without duplicating entire end-to-end scenarios. BDD is an approach to specifying behaviour, not a guarantee that tests exercise a real database or HTTP pipeline.

If intent is missing, record: symbol; input/state; competing plausible expected outcomes; specification needed; affected tests deferred. No requirement to invoke or install a particular BDD skill. Use one if available and appropriate to the user's task.

If current code contradicts accepted intent, a failing test is useful evidence. In TDD bug-fix scope, fix it. In tests-only scope, report it without weakening the assertion or silently changing production behaviour. Characterization must not legitimize a known defect.
