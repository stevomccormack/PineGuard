# Concurrency

This file owns language-independent fixture concurrency and lifecycle rules. [Fixtures](fixtures.md) owns VIBE and case identity; language adapters own runner options and process handling. Read this when running cases concurrently or arranging background activity.

## Identify the claim

| Request | Meaning | Testing decision |
|---|---|---|
| Run VIBE cases concurrently | Independent cases overlap to shorten the suite | Preserve separate discovery, assertions and outcomes; assess isolation before enabling |
| Prepare a fixture asynchronously | Runtime setup awaits work or starts a background resource | Await completion or readiness before the act phase; track failures and resource ownership |
| Test concurrent production behaviour | Ordering, races, cancellation or competing updates are the subject | Apply the normal strength gates to the exact claim; parallel runner execution does not prove concurrency correctness |

Concurrency is an execution choice, not another VIBE category or permission to include interaction assertions. Known business rules establish expected decisions; they do not prove scheduler, database or message-delivery fidelity.

## Independent cases

- Keep data discovery pure and deterministic. Awaited runtime setup does not justify starting services, doing I/O or executing the subject while discovering cases.
- Give each case fresh mutable inputs, subjects and doubles. Share expensive immutable data only where the runner's fixture lifetime and actual immutability permit it. A readonly reference does not freeze its contents.
- Isolate resources that cross a test's process or object boundary: files, databases, ports, environment settings and output locations. A unique test name alone is not isolation. If a dependency cannot be isolated, serialize the affected group explicitly and record why.
- Use bounded concurrency appropriate to the host and resource demand. Verify the same case inventory and expected outcomes as the serial run. Repeat initial parallel validation to expose order dependence; successful repetition is evidence, not proof against races.
- Keep a result for every discovered case and propagate every failure. Faster completion cannot justify dropping cases, suppressing failures or weakening assertions. Do not retry failed cases merely to obtain a green gate.

## Background fixture lifecycle

1. Allocate case-owned resources during runtime setup. Record handles or process IDs immediately and arrange cleanup before any later operation can fail.
2. Await a readiness signal with a bounded deadline, while checking for early failure. An arbitrary fixed sleep or a successful launch is not a readiness check.
3. Perform the test only after readiness. Assert the contract's observable result; do not substitute setup success for the result.
4. Observe background failures and join or await finite work. Distinguish expected cancellation of a long-lived fixture during teardown from unexpected early exit.
5. Clean up owned resources after success, assertion failure, timeout and partial setup. Preserve the original failure and report cleanup failure too; do not target unrelated processes or resources.

Cancellation and signal behaviour need language/platform-specific handling. No ordinary teardown can guarantee cleanup after forceful process or machine termination; choose resource lifetimes that make that limit manageable.

## Strength boundary

A pure policy deciding whether to retry, given supplied outcomes and a supplied attempt count, can remain strong. A real background service listening on a socket establishes a different, boundary-dependent claim. An async API is not automatically weak if execution and results are controllable, but mocked scheduling does not establish real race freedom. Use existing integration/BDD ownership for claims requiring those systems.

Performance and coverage are separate observations. Measure comparable source, cases and environments; the coverage adapter must establish whether concurrent execution is collected completely before its results support a gate.
