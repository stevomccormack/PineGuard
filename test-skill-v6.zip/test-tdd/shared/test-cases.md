# Test cases

This file owns case selection and assertion quality. Apply only cases relevant to the contract; this is not a requirement to multiply every dimension into a Cartesian product.

## Case selection

| Behaviour | Cases to consider | Assertions |
|---|---|---|
| Guard / null fallback | Rejected input, accepted input, fallback input | Exact contract exception type, parameter name if specified, or fallback value |
| Numeric boundary | Below, at, above; zero; negative; max/min when supported | Literal/reference result, specified rounding and overflow |
| Boolean decision | Each outcome; each independent clause; short-circuit cases | Decision or resulting state, not just no exception |
| Collection | Empty, one, many; duplicates; order; missing elements | Contents and specified ordering/cardinality |
| Mapping | Distinct source values; optional values; explicit conversion/fallback | Each meaningful target value; no shared sentinels that hide swapped fields |
| Parsing / formatting | Valid, malformed, empty; culture; whitespace; Unicode if supported | Exact specified output or deliberate error |
| State transition | Allowed and disallowed states; repeat action; boundary state | New state, preserved invariants, specified rejection |
| Async local logic | Completed result, specified fault, controlled cancellation | Awaited value/exception/state; never fire-and-forget |
| Lazy sequence | Enumerate to execute; early exit/disposal when part of contract | Materialized result or required resource outcome |
| Retry / schedule policy | First attempt, limit, eligible/ineligible error, boundary time | Returned decision/delay; no actual waiting |

Do not demand an exception for null simply because a parameter is nullable or non-nullable. Nullable annotations do not enforce runtime checks. Do not test framework exception-message text unless it is explicitly your contract.

## Determinism controls

Use fixed inputs and isolated instances. Supply time and randomness through existing parameters or supported abstractions. A fixed seed must be reported with a property-test failure; retain the shrunk counterexample as a regression case. Avoid dependencies on hash iteration order or runtime-specific random sequences.

Prefer explicit culture/timezone arguments. If testing code using ambient culture, scope and restore the value and assess parallel interference. Avoid changing process-wide environment or static state when a local input works. Use controlled task completion/schedulers for local async behaviour; real race outcomes are outside the strong gate.

An arbitrary delay does not make an async test deterministic. Tests must not depend on the test execution order. Fixed GUIDs and named boundary values are preferable to fresh random fixtures when randomness adds no test value.

## Assertions that carry evidence

- Test real production logic; never mock the subject under test or replace its private algorithm.
- Assert the full relevant result, not merely non-null, successful completion, or output type.
- For a guard whose success contract returns the supplied value, assert that passthrough result as well as exercising the failure contract.
- Test the negative path as well as the happy path where the contract distinguishes them.
- Choose fixtures that expose likely mistakes: differing names/IDs for a mapping; a nonzero amount for rate calculations; an exact threshold for comparisons.
- Prefer one coherent behaviour per test. Multiple assertions on the same mapped result or state transition are reasonable.
- Use fixture-backed cases for every test as required by [fixtures.md](fixtures.md); group rows with parallel setup and behaviour. Avoid a large test with its own conditionals to derive expectations.
- Test private logic through its caller. Testing several real classes together is still acceptable local testing when the gates pass.
- Snapshots are useful for intentionally stable, reviewable large outputs; not a default replacement for specifying expected fields.

## Coverage is a case-finding aid

Short-circuit conditions, ternaries, switches, coalescing, exception filters, loops and early returns can expose gaps. Inspect the tool's actual branch model. Branch coverage is not path coverage or modified condition/decision coverage. Exception paths need deliberate tests even when the coverage tool does not expose them as branch items.

For finite decision tables, cover every specified row. For large/infinite spaces, use partitions, boundaries and justified properties; never claim exhaustive testing.

## Mutation testing

A compatible mutation tool can check whether tests detect introduced changes. Run a bounded subset of critical eligible logic, using compatible repository tooling. Investigate surviving mutants: weak assertions, missing cases, equivalent changes, and out-of-scope changes have different meanings. Timeout or compile-error mutants are not straightforward evidence of assertion strength. Do not impose 100% mutation score or alter production code merely to kill an equivalent mutant.

Use the selected language adapter for the mutation tool. Do not imply a mutation framework is available for every language.
