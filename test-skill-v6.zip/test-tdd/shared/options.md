# Options

This file owns invocation semantics. These are agent instructions, not an implemented command-line program. Do not pass them directly to test runners.

## Supported switches

| Switch | Allowed values | Meaning / default |
|---|---|---|
| `--help` | Flag; no value | Display concise help/use cases and stop; takes precedence over execution options |
| `--install` | Flag; no value | Check/install skill dependencies, then stop; see [INSTALL.md](../INSTALL.md) |
| `--dry-run` | Flag; no value | Preview the selected workflow without writes or execution |
| `--interactive` | Flag; no value | Guide configuration through structured questions; supplied switches prefill choices |
| `--language` | `csharp`, `typescript`, `powershell`, `bash` | Infer from scoped code; if unspecified and no code is available, default C# |
| `--runtime` (alias `--version`) | Exact runtime target or minimum, e.g. `dotnet8.0`, `dotnet8.0+`, `node24+`, `powershell7.4+`, `bash5+` | Runtime compatibility constraint; not a package, language compiler version or wildcard passed to a runner |
| `--framework` | `nunit`, `xunit`, `vitest`, `pester`, `bats` | Reuse relevant established framework; default NUnit for new .NET work |
| `--nunit` / `--xunit` | Flag | Shorthand for `--framework nunit` / `--framework xunit` |
| `--mode` | `tdd`, `coverage`, `audit` | Infer `tdd` for requested features/fixes; otherwise `coverage`. `audit` classifies and reports without generating tests or changing production code |
| `--repo` | Repository directory | Default current repository; resolve before file inspection or command execution |
| `--project` | Project/module/package path inside the repository | Select a build/test unit; language adapter defines the native meaning |
| `--scope` | Quoted repository path, symbol, or list stated in the prompt | Limit subject code. Infer from requested change; whole repository only if requested |
| `--coverage-tool` | `auto`, `coverlet`, `dotcover`, `v8`, `istanbul`, `pester`, `kcov` | Select a compatible collector. Default Coverlet for .NET, V8 for Vitest, Pester for PowerShell; Bash collection only when supported setup exists |
| `--coverage` | `line=100,branch=100` or another explicit metric map | Required metrics and thresholds; default line=100,branch=100. `100%` is shorthand for that default metric pair |
| `--coverlet` / `--dotcover` | Flag | Alias for the corresponding `--coverage-tool`; reject conflicting provider selections |
| `--include-interaction-tests` | Flag; no value | Also consider specified dependency calls, arguments, counts and ordering. Without it, generate eligible local-outcome tests only. Report interaction evidence separately |
| `--include-collaboration` / `--all` | Legacy flags | Compatibility aliases for --include-interaction-tests; show the canonical spelling in generated commands |
| `--characterize` | Flag | Also permit explicitly labelled current-behaviour cases; does not override known intended behaviour |
| `--mutation` | Flag | Run bounded mutation analysis of eligible logic when supported; report missing capability |
| `--output` | Artifact directory | Default a fresh run directory under repository artifacts; preserve existing outputs |

VIBE, fixtures, meaningful assertions and honest reporting are always required. Do not add flags for disabling these. `--include-interaction-tests` changes eligibility consideration only: it does not widen paths, supply intent, grant infrastructure access, allow exclusions or migrate frameworks.

## Resolution

1. Explicit choices override inferred defaults. Conflicting aliases or incompatible pairs (e.g. Bash + NUnit) require a correction before dependent work; continue inventory meanwhile.
2. Read project/package/runtime manifests and lockfiles. Language selection does not migrate languages; framework selection does not authorize bulk conversion of existing tests.
3. A version ending in `+` is a minimum over relevant existing targets. For `dotnet8.0+`, select qualifying .NET targets; do not write that text into a TFM or upgrade the project. With no qualifying target, report mismatch.
4. Distinguish runtime, SDK/compiler and test-framework versions. Record all resolved versions, the actual target(s), runner and provider. Use [tooling.md](tooling.md) for current stable selection and existing constraints.
5. Coverage values must be numeric percentages from 0 through 100, without duplicate metric keys. Accept line/branch/statement/command only where declared by the adapter. A request for a lower target changes the completion threshold only when explicit; retain 100/100 as the default strong target. Unknown metrics and unsupported requested metrics are reported, never mapped to a different metric. A shell branch request remains unsupported even if all known decisions have VIBE cases.
6. In a mixed-language request, resolve each language independently; do not let a .NET default leak into PowerShell. Reuse shared case concepts, not runtime-specific code.
7. `--scope` is interpreted and confirmed by inventory, not evaluated as shell text. Resolve paths inside the requested repository. Never interpolate user expressions into executable commands.
8. `--characterize` with TDD only adds regression evidence for surrounding legacy behaviour; new functionality still needs intent. In audit mode it classifies potential characterization work without writing tests.

## Examples

```text
$test-tdd --language csharp --runtime dotnet8.0+ --nunit --mode coverage --scope "src/Api/Validation"
$test-tdd --language csharp --xunit --mode tdd --scope PriceCalculator
$test-tdd --language typescript --framework vitest --coverage-tool v8 --mode coverage
$test-tdd --language powershell --framework pester --mode coverage --scope tools/parsing
$test-tdd --language bash --framework bats --mode audit --scope tools
$test-tdd --nunit --mode coverage --include-interaction-tests --characterize --scope LegacyService
```

Precedence: explicit invocation > an explicit task profile > relevant repository configuration > documented defaults. Do not silently accept duplicate contradictory options. `--repo` and `--output` are filesystem paths, not shell fragments; `--project` is resolved relative to the repository.

Project translation: a .NET `.csproj`/solution member, a TypeScript workspace package, a PowerShell module/script group, or a Bash library/tool directory. Resolve the corresponding executable tests through project references/manifests or an explicit repository registry. A test-support library with no test methods is not a runnable test suite. Keep source selection and test selection separate in the resolved configuration.

No `--latest` switch: current stable methods are the default requirement. No minimum model intelligence switch: the rules and examples must be explicit enough for a capable execution model.

## Entry modes and scope selection

A bare skill invocation with no task/options displays help. --help takes no argument, reads help.md and stops before repository discovery, installation or execution, including when combined with --interactive or other switches. --interactive follows interactive.md using the host's structured question tool; it is not a shell prompt script. Ordinary invocations still run directly without the wizard.

--scope selects where to look. Without --include-interaction-tests, consider eligible local outcomes: results, state, exceptions and exposed event outputs. The flag additionally considers specified dependency interactions. --coverage sets the measured target for the classified local subset; interaction evidence remains separate. No flag certifies that a whole folder is strong. Existing mixed-file attribution limits remain.

Resolve both legacy aliases to --include-interaction-tests. Characterization stays separate under --characterize. Emit only the canonical interaction flag in generated commands. There is no inverse flag: omitting it keeps the default local-outcome scope.

Help and interaction presentations are in [help](help.md) and [interactive](interactive.md). Skill switches are instructions to the agent; do not pass --include-interaction-tests or its aliases to test:coverage scripts.

See [current capabilities](../../test-coverage/shared/capabilities.md) before proposing diff selection, report format or browser-opening options.
