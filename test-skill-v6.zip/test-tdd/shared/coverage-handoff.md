# Coverage handoff

This file owns the test-generation loop. [test:coverage](../../test-coverage/SKILL.md) owns the manifest, scripts, parsers, reports and gate statuses.

1. Classify candidate methods using scope.md and record assertion authority. Keep weak, mixed and unknown-intent cases visible in the TDD inventory.
2. Build the reporter's explicit whole-file manifest only for files wholly eligible for the strong target. Keep mixed-file strong methods in the inventory as attribution blockers; still write their justified tests without claiming their isolated percentage.
3. Translate skill switches to the companion's actual script options. Resolve runtime constraints to one TFM. Choose the existing unit-test project and inspect runner, exclusions and source mappings. Do not mix BDD execution into unit coverage evidence.
4. Invoke its Bash collector into a fresh output directory. Read coverage.json, including status, tests, capabilities, missingFiles, conflicts and gaps; retain the HTML path.
5. For each actual metric gap, check expected-result authority and reachability, then add the smallest meaningful fixture-backed VIBE case. A coverage location is not a requirement. Reuse shared fixtures and native typed case adapters.
6. Run focused tests. After a meaningful batch, collect again with unchanged scope and target. Compare exact counts and source identity. A new classification fact may legitimately change scope, but record the reason and restart the baseline; never silently shrink it.
7. Continue until the requested supported metrics pass, or every remaining gap has an explicit blocker under workflow.md. Do not retry unchanged failed setups. Unsupported metrics, missing files, ambiguous attribution, zero tests and failed tests are evidence problems, not invitations to fabricate tests or exclusions.
8. Report the achieved strong-scope counters, deferred methods and reasons, BDD handoffs, assertion quality checks and both JSON/HTML paths. A scoped pass is not project-wide 100%.

The current companion implements file-scoped reports. It does not yet certify method-only scope in mixed files or scoped dotCover statement coverage. Preserve these limits rather than claiming the broader design is already automated. Its PLAN.md owns measurement improvements.

When installed separately, obtain the companion skill before this coverage-driven loop; ordinary TDD red/green work can still use the project's native test command. Never invent an unavailable tool call.

## Completion across the full requested inventory

A passing file manifest is only a measurable-subset pass. If the requested strong inventory also contains mixed-file strong methods, missing instrumentation or unresolved rules, the overall task remains partial. Report both facts: measurable subset counters, and remaining requested inventory with reasons. Never omit those methods from the task-level status because they cannot enter the reporter's file manifest.

Run the intended local-outcome unit suite for the strong gate. Do not combine BDD, integration, characterization or opt-in interaction runs and present their combined hits as evidence produced by strong tests. A `suite` label in a manifest does not filter the runner. The convenience collector executes the selected project/package/test path; when categories share that suite, use a repository-supported native filter and import its matching fresh report, or report suite attribution unresolved. Preserve separate interaction/characterization results.
