# Coverage

This file owns measurement and completion claims. Scope eligibility is in [scope.md](scope.md); exclusion decisions are in [exclusions.md](exclusions.md).

## Target

Pursue **100% measured executable lines and 100% measured branches for the explicitly inventoried strong scope**, using the designated unit-test run. Also report whole production-scope coverage and unresolved/mixed items. Do not infer correctness or all-input coverage from this target.

There are three separate inventories:

1. **Requested production scope:** all relevant source symbols, including uninstrumented ones.
2. **Strong scope:** behaviours passing the classification gates, mapped to measurable symbols/items.
3. **Measurement exclusions:** items omitted by tools or explicit policy, with recorded reasons.

Never collapse these into one filter list.

## Exact completion rules

- Count covered and total items. `covered == total` determines 100%; rounded display percentages do not.
- No executable lines means `not applicable`, not an accomplished 100% target. An empty eligible scope is not success.
- A branchless method has branch coverage `not applicable (0 branches)` only when a branch-capable tool has confirmed zero. A tool without branch capability means `unsupported`, never zero.
- Every inventoried strong symbol must appear in measurement, or have an explained non-executable representation. Missing symbols, PDBs, reports, tests, or aborted runs are not zero-work success.
- A whole-scope total is based on the explicitly listed production scope under disclosed existing exclusions. If attributes prevent truly raw totals, label it "overall measurable coverage" and list omitted items.
- Keep unit-only evidence separate from merged BDD/integration evidence. Other suites executing a line do not prove the unit suite exercised it.
- Preserve target framework, configuration, tool version and source revision. Do not merge stale runs, different source builds or different tool metrics. Report framework/configuration variants separately; optionally aggregate only with a justified identity model.

## Mapping eligible code

Prefer whole-method or whole-type scope when it corresponds to the behaviour classification. A mixed method may contain eligible guards and ineligible I/O. Identify the strong behaviour without declaring every instruction in its method eligible.

If the report can precisely attribute its executable lines and branches, use an explicit mapping of source symbol, lines and branch identifiers tied to the current build. Recompute after edits; line numbers alone are unstable. Branch IDs are tool/build-specific.

If a line or branch belongs to both eligible and boundary behaviour, do not claim a clean split. Report the method as mixed and show whole-method measurement alongside behaviour cases. Mark strong coverage attribution unresolved for that item; do not exclude the mixed item from the inventory to declare completion.

Do not approximate method-specific eligibility with broad namespace filters. A collector's type/file filters may not support arbitrary methods or branches. Use sufficiently detailed reports and verified aggregation if native filtering cannot represent the inventory. Report inability to compute the requested scope when evidence is insufficient.

When writing an aggregator, test it against known counts including uncovered items, empty scope, branchless code, overloaded methods, duplicate runs and missing symbols before trusting its gate. Define unique identities for lines and branch points; do not average percentages or add duplicate denominators. Do not infer denominators from only covered rows.

## Coverage gap triage

| Gap | Action |
|---|---|
| Reachable untested strong path | Add a meaningful VIBE fixture case |
| Assertion exercises code but misses result | Improve assertion; coverage itself may not change |
| Required behaviour absent from implementation | TDD fix if authorized; otherwise report defect |
| Missing intent | Defer affected expectation, request specification |
| Boundary-dependent branch | Retain boundary classification and handoff |
| Suspected unreachable source | Explain reachability using invariants/callers; do not force impossible state |
| Generated/async instrumentation artifact | Inspect source mapping and installed tool issues; do not blanket-exclude async code |
| Stale/missing assembly or symbols | Correct collection, then rerun |

Keep unreachable source code visible as unresolved unless an independently justified exclusion or authorized production correction is made. "The tool does not count it" and "the source is correct" are different conclusions.

## CI

Preserve existing gates. Add a strong-scope gate only when requested or within the established test change workflow; do not replace overall standards with a smaller denominator. Pin/reuse tool versions and configuration. Do not publish a fabricated successful status if branch support is unavailable. Tool commands and compatibility checks belong in the relevant adapter document.
