# Tooling

This file owns freshness and compatibility. Current stable tooling and current documented methods are the default. A permanently hard-coded "latest" version becomes stale.

## Resolve before generation

1. Inspect the repository's pinned SDK/runtime, compiler, framework, runner, collector, package manager and lockfiles.
2. Verify current stable releases through the official package registry or release feed and read matching documentation. A documentation page may describe an unreleased major; a search snippet is not release evidence.
3. Build a compatibility tuple: language/compiler + runtime target + test framework + runner/adapter + collector + reporter. Verify each link; newest individual packages do not necessarily form a working tuple.
4. For new unconstrained test infrastructure, choose the latest stable compatible tuple and pin exact resolved versions. Do not silently choose an old major merely because a sample uses it. Do not use previews unless explicitly requested.
5. For existing constrained repositories, retain current stable methods that work there. Report an older dependency or runtime constraint explicitly and describe the minimal upgrade needed for an unavailable capability. Do not impose a migration on a tests-only task.
6. Record resolved versions, verification date, official sources and any constraint. Run the resulting suite; documentation alone does not establish compatibility.

"Best" means meaningful assertions, controlled execution, native typed data, explicit scope, fresh measurement and low coupling. Additional abstractions, new packages and preview features do not automatically improve testing.

## Platform evidence

| Platform | Preferred baseline for new work | Required verification |
|---|---|---|
| .NET | NUnit or xUnit as requested; native typed cases; Coverlet for branch evidence | Published stable framework/adapter/collector; SDK vs TFM; VSTest vs MTP |
| TypeScript | Current stable Vitest with matched coverage provider | Node support, TS/Vite support, source maps and locked package versions |
| PowerShell | Current stable PowerShell and Pester | Runtime compatibility, assertion APIs, discovery semantics and actual coverage counters |
| Bash | Bats; Ubuntu WSL2 for full Windows suites, native Bash on macOS | [Environment selection](../../test-coverage/languages/bash/environment.md), native tool versions, separate Git Bash compatibility evidence and actual kcov metrics |

Do not label static analysis, type checking or linting as unit coverage. Preserve their separate findings. If no available tool measures branches, report that limitation instead of inventing a branch score.
