# Business rules

This file owns how an accepted rule changes test eligibility. [Expectations](expectations.md) owns authority precedence; [scope](scope.md) owns the six gates; [fixtures](fixtures.md) owns VIBE construction. Architecture and pattern documents supply discovery examples, not alternate eligibility rules.

## The central distinction

Business meaning and technical isolation are independent. Knowing the rule repairs an expectation gap. It does not repair an unrealistic fake, a race, missing transaction semantics, or an assertion coupled to internal calls.

| Before | New evidence | Classification consequence |
|---|---|---|
| Pure eligibility function with an unexplained threshold | Accepted decision table with inclusive limits | Can become strong if the remaining gates pass |
| Handler reads a record, computes a rule and returns a decision | Accepted policy and a faithful record stub | Its local decision can be strong; a stub does not disqualify it |
| Domain service compares several real in-memory objects | Accepted cross-object rule | Can be strong; the word service changes nothing |
| Listener must acknowledge after durable commit | Explicit ordering contract | Valuable collaboration test under the opt-in; actual durability still needs integration evidence |
| Repository must perform a case-insensitive query | Explicit comparison policy | A policy helper can be strong; SQL/provider behavior still requires the actual provider |
| Two concurrent requests must never overspend | Explicit invariant | Serial aggregate tests cover local rejection; concurrent storage enforcement remains separate |
| Audit event must be retained despite process failure | Explicit event schema and delivery requirement | Event construction can be strong; recording a logger call cannot prove retention |

Do not describe every opt-in interaction test as bad. A narrow assertion of a stable outward obligation can be valuable. It remains outside the default strong coverage target because it supplies different evidence. Conversely, a no-mock test with an invented expected answer is not strong.

## Convert a rule into executable evidence

For each candidate, write a compact rule record with these fields. Unknown material fields block only the affected cases.

| Field | Required detail |
|---|---|
| Identity | Rule ID, accepted source location/version, bounded context or product scope |
| Preconditions | Legal starting state, relevant facts, identity/tenant and supported invalid inputs |
| Decision | Expected result or state transition; ordering/precedence between overlapping rules |
| Boundaries | Inclusive/exclusive limits, units, rounding, missing values and effective dates where relevant |
| Observation | Returned value, public state, recorded domain event, or documented outward obligation |
| Failure | Expected rejection or error, and state/effects that must remain unchanged |
| Evidence split | What this unit establishes; which provider, host or distributed claim remains untested |

Do not demand irrelevant fields: an integer range rule need not invent tenancy or money semantics. If a rule depends on a clock, exchange rate or feature configuration, supply that fact explicitly or through a simple port. Test rule combinations when their interaction matters; do not generate the Cartesian product of unrelated inputs.

## Worked example: reservation rule

Illustrative accepted contract R-17: a request reserves a strictly positive quantity no greater than the supplied available quantity. Rejection leaves state unchanged and records no reservation event. The rule is evaluated on one loaded inventory snapshot. This example does not assert a production policy for any repository.

| VIBE focus | Given available / requested | Expected local observation |
|---|---|---|
| Valid | 8 / 3 | Remaining 5; reservation event contains quantity 3 |
| Invalid | 8 / 0, 8 / -1 | Rejection; remaining 8; no event |
| Boundary | 8 / 8 | Remaining 0; successful event |
| Boundary | 8 / 9 | Rejection; remaining 8; no event |
| Edge | 0 / 1 | Rejection; remaining 0; no event |

Use a named neutral fixture for each starting state/input, then contract-specific expected results and native typed cases. Construct a fresh aggregate per row. Check both result and relevant post-state on rejection. The event may be a public aggregate output; it is not automatically a mock interaction.

Where this code lives changes discovery, not its rule:

- Entity, domain service, ordinary module or application handler with a simple loaded-record stub: the local rule can be strong.
- Handler asserting repository Save is called with the updated aggregate: an additional collaboration obligation, opt-in.
- Repository concurrency token prevents two reservations from succeeding against one snapshot: provider integration.
- A broker eventually delivers the event: messaging integration/system evidence.

Knowing R-17 does not settle concurrency, isolation, retry or delivery guarantees. Record those residual claims rather than inferring them from the local test.

## Histories, properties and rule changes

Strong units need not be stateless or one method. Exercise supported operation sequences against real local objects: reserve then release; approve then reject another approval; replay events then issue a command. Histories are fixtures too. Never force impossible states with reflection to reach branches.

Use property/model-based testing when the rule supplies a useful independent invariant or transition model. Bound generation, control seeds and retain counterexamples. Pair algebraic properties with known examples; do not copy the production algorithm as the model. Line/branch coverage does not establish every state, history or interacting condition.

When rules change, update the applicable expectations and traceability; avoid preserving old outputs merely to keep a regression suite green. Unchanged implementation may initially fail a new rule test correctly. Tests-only scope still does not authorize a production policy change.

## When to ask for a rule

Inspect accepted BDD examples, public contracts, decision tables and maintained tests first. Existing code is evidence of what happens, not independent proof of what should happen. Ask narrowly: 'At the exact limit, should this request be accepted or rejected?' Continue unaffected cases. No amount of architectural naming, coverage data or mocking can resolve a missing decision.
