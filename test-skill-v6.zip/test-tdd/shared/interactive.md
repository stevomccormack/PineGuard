# Interactive TDD

Follow the shared [question flow](../../test-coverage/shared/questions.md). Use the host's structured questions to guide the user. Do not display this whole checklist as one large form.

## 1. Goal

Ask: **What would you like to do?**

- Add tests to existing code → `--mode coverage`.
- Build or fix behavior → `--mode tdd`.
- Assess test candidates first → `--mode audit`.

If building/fixing, obtain the requested change and accepted rule/examples from the task or a focused free-text question. Do not invent them. Audit can proceed with rule gaps identified.

## 2. Code and tests

Resolve the repository from the task/current project, or ask for its path. Then discover candidate source areas and test projects read-only.

Ask **Which code should we focus on?** Offer up to three real discovered areas where appropriate; allow a path or symbol. Do not default to the whole repository. Ask **Which test project/framework should we use?** only when discovery or explicit switches do not settle it. For a new .NET suite offer NUnit (recommended default) and xUnit; do not migrate an existing suite by default.

Infer language/runtime from manifests. If multiple targets matter, ask the user to choose or specify a constraint. Record exact targets for later separate collection runs. Unknown directories or a support-only test library are not executable tests.

## 3. Test scope

Ask: **What should the tests verify?**

- **Local outcomes (recommended):** results, state, exceptions and exposed event outputs; simple stubs are allowed.
- **Local outcomes and interactions:** also verify specified dependency calls, payloads, counts or ordering.

The first choice omits the interaction flag; the second adds `--include-interaction-tests`. Explain in one sentence: “Returns a rejection” is a local outcome; “never calls the payment gateway” is an interaction. Both choices still need credible rules/setup; neither claims a real database or broker was tested.

Only when legacy intent is unclear and characterization is useful, ask **How should unclear existing behavior be handled?** Offer defer/report (recommended) or labelled characterization. Do not make characterization the default just to increase coverage.

## 4. Coverage and evidence

Recommend `line=100,branch=100` for the eligible local subset with a capable provider. Explain that deferred behavior remains visible and interaction obligations are separate evidence. Offer **Use the recommended target** or **Set metric percentages**, accepting values such as `line=95,branch=90`.

Resolve the provider from the repository and language. Ask a provider question only when selection is unresolved or a chosen provider cannot meet the requested metrics. For Pester/kcov explain command/line capability and present an explicit supported target alternative versus retaining the original unsupported request. Never silently translate it.

For audit, explain that the target guides the assessment; no tests are generated. Expose `--mutation` when requested or useful, without requiring every user to answer an advanced-tools questionnaire. Resolve output to a fresh artifacts directory and show it at review.

## 5. Review

Use the shared review choices. Show the ordinary invocation without `--interactive`, preserving all resolved switches and the requested behavior. Include mixed-file attribution or missing-provider limitations where applicable. On Run, route back to SKILL.md and the existing test/coverage workflow. The wizard itself does not certify that a chosen source area passes the strength gates; inventory does that next.

For explicit `--install`, use the companion’s [install-only questions](../../test-coverage/shared/interactive.md) and skip the test-design steps above. For `--dry-run`, final review offers Preview and preserves the read-only mode.
