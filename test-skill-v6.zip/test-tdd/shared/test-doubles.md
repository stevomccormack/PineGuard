# Test doubles

This file owns dependency replacement. Classify using [scope.md](scope.md) before choosing a mocking library.

## Choose by purpose

| Choice | Purpose | Default |
|---|---|---|
| Real in-memory collaborator | Execute cheap local behaviour | Prefer |
| Dummy | Satisfy an unused dependency | Accept if no hidden use is assumed |
| Stub | Supply a boundary value or fault | Accept for local outcome tests |
| Fake | Small functioning substitute | Accept only when its semantic limits are understood |
| Spy / mock expectation | Observe required calls | Collaboration scope; requires `--include-interaction-tests` by default |

A mocking framework configured only to return a value is being used as a stub. Conversely, a handwritten recorder asserting calls is an interaction test. Classification does not depend on library name.

## Allowed by default

- A clock provides a fixed instant; production expiry logic returns a decision.
- A lookup returns a known record; production mapping transforms it and the test asserts the returned value.
- A boundary returns a documented failure; production local policy chooses a defined outcome.
- A logger uses the framework's null logger when logs are incidental.

Use only setup needed for the case. A stubbed path is still weak if constructing it requires imitating framework behaviour or orchestrating a chain of callbacks and state changes. Multiple independent simple input sources are not automatically weak; semantic complexity matters more than count.

## Under --include-interaction-tests

Generate interaction tests only when the obligation has an authority source. Examples: rejection must issue no payment command; cancellation must propagate the specified token; an accepted operation must emit a specified event payload.

Assert only contract-relevant details. Verify exact order, count or arguments only when changing them would violate the obligation. Avoid blanket `VerifyAll`, strict mocks across all internals, and tests that require every implementation call to be configured.

Do not infer distributed exactly-once delivery from one recorded method call. Do not infer durable persistence from `SaveChanges` being invoked. Pair the local obligation with a handoff for the real boundary evidence.

## Reject these shortcuts

- Mocking `DbSet` query execution and claiming production SQL semantics.
- Fake HTTP responses presented as proof the remote service still satisfies its contract.
- Arbitrary exception types a dependency cannot produce under its documented contract.
- Partial mocks that bypass the very algorithm being covered.
- Deep mock graphs introduced only to reach another line.
- Exact log wording when only the business outcome matters. If audit output is a requirement, classify and test that contract explicitly.

Terminology follows [Test Double](https://martinfowler.com/bliki/TestDouble.html). Dependency fidelity needs separate evidence; see [Contract Test](https://martinfowler.com/bliki/ContractTest.html).
