# Application

Application code is often mixed, not inherently weak. A use case may retrieve facts, make a meaningful decision, mutate a real aggregate, and request effects. Inspect each claim separately.

| Behavior | Default strong candidate when specified | Separate evidence |
|---|---|---|
| Application authorization | Decision from supplied actor, resource, tenant and policy facts | Authentication, claims population, middleware enforcement |
| Command handling | Local result and aggregate state after an accepted/rejected command | Persistence, transaction boundary, dispatch |
| Failure translation | Documented dependency failure becomes a defined application result | Real provider actually emits/maps that failure |
| Coordination policy | Choose strategy, batching, retry eligibility or next action from explicit facts | Calls/order are opt-in; scheduling and delivery need boundary tests |
| Query result processing | Projection, grouping, ordering or pagination decision over supplied data | SQL translation, collation, consistency and server-side paging |
| Idempotency decision | Given a known prior result/key, choose the required local response | Atomic duplicate detection and concurrent requests |

A repository returning a plain record or aggregate can be a simple stub. Assert the production decision, not the stubbed data itself. Replacing an entire collaborator chain with scripted responses may fail setup fidelity even when every rule is known.

Example: a checkout handler loads an account and returns CreditLimitExceeded under an accepted limit rule. That outcome can be strong. An additional assertion that no payment command was issued is a valuable outward-obligation test under `--include-interaction-tests`. Neither proves payment was never processed by an external service.

Use existing supported handlers and boundaries. A separate decision function can help when requested refactoring is in scope, but is not a prerequisite for testing every mixed handler. Do not create a new production architecture just to make tests solitary.

If the project combines unit, BDD and integration tests, select the actual unit suite when measuring. The current coverage convenience script runs a whole selected project; use native filtered collection/import where necessary. Do not let extra suites inflate the unit evidence.
