# Core

Core is a repository-specific name, not a universally separate Clean Architecture layer. It may contain domain objects, use cases, interfaces, helpers, or all of them. First map actual responsibilities and dependencies. A namespace named Core may still call a database or read the current clock.

| What is actually inside Core? | Route / treatment |
|---|---|
| Invariants, value transformations, business decisions | [Domain](domain.md) and [business rules](../../shared/business-rules.md) |
| Use-case coordination, authorization decisions, failure policy | [Application](application.md) |
| Port/interface declarations, type aliases, marker types | No runtime test merely to execute a declaration |
| Generated code, DTO auto-properties | Apply existing trivial/generated and exclusion policies; no getter/setter padding |
| Provider/host-dependent behavior | [Infrastructure](infrastructure.md), wherever physically located |

The dependency rule helps keep mechanisms outside policy, but it does not guarantee pure functions or trustworthy expectations. A domain object can be mutable and still strongly testable; a static helper can depend on ambient state and be weak.

100% line and branch coverage is a legitimate target for an explicitly inventoried executable subset whose behaviors all pass the gates. Do not predeclare 'Core = 100%' or exclude everything inconvenient. Branchless items, unsupported metrics, generated code and unattributable mixed files retain the existing measurement rules. The current reporter certifies whole-file scope only; this documentation does not add method-level measurement.

Dependency direction itself is usually checked with an architecture/static dependency test, not thousands of business unit assertions. Classify such checks separately from behavioral coverage.
