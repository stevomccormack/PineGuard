# Domain

Look for decisions that use domain facts and preserve invariants: quantities, eligibility, pricing rules, transitions, allocation and identity-sensitive operations. Accepted rules plus controlled local execution make these strong candidates. Read [business rules](../../shared/business-rules.md) for the required evidence record.

| Candidate | Strong unit observation | Residual or trap |
|---|---|---|
| Value object | Validation, canonical representation, equality under its actual contract | Do not retest framework-generated equality without a custom obligation |
| Entity / aggregate | Supported transition, invariant, rejection preserving state | Persistence and concurrent enforcement are separate |
| Domain service | Defined decision over supplied facts or real local objects | No blanket exception for services; remote lookups may be separate inputs |
| Domain policy / specification | Accepted/rejected decision and meaningful reason | A query expression executed locally does not prove provider translation |
| Domain event construction | Event type, relevant payload, correct local recording | Recording is not publishing or durable delivery |
| Domain factory | Valid creation and rejection; invariant holds after construction | Container activation and database-generated identity remain boundary concerns |

Use multiple real domain objects within one test when they form the smallest coherent behavior. One class per unit is not a requirement. Avoid mocking entities and value objects that can run cheaply in memory.

The domain layer can contain abstract declarations, generated members, serialization attributes, persistence leakage and unknown rules. Its entire reported coverage is not automatically a useful target. Domain services are assessed with the same gates as entities. For DDD-specific distinctions use [model](../ddd/model.md), [services](../ddd/services.md) and [events](../ddd/events.md); do not duplicate those rules here.
