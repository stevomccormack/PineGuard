# Infrastructure

Infrastructure is not uniformly untestable. It contains local decisions and translations alongside mechanisms whose fidelity requires integration tests. Classify the specific claim.

| Local candidate | What a strong unit can establish | What it cannot establish |
|---|---|---|
| Request/envelope builder | Contract-backed fields, escaping, headers, identifiers | Remote acceptance or wire behavior |
| Response/error translator | Defined input maps to the correct local result | Actual client/provider error behavior |
| Retry/backoff policy | Retry/no-retry, bounded delay, supplied jitter and budget | Timer behavior, cancellation races, reconnect success |
| Serializer wrapper | Published vectors or schema-backed shape with real local serializer | End-to-end consumer compatibility or broker/database limits |
| Cache decision | Fresh/stale decision with fixed time and explicit cache state | Eviction, distributed coherence or concurrent stampede prevention |
| Telemetry transformation | Required redaction, bounded dimensions or event mapping | Export, sampling configuration, ingestion and alerts |

Use real deterministic libraries locally when cheap. Their involvement does not automatically force integration classification. Conversely, a fake database with a matching interface is still a different provider.

Route provider details to [data](../boundaries/data.md), [messaging](../boundaries/messaging.md), [API](../boundaries/api.md) and [observability](../boundaries/observability.md). These boundary documents own the claim splits; this file only locates them in architecture.

DI registration, resolution, lifetime, disposal and host startup deserve small composition tests when they matter. Those tests can be deterministic and cheap while still being composition/integration evidence. Do not count them as strong business-unit coverage or hand them automatically to BDD without identifying an actual owner.
