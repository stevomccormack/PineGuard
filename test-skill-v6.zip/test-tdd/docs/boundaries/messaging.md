# Messaging

Listeners and consumers often contain strong local policies inside a transport boundary. 'Listener' is not a classification.

| Behavior | Strong candidate | Separate claim |
|---|---|---|
| Decode/validate an envelope | Real local parser against accepted schema/examples | Broker headers, encoding and real delivery |
| Select processing action | Decision from message, known state and accepted policy | Dispatch/call verification is opt-in if no returned decision exists |
| Decide retry or dead-letter | Documented failure category, attempt count and budget | Actual requeue, dead-letter routing and redelivery |
| Handle a known duplicate | Return prior outcome or reject under a supplied rule | Atomic deduplication under concurrent consumers |
| Build outgoing event | Required identity, causation and business fields | Broker acceptance, publication and downstream compatibility |
| Aggregate a batch locally | Known window inputs, ordering and aggregation rules | Watermarks, wall-clock windows, partition order and scheduler behavior |

No automatic assertion of ACK/NACK, commit offsets, publish counts or exact order in the strong target. Under `--include-interaction-tests`, verify a documented obligation narrowly, for example acknowledge only after the commit port reports success. This proves the caller's protocol decision under those responses; it does not prove the storage was durable or the broker received acknowledgement.

Delivery mode, retries, ordering, visibility/lease expiry, poison messages, cancellation during processing and shutdown are broker/runtime concerns. Use a real compatible broker for those claims. Deterministic state-machine tests can complement that evidence without replacing it.

For an outbox, mapping state changes to an outbox payload may be local. Atomic transaction, relay recovery and duplicate publication require integration/system tests. 'Published once in this unit test' is not an exactly-once guarantee.

For event sourcing and sagas use [DDD events](../ddd/events.md). Avoid deep fake broker implementations; supply simple documented facts to local policies instead.
