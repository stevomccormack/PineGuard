# API

Inspect the claim, not whether the method is a controller, endpoint, middleware, resolver or handler.

| Candidate claim | Local unit evidence | Boundary evidence still needed |
|---|---|---|
| Request is valid under an explicit business rule | Production validation over supplied data, including defined invalid cases | Deserialization, binding, framework validation execution |
| Supplied actor/resource/tenant facts permit an operation | Policy decision and rule precedence | Identity verification, claims extraction, endpoint enforcement |
| Result maps to the required response model/status decision | Real local mapper or returned response object | Routing, middleware, headers and actual serialized HTTP response |
| Pagination token or identifier follows a format | Known vectors and explicit malformed-input behavior | Client/server interoperability and query consistency |
| External error becomes a specific API error | Mapper over documented error variants | Real client errors and host exception pipeline |
| Required downstream command is suppressed on rejection | Optional outward-obligation test | Whether external effects actually occurred |

Calling an action directly bypasses host behavior. A returned status object is useful local evidence, but does not prove the deployed endpoint emits that status. Framework-provided binding, authorization attributes and middleware registration belong in host/composition tests.

Security-relevant mapping requires an approved field contract: 'maps every property' can be wrong when fields must be withheld. Test explicit data-minimization/redaction decisions locally; test enforcement at the host boundary as well.

GraphQL/RPC and HTTP differ in transport semantics but use the same separation of local decisions from host behavior. Avoid adding another controller mock layer when a real in-memory handler/mapper is sufficient.
