# Data

Separate a caller's policy, a repository's transformation and the database's execution semantics. A repository interface only creates a replaceable boundary; it does not make the replacement faithful to storage.

| Behavior | Appropriate unit claim | Requires provider evidence |
|---|---|---|
| Not-found or stale-record handling | Caller produces the specified outcome from a known response | Real repository identifies that state correctly |
| Row/domain transformation | Accepted field, null and conversion rules | Actual query projection and stored representation |
| Query/predicate builder | Structural contract or local predicate rule where independently specified | SQL translation, null behavior, collation, ordering and execution plan |
| Parameterized command construction | Untrusted value stays in parameters under a specified command contract | Driver binding and server execution |
| Optimistic-conflict translation | Known conflict maps to defined local result | Token handling and conflicts between real concurrent updates |
| Transaction orchestration | Opt-in documented commit/rollback request | Atomicity, isolation, rollback and durable state |
| Cache policy | Fixed-time fresh/stale decision | Actual eviction/coherence and concurrency |

Do not mock IQueryable/DbSet execution to certify EF Core behavior. Microsoft recommends tests against the actual database system for its semantics; when substituting data access, a repository above EF Core can provide a stub boundary, at an architectural cost. This is not an instruction to introduce repositories into every codebase. [EF Core testing strategy](https://learn.microsoft.com/en-us/ef/core/testing/choosing-a-testing-strategy).

A database in a local container can be fast and repeatable while remaining integration evidence. SQLite can test SQLite; it is not proof of SQL Server or PostgreSQL semantics. Use the production engine/version family when the assertion depends on provider behavior.

Local aggregation/reduction over already supplied rows can be strong. Server-side aggregation, case comparison, decimal handling and paging require provider tests too. The same applies to TypeScript ORMs and scripts calling database clients; changing the language does not remove the dependency.

Stored procedures contain real business logic, but this skill's current coverage providers do not certify SQL line/branch coverage. Record that separate test/tool requirement; never credit stubbed procedure results as coverage of the procedure.
