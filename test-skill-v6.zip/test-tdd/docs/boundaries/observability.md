# Observability

Observability can be a specified output, an incidental diagnostic, or a distributed operational capability. Those are different test claims.

| Requirement | Candidate evidence | Limit |
|---|---|---|
| Redact particular sensitive fields | Strong local transform with named allowed/removed examples | Does not prove all production paths use it |
| Build a structured audit event | Strong local event value with required business fields | Does not establish durable audit storage |
| Use bounded metric dimensions | Strong normalization/classification policy with explicit allowed values | Does not establish deployed cardinality or backend cost |
| Emit the documented event on a transition | Opt-in interaction assertion when only a sink call exposes it | Avoid incidental log wording and implementation call counts |
| Attach required span attributes/status | Real local SDK capture can validate an instrumentation contract | Treat SDK/listener setup as component evidence when it is the behavior under test |
| Carry trace context across a queue/HTTP boundary | Host/transport integration | A fixed local trace ID does not prove propagation |
| Deliver, sample, retain and alert | Pipeline/system/operational tests | Unit coverage cannot establish backend ingestion or alert behavior |

Use a null logger when logging is incidental. Do not test every log line merely to execute it. If event ID, severity, fields or exact wording are contractual, record that authority and assert only those obligations under the appropriate scope.

Known observability requirements can improve expectations; they do not turn exporters or sampling pipelines into pure business units. Local in-memory capture can be useful and deterministic without belonging to the strong line/branch target. Do not manufacture an output model solely to move an emission test into the default category.

Telemetry pipelines can sample or filter data. A domain audit record that must exist should not be assumed equivalent to a sampled diagnostic span. Determine the application's actual required record and persistence contract. OpenTelemetry distinguishes instrumentation, signals and export/propagation concepts: [overview](https://opentelemetry.io/docs/specs/otel/overview/), [observability primer](https://opentelemetry.io/docs/concepts/observability-primer/).

Avoid global listeners leaking across tests, live exporters, fixed sleeps and exact elapsed-time assertions. Use framework-supported scoped capture and deterministic flush/completion controls for the evidence level being tested.
