# Architecture

Use architecture to discover likely responsibilities. Use [scope](../shared/scope.md) to classify their actual behavior. Neither folder names nor dependency direction establish test quality or a coverage denominator.

| Repository evidence | Read |
|---|---|
| Core, Domain, Application, Infrastructure projects or dependency rings | [Clean Architecture core](clean-architecture/core.md), then the relevant layer |
| Entities, aggregates, value objects, domain services or domain events | [DDD model](ddd/model.md), [services](ddd/services.md), [events](ddd/events.md) |
| Bounded contexts, translation between models, shared language | [DDD contexts](ddd/contexts.md) |
| Named design pattern or equivalent unnamed code | [Patterns](patterns.md) |
| HTTP, broker, storage, telemetry responsibilities | The relevant [API](boundaries/api.md), [messaging](boundaries/messaging.md), [data](boundaries/data.md) or [observability](boundaries/observability.md) boundary |
| Only API/model projects, modules or functions | Inspect responsibilities directly; no architecture migration is needed |

Clean Architecture concerns dependency direction and separating policy from mechanisms. DDD concerns domain modeling, language and boundaries; it is not a mandatory project/folder layout. They can be used together or separately. Original references: [Clean Architecture](https://blog.cleancoder.com/uncle-bob/2012/08/13/the-clean-architecture.html), [DDD Reference](https://www.domainlanguage.com/wp-content/uploads/2016/05/DDD_Reference_2015-03.pdf).

These guides are test-selection advice, not an architecture conformance standard. Do not create layers, repositories, interfaces or domain services solely because the documents name them. Inspect concrete dependencies and supported entry points. Record architectural violations only when they affect the requested test evidence; do not turn test work into an unsolicited redesign.

The shared rules apply equally to .NET and TypeScript. PowerShell and Bash often benefit from smaller modules and a separation between decisions and effects; they can contain domain policy too. Native syntax and runtime hazards remain in [language adapters](../SKILL.md#language-routing).
