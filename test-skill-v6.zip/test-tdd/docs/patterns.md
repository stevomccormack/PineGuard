# Patterns

Pattern names are search hints. The following are discovery examples, not exemptions from [scope](../shared/scope.md). The strongest unit may be a function or several real cooperating objects.

| Pattern / responsibility | Strong candidate when the rule is known | Boundary / common mistake |
|---|---|---|
| Strategy / policy | Select and execute an algorithm from explicit facts | Mocking the selected algorithm and asserting its return value |
| Specification / predicate | Accepted combinations, precedence and boundary decisions | Claiming local evaluation proves query-provider semantics |
| Factory / builder | Construct a valid meaningful object, reject invalid combinations | Testing constructors/DI resolution merely for coverage |
| Adapter / mapper / anti-corruption layer | Contract-backed translation, normalization, rejection | Stubbed provider compatibility; copying implementation fields as authority |
| Parser / formatter / serializer | Accepted reference vectors and defined invalid input behavior | Round-trip alone can preserve a shared defect |
| Reducer / fold / data aggregation | Known accumulation, empty input, order dependence, numeric limits | Confusing it with a DDD aggregate or distributed aggregation |
| Entity / aggregate | Invariants and transitions across real local members | Mocking the model or asserting private layout |
| Domain service | Defined computation across domain facts/objects | Treating every Service as I/O-heavy |
| Command handler / use case | Observable policy/result/state with simple port facts | Scripting every internal call; assuming Save implies persistence |
| Listener / consumer | Parse and decide over message and state | Assuming local callback execution proves broker semantics |
| State machine | Accepted transitions, rejected transitions, state preservation | Branch coverage mistaken for all histories |
| Saga / process manager | Deterministic next state and returned commands | Durability, distributed compensation and ordering |
| Event-sourced model | Replay given history; command yields specified next events | Stream append concurrency and recovery |
| Chain of responsibility / rule pipeline | Defined precedence and final decision | Requiring implementation order when only outcome is contractual |
| Decorator | A specified transformation of input/output or local failure policy | Every forwarding wrapper receiving redundant tests |
| Retry / backoff policy | Classification, attempt budget and calculated delays | Sleeping to test timers; duplicating a framework retry implementation |
| Circuit breaker | A pure transition model if custom policy actually exists | Testing a fake scheduler or asserting third-party internals |
| Cache-aside | Local key/expiry/outcome policy | Distributed coherence and concurrent fills |
| Repository / unit of work | Caller decision and local mapping | Provider queries/transactions declared tested by mocks |
| CQRS projection | Pure event-to-view transformation with known ordering | Assuming CQRS implies event sourcing; storage/delivery correctness |
| Visitor / interpreter | Defined evaluation across node variants | Copying production dispatch into the expected-result generator |
| Planner / executor | Explicit plan from supplied state; inspect meaningful proposed actions | Plan equality proving that effects executed successfully |

Planner/executor and functional-core/imperative-shell arrangements often expose useful test boundaries. They are opportunities in existing code, not required refactors. An existing handler can still have strong local cases without being redesigned.

For effects observable only as port calls, use [test doubles](../shared/test-doubles.md). For detailed API, storage, messaging or telemetry claims use the relevant [architecture routing](architecture.md). Keep the pattern table about recognition; do not duplicate boundary procedures here.
