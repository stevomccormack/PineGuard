# DDD model

DDD names help discover intended responsibilities, not certify them. Inspect behavior and its bounded-context rules. Tactical modeling concepts and strategic boundaries are different concerns; use [contexts](contexts.md) for the latter.

| Model element | Valuable local tests | Avoid |
|---|---|---|
| Value object | Accepted construction, validation, normalization and custom equality/units | Auto-property echoes or asserting every compiler-generated member |
| Entity | Identity-sensitive transitions and defined invariant preservation | Assuming all mutable data has domain behavior |
| Aggregate | Command/operation against the root, relevant state and recorded events across real members | Mocking internal entities, reaching private fields, requiring one assertion per class |
| Specification/policy | Known predicate, composition semantics, overlapping rules and boundaries | Assuming a database query specification has identical in-memory semantics |
| Domain service | Domain decision that does not naturally belong to an entity/value object | Blanket exclusion because its name ends in Service |

An aggregate can be the unit. Set it up through supported construction/history and assert the externally meaningful result. Keep its internal layout free to change. Failure cases should inspect relevant unchanged state and absence of forbidden recorded events, when required by the contract.

Aggregate invariants can be locally verified across sequential operations. Atomic commit, uniqueness across stored aggregates and concurrent updates require additional evidence. A serial in-memory history cannot prove those guarantees. Do not create an oversized in-memory aggregate merely to replace a real consistency boundary.

Distinguish an aggregate from data aggregation: a reducer summing rows is not automatically a DDD aggregate. Both may be strong candidates, but the latter needs its own numeric, ordering and empty-input contracts.

100% measured branches does not cover every domain state or transition history. Use explicit state/transition tables and independent properties where valuable, while retaining the existing VIBE fixture conventions.
