# DDD contexts

A bounded context identifies where a particular model and language apply. It is not necessarily a project, process, service or database. Do not infer it solely from deployment structure.

Attach rule authority to its context. 'Customer', 'balance' or 'approved' can legitimately mean different things across contexts. Reusing fixture input shapes can be useful; sharing one expected-result table across distinct policies can erase those distinctions. Keep contract-specific expectations separate.

An anti-corruption layer translates external concepts into a local model. Its deterministic translation and rejection policies can be strong with accepted mappings/reference examples. Transport availability and compatibility with the actual external provider still need boundary evidence. Do not claim the upstream system satisfies a locally invented fixture schema.

Shared kernels require explicitly shared semantics, not merely matching DTOs. Unit tests can protect agreed transformations and invariants. Architecture checks can protect dependency constraints. Cross-context compatibility and business workflows need separately identified tests.

DDD does not mandate a universal four-project structure, class-based implementation or domain services in every system. Use its modeling vocabulary only when it clarifies an existing responsibility. It applies to TypeScript as well as .NET; a model may be represented through data and functions. Script modules can encode policies without being called bounded contexts.
