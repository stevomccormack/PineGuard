# DDD events

Separate domain facts, local event recording, handling decisions and transport. An event-shaped object is not itself evidence of a distributed architecture.

| Claim | Suitable evidence |
|---|---|
| Operation records the correct domain event | Strong candidate when event collection/result is a supported observable contract |
| Rejected operation records no event | Strong candidate alongside unchanged state, if the rule requires it |
| Given a domain event and current local state, compute the next state | Strong candidate with real local behavior and known rules |
| Handler calls an event publisher with specified payload | Opt-in collaboration obligation |
| Serialized integration event meets a published shape | Local serialization vectors plus appropriate consumer/provider contract evidence |
| State and outbox record commit atomically | Database transaction integration |
| Event is delivered and processed despite duplicates/failures | Messaging/system evidence, plus any separately testable local deduplication policy |

For event-sourced code, command decisions and event replay/folding can be strong. Use accepted event histories, expected state and next-event outputs. Include repeated commands, unsupported transitions and empty histories only where their contract is defined. Stream concurrency, append ordering, upcasting compatibility with stored histories and projection delivery need their own evidence; pure upcasters can also have local reference-vector tests.

An in-memory domain-event list observed through a public contract is an output. It is not the same as a spy verifying which dispatcher method ran. Do not force all event tests behind the collaboration switch.

For sagas/process managers, a transition function returning commands can be strong. If the existing implementation only sends commands through ports, those assertions follow the collaboration opt-in. Durable recovery, distributed compensation and message ordering remain [messaging](../boundaries/messaging.md) concerns.
