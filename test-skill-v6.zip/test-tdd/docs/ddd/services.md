# DDD services

A domain service expresses domain behavior that does not naturally fit an entity or value object. This modeling role is not a testability penalty. Application services and infrastructure services may have different responsibilities despite sharing the suffix.

| Actual service behavior | Treatment |
|---|---|
| Allocate a payment across supplied invoices under an accepted rule | Strong candidate with real invoices and fixture-backed expected allocations |
| Assess eligibility from supplied facts, effective time and a decision table | Strong candidate; exercise rule precedence and thresholds |
| Load one required fact through a simple port, then return a local decision | Can be strong if the stub is faithful and production policy executes |
| Coordinate several external actions and return no local state/result | Documented outward obligations are opt-in collaboration tests |
| Guarantee uniqueness by checking a repository before insertion | Local response to 'already exists' can be strong; race-safe uniqueness is provider evidence |
| Quote using a remote system's proprietary calculation | Local mapping/error handling may be strong; a stubbed quote does not test that calculation |

Multiple inputs or collaborators are not a numerical weakness threshold. Judge whether setup supplies facts or reimplements hidden behavior. A dozen plain values can be easier to trust than one fake transactional database.

Read [business rules](../../shared/business-rules.md) to identify missing policy. Read [application](../clean-architecture/application.md) for use-case coordination and [test doubles](../../shared/test-doubles.md) for outward obligations. Classification follows responsibility, not the service label or DI registration.
