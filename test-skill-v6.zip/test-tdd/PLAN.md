# Implementation plan

The documentation and companion coverage skill are installed. Test creation remains agent-driven; deterministic installation, collection and reporting are Bash scripts in [test:coverage](../test-coverage/SKILL.md).

## Ownership

SKILL.md routes. shared/options.md owns the skill invocation; scope.md owns strength classification; expectations.md owns assertion authority; fixtures.md owns VIBE and data architecture; test-cases.md owns case selection; test-doubles.md owns collaborator replacement; workflow.md owns execution; coverage.md owns target policy; exclusions.md owns omissions; report.md owns completion evidence. Language adapters specialize syntax and runtime hazards. Coverage mechanics are maintained once in the companion skill.

## Execution recommendations

- Use --language, --runtime, --framework, --repo, --project, --scope and explicit metric targets. NUnit and xUnit are equal adapters. --include-interaction-tests explains the extended scope better than --all; neither invents intent.
- Resolve skill-level constraints to the companion's concrete arguments. A skill invocation is not a globally installed CLI command.
- All tests use fixtures and named VIBE rows. The fixture definition is shared across languages; typed adapters belong to each framework.
- Existing-code coverage is regression testing, not retrospectively claimed TDD. For requested changes use meaningful red/green cycles.
- Use the coverage-handoff loop until supported targets pass or remaining cases have explicit blockers. Never make source exclusions a substitute for test design.

## Remaining acceptance work

1. Run realistic independent classification evaluations on API/model-only repositories, mixed methods, missing specs, fragile mocks and compiler-only contracts. Document model mistakes before changing rules.
2. Compile and run the native examples against the repository's supported runtime/framework matrix. Do not confuse a doc-link check with execution evidence.
3. Add a method-level measurement adapter to the companion before claiming automatic isolated coverage of strong methods in mixed files.
4. Validate the Bash collection scripts on physical macOS and Windows, including kcov and project-specific Pester/TypeScript configurations; keep platform limits explicit.
5. Exercise the full test-creation loop on an existing API without adding architectural layers, then inspect assertions and surviving plausible defects as well as percentages.

The aim is 100% measured line and branch coverage where supported and attributable, with justified expectations and low-maintenance tests. No skill can guarantee unspecified intent, all possible inputs, or bug freedom from a percentage.

## Architecture knowledge ownership

shared/business-rules.md owns how accepted rules improve eligibility. docs/architecture.md routes discovery. docs/clean-architecture maps project responsibilities; docs/ddd explains model-specific test boundaries; docs/patterns.md recognizes candidates; docs/boundaries splits local assertions from provider/host/distributed evidence. These references do not override shared/scope.md, fixture rules or the coverage denominator.

Evaluate the added contrast cases before claiming autonomous identification is reliable across existing APIs. No new architecture or --architecture flag is required: infer actual responsibilities, and ask only about ambiguous rules that affect the requested cases.
