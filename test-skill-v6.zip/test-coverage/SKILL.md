---
name: test-coverage
description: Install coverage tools, collect test coverage and create structured JSON and HTML reports for C# NUnit/xUnit, TypeScript, PowerShell and Bash. Preserve provider metric limitations and reconcile an explicit source inventory. Use with test-tdd for coverage-guided test creation.
---

# test:coverage
## Entry modes

Resolve [execution modes](shared/execution.md) before any workflow step. Help stops immediately; interactive gathers choices; dry-run previews without writes; install-only sets up dependencies and stops. These modes must not fall through to test creation or collection.

Read [INSTALL.md](INSTALL.md) for setup and [options](shared/options.md) for supported switches.


Measure declared source scope and return evidence. Test design and semantic classification belong to [test:tdd](../test-tdd/SKILL.md). This skill also works independently with an explicitly requested source scope.

1. Read [options](shared/options.md), [installation](shared/installation.md) and [scope](shared/scope.md). Inspect project constraints and existing exclusions before selecting a runner/provider.
2. Read the relevant adapter: [.NET](languages/dotnet/testing.md), [TypeScript](languages/typescript/testing.md), [PowerShell](languages/powershell/testing.md), [Bash](languages/bash/testing.md).
3. Create the scope manifest before collection. Resolve one runtime, one unit suite and one fresh output directory.
4. Run `bash scripts/collect.sh` with documented arguments. It installs coverage tools and produces native evidence, JSON and HTML. For an existing native report or an unsupported collection topology, use the adapter's native collection procedure followed by `bash scripts/report.sh`.
5. Read [reports](shared/reports.md). Return gaps, exact counters and limitations to the caller. An unsupported metric, missing inventory, zero tests or failed tests cannot pass.
6. Consult [validation](evaluation/results.md) for tested paths and implementation limits; do not imply every platform has been exercised.

All delivered executable scripts are Bash, compatible in syntax with Bash 3.2+. Full Bash suites on Windows should run in Ubuntu WSL2; Git Bash remains supported for Windows tool workflows and compatibility tests. On macOS use native Bash. The collection commands invoke the native test frameworks through their APIs/CLIs. PowerShell tests remain PowerShell and TypeScript tests remain TypeScript; orchestration is Bash.

Do not add tests, modify production source, change exclusions, upgrade the application runtime or install system services to make a coverage gate pass. Required local coverage packages may be installed within the user's request. Record dependency changes. Preserve requested thresholds even when a provider cannot measure them.

The implementation supports whole-file scope. Mixed files needing method attribution remain unresolved for the strong-only gate; never include weak members in that target or exclude them to disguise the limitation. Native reports remain available for human inspection.

Ownership: `shared/` defines measurement mechanics, manifests and reports; `languages/` defines provider integration; `scripts/` implements those operations. VIBE and test-strength rules have one owner in test:tdd. [PLAN.md](PLAN.md) records remaining improvements and [sources](shared/sources.md) records tool references.

Read [capabilities](shared/capabilities.md) before claiming provider, report, diff or platform support. An installation check is not a test or coverage result.

For parallel Bash execution, read [parallel collection](languages/bash/testing.md#parallel-collection). Native Bats jobs do not imply collector support or complete child-process coverage.

For Bash work on Windows, read [Bash environment](languages/bash/environment.md) before selecting a runtime. Bats is the framework; Ubuntu WSL2 is the recommended full-suite environment. This preference does not migrate .NET, TypeScript or PowerShell workflows.
