#!/usr/bin/env bash
# Functions only; caller sources common.sh and ensures jq.
validate_target() {
  local value=$1
  [ "$value" != '100%' ] || value='line=100,branch=100'
  jq -en --arg value "$value" '
    $value|split(",")|map(split("=")|if length==2 then {key:.[0],value:(.[1]|tonumber)} else error("metric=value required") end)|
    if length>0 and (map(.key)|unique|length)==length and all(.[];
      (.key=="line" or .key=="branch" or .key=="command" or .key=="statement") and
      (.value|isfinite) and .value>=0 and .value<=100)
    then from_entries else error("Invalid or duplicate coverage target") end'
}
validate_scope() {
  local manifest=$1 file declared component partial
  jq -e '.version==1 and (.root|type=="string" and length>0) and
    (.files|type=="array" and length>0) and all(.files[];type=="string" and length>0 and (test("[\u0000-\u001f\u007f]")|not)) and
    (.files|unique|length)==(.files|length)' "$manifest" >/dev/null || fail 'Invalid source inventory'
  declared=$(jq -r .root "$manifest")
  case "$declared" in /*|[A-Za-z]:/*) :;; *) fail 'Scope root must be absolute';; esac
  root=$(absolute_path "$declared")
  while IFS= read -r file; do
    case "$file" in /*|*\\*|*:*|.|..|./*|../*|*/./*|*/../*|*/.|*/..|*//*|*/) fail "Scope needs canonical repository-relative paths: $file";; esac
    [ -f "$root/$file" ] || fail "Scope source does not exist: $file"
    # Reject symlinked entries rather than reading outside the declared inventory.
    partial=$root
    while IFS= read -r component; do
      partial="$partial/$component"
      [ ! -L "$partial" ] || fail "Symlinked source scope is unsupported: $file"
    done < <(printf '%s\n' "$file" | tr '/' '\n')
  done < <(jq -r '.files[]' "$manifest")
}
validate_tests() {
  jq -e '
    def count: type=="number" and isfinite and .>=0 and floor==.;
    (.total|count) and (.failed|count) and ((.skipped//0)|count) and
    (.failed+(.skipped//0)<=.total) and (.verified|type=="boolean") and
    (.exitCode==null or (.exitCode|type=="number" and isfinite and floor==.))' "$1" >/dev/null || fail 'Invalid test evidence counters or attestation'
}
