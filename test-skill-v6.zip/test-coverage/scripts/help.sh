#!/usr/bin/env bash
# Read-only help; deliberately does not source common.sh or initialize a cache.
set -euo pipefail
help_root=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
cat "$help_root/shared/help.md"
