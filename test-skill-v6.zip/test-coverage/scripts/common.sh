#!/usr/bin/env bash
# Shared Bash 3.2+ helpers. No changes to shell profiles or global PATH.
set -euo pipefail
TC_ROOT=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
TC_CACHE=${TEST_COVERAGE_CACHE:-${XDG_CACHE_HOME:-$HOME/.cache}/test-coverage}
export PATH="$TC_CACHE/bin:$TC_CACHE/dotnet:$PATH"
case "$(uname -s)" in
  MINGW*|MSYS*|CYGWIN*) TC_OS=windows ;;
  Darwin) TC_OS=macos ;;
  Linux) TC_OS=linux ;;
  *) printf 'Unsupported operating system\n' >&2; exit 2 ;;
esac
# Native jq otherwise writes CRLF into Bash command substitutions on Windows.
jq() { if [ "$TC_OS" = windows ]; then command jq -b "$@"; else command jq "$@"; fi; }
fail() {
  printf '%s\n' "$*" >&2
  if [ -n "${RUN:-}" ] && [ -d "$RUN" ] && type -P jq >/dev/null 2>&1; then
    mkdir -p "$RUN/report"
    jq -n --arg reason "$*" '{schemaVersion:1,status:"collection-failed",reason:$reason,metrics:[],gaps:[]}' >"$RUN/report/coverage.json"
    jq -r '"<!doctype html><html lang=\"en\"><meta charset=\"utf-8\"><title>Coverage collection failed</title><h1>Coverage collection failed</h1><p>"+(.reason|@html)+"</p><p>See the run logs and raw evidence. No coverage target was established.</p></html>"' "$RUN/report/coverage.json" >"$RUN/report/coverage.html"
  fi
  exit 2
}
need() { command -v "$1" >/dev/null 2>&1 || fail "Required host runtime missing: $1. Install the project-compatible runtime, then retry."; }
native_path() { if [ "$TC_OS" = windows ]; then cygpath -m "$1"; else printf '%s\n' "$1"; fi; }
absolute_path() {
  local value=$1
  if [ "$TC_OS" = windows ]; then value=$(cygpath -u "$value"); fi
  if [ -d "$value" ]; then (cd "$value" && pwd)
  elif [ -f "$value" ]; then (cd "$(dirname "$value")" && printf '%s/%s\n' "$PWD" "$(basename "$value")")
  else fail "Path does not exist: $value"; fi
}
sha256() {
  if command -v sha256sum >/dev/null 2>&1; then sha256sum "$1" | awk '{print $1}'
  else shasum -a 256 "$1" | awk '{print $1}'; fi
}
fetch() { mkdir -p "$TC_CACHE/bin" "$TC_CACHE/downloads"; need curl; curl --fail --location --silent --show-error --retry 2 "$1" -o "$2"; }
ensure_jq() {
  type -P jq >/dev/null 2>&1 && return
  local asset url sums expected actual
  case "$TC_OS:$(uname -m)" in
    windows:*) asset=jq-windows-amd64.exe ;;
    macos:arm64) asset=jq-macos-arm64 ;;
    macos:*) asset=jq-macos-amd64 ;;
    linux:aarch64|linux:arm64) asset=jq-linux-arm64 ;;
    linux:*) asset=jq-linux-amd64 ;;
  esac
  url=https://github.com/jqlang/jq/releases/latest/download
  fetch "$url/$asset" "$TC_CACHE/downloads/$asset"
  sums="$TC_CACHE/downloads/jq-sha256sum.txt"
  fetch "$url/sha256sum.txt" "$sums"
  expected=$(awk -v file="$asset" '$2==file || $2=="*"file {print $1}' "$sums")
  [ -n "$expected" ] || fail 'jq checksum not found in official release manifest'
  actual=$(sha256 "$TC_CACHE/downloads/$asset")
  [ "$actual" = "$expected" ] || fail 'jq checksum mismatch'
  if [ "$TC_OS" = windows ]; then cp "$TC_CACHE/downloads/$asset" "$TC_CACHE/bin/jq.exe"
  else cp "$TC_CACHE/downloads/$asset" "$TC_CACHE/bin/jq"; chmod +x "$TC_CACHE/bin/jq"; fi
}
ensure_yq() {
  if command -v yq >/dev/null 2>&1 && yq --version 2>/dev/null | grep -q mikefarah; then return; fi
  ensure_jq
  local os arch asset meta url digest target
  os=$TC_OS; [ "$os" != macos ] || os=darwin
  arch=amd64; case "$(uname -m)" in arm64|aarch64) arch=arm64;; esac
  asset="yq_${os}_${arch}"; [ "$os" != windows ] || asset="$asset.exe"
  meta="$TC_CACHE/downloads/yq-release.json"
  fetch https://api.github.com/repos/mikefarah/yq/releases/latest "$meta"
  url=$(jq -r --arg a "$asset" '.assets[] | select(.name==$a) | .browser_download_url' "$meta")
  digest=$(jq -r --arg a "$asset" '.assets[] | select(.name==$a) | .digest // empty' "$meta")
  [ -n "$url" ] && [ "${digest#sha256:}" != "$digest" ] || fail 'Official yq asset or SHA256 digest unavailable'
  target="$TC_CACHE/downloads/$asset"; fetch "$url" "$target"
  [ "$(sha256 "$target")" = "${digest#sha256:}" ] || fail 'yq checksum mismatch'
  if [ "$os" = windows ]; then cp "$target" "$TC_CACHE/bin/yq.exe"
  else cp "$target" "$TC_CACHE/bin/yq"; chmod +x "$TC_CACHE/bin/yq"; fi
}
ensure_dotnet_tool() {
  local package=$1 executable=$2
  [ ! -f "$TC_CACHE/dotnet/$executable" ] && [ ! -f "$TC_CACHE/dotnet/$executable.exe" ] || return 0
  need dotnet
  mkdir -p "$TC_CACHE/dotnet"
  dotnet tool install "$package" --tool-path "$(native_path "$TC_CACHE/dotnet")" >&2
}
xml_json() { ensure_yq; yq -p xml -o json --xml-attribute-prefix '@' '.' "$1"; }
capture() {
  # Preserve failure while allowing a report to be generated from partial evidence.
  set +e
  "$@" >"$RUN/log.txt" 2>&1
  TEST_EXIT=$?
  set -e
  cat "$RUN/log.txt" >&2
}
