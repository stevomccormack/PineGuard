#!/usr/bin/env bash
set -euo pipefail
# Handle UI entry modes before common.sh can create directories or install tools.
if [ "$#" -eq 0 ]; then bash "$(dirname "${BASH_SOURCE[0]}")/help.sh"; exit 0; fi
for ui_arg in "$@"; do
  if [ "$ui_arg" = --help ]; then bash "$(dirname "${BASH_SOURCE[0]}")/help.sh"; exit 0; fi
done
for ui_arg in "$@"; do
  if [ "$ui_arg" = --dry-run ] || [ "$ui_arg" = --check ]; then
    printf '%s\n' 'Preview/check must use root install.sh for installation, or the agent skill --dry-run for test/report planning. No actions performed.' >&2
    exit 2
  fi
done
for ui_arg in "$@"; do
  if [ "$ui_arg" = --interactive ]; then
    printf '%s\n' 'Interactive questions run in the agent UI. Invoke $test-coverage --interactive.' >&2
    exit 2
  fi
done
source "$(dirname "${BASH_SOURCE[0]}")/common.sh"
provider=${1:-base}
case "$provider" in base|coverlet|dotcover|v8|istanbul|pester|kcov) :;; *) fail "Unknown installer: $provider";; esac
ensure_jq
case "$provider" in
  base) ensure_yq ;;
  coverlet) ensure_yq; ensure_dotnet_tool coverlet.console coverlet ;;
  dotcover) ensure_yq; ensure_dotnet_tool JetBrains.dotCover.CommandLineTools dotCover ;;
  v8|istanbul)
    need node; need npm
    project=${2:?Supply the TypeScript package directory}
    cd "$project"
    [ -f package.json ] || fail 'TypeScript project requires package.json'
    # Prefer the existing package manager; installing the provider is an explicit dependency change.
    version=$(node -p 'try { require("vitest/package.json").version } catch (_) { "" }')
    matched=0
    if [ -n "$version" ] && node -e 'process.exit(require("@vitest/coverage-"+process.argv[1]+"/package.json").version===process.argv[2]?0:1)' "$provider" "$version" 2>/dev/null; then matched=1; fi
    if [ "$matched" -eq 0 ]; then
    if [ -n "$version" ]; then packages=("@vitest/coverage-$provider@$version")
    else packages=(vitest "@vitest/coverage-$provider"); fi
    if [ -f pnpm-lock.yaml ]; then need pnpm; pnpm add -D --save-exact "${packages[@]}" >&2
    elif [ -f yarn.lock ]; then need yarn; yarn add -D --exact "${packages[@]}" >&2
    elif [ -f bun.lock ] || [ -f bun.lockb ]; then need bun; bun add -d --exact "${packages[@]}" >&2
    else npm install --save-dev --save-exact "${packages[@]}" >&2; fi
    fi
    ;;
  pester)
    need pwsh
    mkdir -p "$TC_CACHE/modules"
    export TC_MODULES=$(native_path "$TC_CACHE/modules")
    pwsh -NoProfile -NonInteractive -Command '$ErrorActionPreference="Stop"; $existing=Get-ChildItem "$env:TC_MODULES/Pester/*/Pester.psd1" -ErrorAction SilentlyContinue; if($env:TEST_COVERAGE_PESTER_VERSION){$existing=$existing|Where-Object{$_.Directory.Name -eq $env:TEST_COVERAGE_PESTER_VERSION}}; if(-not $existing){$p=@{Name="Pester";Repository="PSGallery";Path=$env:TC_MODULES;Force=$true;AcceptLicense=$true}; if($env:TEST_COVERAGE_PESTER_VERSION){$p.RequiredVersion=$env:TEST_COVERAGE_PESTER_VERSION}; Save-Module @p}' >&2
    ;;
  kcov)
    if { [ "$TC_OS" = macos ] || [ "$TC_OS" = linux ]; } && command -v kcov >/dev/null 2>&1 && command -v bats >/dev/null 2>&1; then
      :
    elif [ "$TC_OS" = linux ]; then
      fail "Linux/WSL2 coverage needs native bats and kcov on PATH. See languages/bash/environment.md; Docker is not selected automatically."
    elif [ "$TC_OS" = macos ] && command -v brew >/dev/null 2>&1; then
      command -v kcov >/dev/null 2>&1 || brew install kcov >&2
      command -v bats >/dev/null 2>&1 || brew install bats-core >&2
    else
      need docker; docker info >/dev/null 2>&1 || fail 'Docker is installed but its engine is not running. Start Docker Desktop and retry.'
      docker image inspect kcov/kcov:latest >/dev/null 2>&1 || docker pull kcov/kcov:latest >&2
      need git
      if [ ! -d "$TC_CACHE/bats/.git" ]; then
        mkdir -p "$TC_CACHE"
        tag=$(curl -fsSL https://api.github.com/repos/bats-core/bats-core/releases/latest | jq -r .tag_name)
        [ -n "$tag" ] && [ "$tag" != null ] || fail 'Cannot resolve stable bats-core release'
        git clone --depth 1 --branch "$tag" https://github.com/bats-core/bats-core.git "$TC_CACHE/bats" >&2
      fi
    fi
    ensure_yq
    ;;
  *) fail "Unknown installer: $provider" ;;
esac
jq -n --arg provider "$provider" --arg os "$TC_OS" --arg cache "$TC_CACHE" --arg jq "$(jq --version)" '{provider:$provider,os:$os,cache:$cache,jq:$jq,status:"ready"}'
