#!/usr/bin/env bash
# Collect once; an agent owns semantic classification and the test-writing loop.
set -euo pipefail
# Handle UI entry modes before common.sh can create directories or install tools.
if [ "$#" -eq 0 ]; then bash "$(dirname "${BASH_SOURCE[0]}")/help.sh"; exit 0; fi
for ui_arg in "$@"; do
  if [ "$ui_arg" = --help ]; then bash "$(dirname "${BASH_SOURCE[0]}")/help.sh"; exit 0; fi
done
for ui_arg in "$@"; do
  if [ "$ui_arg" = --dry-run ] || [ "$ui_arg" = --check ]; then
    printf '%s\n' 'Preview/check must use root install.sh for installation, or the agent skill --dry-run for test/report planning. No actions performed.' >&2
    exit 2
  fi
done
for ui_arg in "$@"; do
  if [ "$ui_arg" = --interactive ]; then
    printf '%s\n' 'Interactive questions run in the agent UI. Invoke $test-coverage --interactive.' >&2
    exit 2
  fi
done
source "$(dirname "${BASH_SOURCE[0]}")/common.sh"
source "$(dirname "${BASH_SOURCE[0]}")/validate.sh"
repo= project= language=csharp framework= provider=auto scope= output= runtime= target='line=100,branch=100'
seen=' '
while [ "$#" -gt 0 ]; do
  [[ "$seen" != *" $1 "* ]] || fail "Duplicate collection option: $1"
  seen="$seen$1 "
  [ "$#" -ge 2 ] && [ -n "$2" ] && [[ "$2" != --* ]] || fail "Missing value for $1"
  case "$1" in
    --repo) repo=$2;; --project) project=$2;; --language) language=$2;;
    --framework) framework=$2;; --coverage-tool) provider=$2;; --scope) scope=$2;;
    --output) output=$2;; --runtime) runtime=$2;; --coverage) target=$2;;
    *) fail "Unknown collection option: $1";;
  esac
  shift 2
done
[ -n "$repo" ] && [ -n "$project" ] && [ -f "$scope" ] && [ -n "$output" ] || fail 'Required: --repo --project --scope --output'
repo=$(absolute_path "$repo"); project=$(absolute_path "$project"); scope=$(absolute_path "$scope")
[ ! -e "$output" ] || fail 'Output must be a new directory for this run'
if [ "$provider" = auto ]; then
  case "$language" in csharp) provider=coverlet;; typescript) provider=v8;; powershell) provider=pester;; bash) provider=kcov;; *) fail "Unknown language: $language";; esac
fi
case "$language:$provider" in csharp:coverlet|csharp:dotcover|typescript:v8|typescript:istanbul|powershell:pester|bash:kcov) :;; *) fail 'Language and coverage provider are incompatible';; esac
case "$language:${framework:-auto}" in csharp:auto|csharp:nunit|csharp:xunit|typescript:auto|typescript:vitest|powershell:auto|powershell:pester|bash:auto|bash:bats) :;; *) fail 'Language and test framework are incompatible';; esac
ensure_jq
validate_target "$target" >/dev/null || fail 'Invalid coverage target'
validate_scope "$scope"
[ "$root" = "$repo" ] || fail 'Scope root must equal --repo'
mkdir -p "$output/raw"; RUN=$(absolute_path "$output"); output=$RUN
cd "$repo"
bash "$TC_ROOT/scripts/install.sh" "$provider" "$project" >"$RUN/install.json"
ensure_jq
started=$(date -u '+%Y-%m-%dT%H:%M:%SZ')
source_hashes() {
  while IFS= read -r f; do
    [ -f "$repo/$f" ] || fail "Scope file missing: $f"
    jq -n --arg file "$f" --arg hash "$(sha256 "$repo/$f")" '{file:$file,sha256:$hash}'
  done < <(jq -r '.files[]' "$scope")
}
# Bind the run to the source inventory, not just a potentially dirty git commit.
[ "$(absolute_path "$(jq -r .root "$scope")")" = "$repo" ] || fail 'Scope root must equal --repo'
source_hashes | jq -s . >"$RUN/source-before.json"
TEST_EXIT=0
report_args=()
case "$provider" in
  coverlet|dotcover)
    need dotnet
    case "$project" in *.csproj) :;; *) fail '.NET --project must identify one test .csproj';; esac
    args=("$(native_path "$project")")
    if [ -n "$runtime" ]; then
      case "$runtime" in net[0-9]*.0) :;; *) fail 'Collector --runtime is one exact TFM, for example net8.0 or net10.0';; esac
      args+=(--framework "$runtime")
    fi
    dotnet build "${args[@]}" >"$RUN/build.log" 2>&1 || { cat "$RUN/build.log" >&2; fail 'Build failed before collection'; }
    # Framework choice must be singular; never merge unrelated target frameworks.
    props=("$(native_path "$project")" -getProperty:TargetPath)
    [ -z "$runtime" ] || props+=("-p:TargetFramework=$runtime")
    dll=$(dotnet msbuild "${props[@]}" | tr -d '\r')
    [ -f "$dll" ] || fail 'Cannot resolve one test assembly; supply --runtime for a multi-target project'
    test_project=$(native_path "$project"); results=$(native_path "$RUN/raw")
    case "$test_project$results" in *\"*) fail 'Embedded quotes in paths are unsupported by the native collector argument format';; esac
    testargs="test \"$test_project\" --no-build --logger trx --results-directory \"$results\""
    [ -z "$runtime" ] || testargs="$testargs --framework $runtime"
    # New xUnit packages may use an in-process executable rather than VSTest.
    # Inspect its advertised switches; never pass VSTest options to that runner.
    deps="${dll%.dll}.deps.json"
    if [ -f "$deps" ] && jq -e '.libraries|keys|any(startswith("xunit.v3.runner.inproc.console/"))' "$deps" >/dev/null; then
      dotnet "$dll" --help >"$RUN/runner-help.txt" 2>&1 || true
      if grep -q -- '-result-trx' "$RUN/runner-help.txt"; then
        testargs="\"$dll\" -result-trx \"$results/tests.trx\""
      elif grep -q -- '--report-trx' "$RUN/runner-help.txt"; then
        testargs="\"$dll\" --report-trx --results-directory \"$results\""
      else fail 'The xUnit executable does not advertise a supported TRX exporter; use native collection and import'; fi
    fi
    if [ "$provider" = coverlet ]; then
      capture coverlet "$dll" --target dotnet --targetargs "$testargs" --format cobertura --output "$(native_path "$RUN/raw/coverage.cobertura.xml")"
      input="$RUN/raw/coverage.cobertura.xml"
    else
      capture dotCover cover --target-executable "$(native_path "$(command -v dotnet)")" --target-arguments "$testargs" --json-report-output "$(native_path "$RUN/raw/coverage.json")" --snapshot-output "$(native_path "$RUN/raw/coverage.dcvr")"
      input="$RUN/raw/coverage.json"
    fi
    trx= count=0
    while IFS= read -r f; do trx=$f; count=$((count+1)); done < <(find "$RUN/raw" -name '*.trx' -type f)
    [ "$count" -eq 1 ] || fail 'Expected one TRX report; zero or multiple test results are unresolved'
    xml_json "$trx" | jq --argjson code "$TEST_EXIT" '.TestRun.ResultSummary.Counters|{total:(."@total"|tonumber),failed:(."@failed"|tonumber),skipped:(."@notExecuted"|tonumber),exitCode:$code,verified:true}' >"$RUN/tests.json"
    ;;
  v8|istanbul)
    cd "$project"
    # Each predeclared source must be in the instrumentation inventory, including unimported files.
    includes=()
    while IFS= read -r f; do includes+=("--coverage.include=$(native_path "$repo/$f")"); done < <(jq -r '.files[]' "$scope")
    capture npx --no-install vitest run --coverage.enabled --coverage.provider="$provider" --coverage.reporter=json --coverage.reportsDirectory="$(native_path "$RUN/raw")" --reporter=json --outputFile="$(native_path "$RUN/raw/tests.json")" "${includes[@]}"
    input="$RUN/raw/coverage-final.json"
    jq --argjson code "$TEST_EXIT" '{total:.numTotalTests,failed:.numFailedTests,skipped:.numPendingTests,exitCode:$code,verified:true}' "$RUN/raw/tests.json" >"$RUN/tests.json"
    ;;
  pester)
    export TC_MODULES=$(native_path "$TC_CACHE/modules") TC_PROJECT=$(native_path "$project") TC_SCOPE=$(native_path "$scope") TC_RUN=$(native_path "$RUN")
    # Invoke the framework API directly; no PowerShell script files are installed.
    capture pwsh -NoProfile -NonInteractive -Command '
      $ErrorActionPreference="Stop"
      $m=Get-ChildItem "$env:TC_MODULES/Pester/*/Pester.psd1" | Sort-Object { [version]$_.Directory.Name } -Descending | Select-Object -First 1
      if($env:TEST_COVERAGE_PESTER_VERSION){$m=Get-Item "$env:TC_MODULES/Pester/$env:TEST_COVERAGE_PESTER_VERSION/Pester.psd1"}
      Import-Module $m.FullName -Force
      $s=Get-Content -Raw $env:TC_SCOPE | ConvertFrom-Json
      $c=New-PesterConfiguration
      $c.Run.Path=$env:TC_PROJECT; $c.Run.PassThru=$true
      $c.CodeCoverage.Enabled=$true; $c.CodeCoverage.Path=@($s.files | ForEach-Object { Join-Path $s.root $_ })
      $c.CodeCoverage.OutputPath="$env:TC_RUN/raw/pester.xml"
      $r=Invoke-Pester -Configuration $c
      $items=@(); $i=0
      foreach($hit in @(@{Rows=$r.CodeCoverage.CommandsExecuted;Hits=1},@{Rows=$r.CodeCoverage.CommandsMissed;Hits=0})) {
        foreach($row in $hit.Rows) {
          if($null -eq $row) { continue }; $i++
          $id="$($row.Line):$($row.StartColumn):$($row.EndColumn):$($row.Command)"
          $items+=@{file=$row.File;metric="command";line=$row.Line;id=$id;hits=$hit.Hits}
        }
      }
      @{items=$items;native=$r.CodeCoverage}|ConvertTo-Json -Depth 30|Set-Content "$env:TC_RUN/raw/coverage.json"
      @{total=$r.TotalCount;failed=$r.FailedCount;skipped=$r.SkippedCount;exitCode=$(if($r.Result -ne "Passed"){1}else{0});verified=$true}|ConvertTo-Json|Set-Content "$env:TC_RUN/tests.json"
      if($r.Result -ne "Passed"){exit 1}'
    input="$RUN/raw/coverage.json"
    # A host error cannot be hidden by partial Pester output.
    [ "$TEST_EXIT" -eq 0 ] || jq --argjson code "$TEST_EXIT" '.exitCode=$code' "$RUN/tests.json" >"$RUN/tests.tmp"
    [ ! -f "$RUN/tests.tmp" ] || mv "$RUN/tests.tmp" "$RUN/tests.json"
    ;;
  kcov)
    if { [ "$TC_OS" = macos ] || [ "$TC_OS" = linux ]; } && command -v kcov >/dev/null 2>&1 && command -v bats >/dev/null 2>&1; then
      capture kcov --include-path="$repo" "$RUN/raw/kcov" "$(command -v bats)" --formatter tap "$project"
    else
      case "$project" in "$repo"/*) test_relative=${project#"$repo/"};; *) fail 'Docker Bats test directory must be inside --repo';; esac
      report_args+=(--source-prefix /work)
      # Disable Git Bash automatic /work argument conversion for the Linux container.
      capture env MSYS_NO_PATHCONV=1 docker run --rm --security-opt seccomp=unconfined \
        -v "$(native_path "$repo"):/work" -v "$(native_path "$RUN/raw"):/reports" \
        -v "$(native_path "$TC_CACHE/bats"):/bats:ro" -w /work kcov/kcov:latest \
        --include-path=/work /reports/kcov /bats/bin/bats --formatter tap "/work/$test_relative"
    fi
    input="$RUN/raw/kcov/kcov-merged/cobertura.xml"
    [ -f "$input" ] || fail 'kcov did not produce its merged Cobertura report; inspect raw output'
    total=$(awk '/^(not )?ok [0-9]+/{n++} END{print n+0}' "$RUN/log.txt")
    failed=$(awk '/^not ok [0-9]+/{n++} END{print n+0}' "$RUN/log.txt")
    skipped=$(awk '/^ok [0-9]+.*#[[:space:]]*[Ss][Kk][Ii][Pp]/{n++} END{print n+0}' "$RUN/log.txt")
    jq -n --argjson total "$total" --argjson failed "$failed" --argjson skipped "$skipped" --argjson code "$TEST_EXIT" '{total:$total,failed:$failed,skipped:$skipped,exitCode:$code,verified:true}'  >"$RUN/tests.json"
    ;;
esac
[ -f "$input" ] || fail 'The coverage tool did not produce a native report. Inspect log.txt; no coverage gate can be evaluated.'
source_hashes | jq -s . >"$RUN/source-after.json"
cmp -s "$RUN/source-before.json" "$RUN/source-after.json" || fail 'Source changed during collection; discard this run and recollect'
jq -n --arg started "$started" --arg os "$TC_OS" --arg language "$language" --arg runtime "$runtime" --arg project "$(native_path "$project")" --arg provider "$provider" --argjson exitCode "$TEST_EXIT" '{started:$started,os:$os,language:$language,runtime:$runtime,project:$project,provider:$provider,exitCode:$exitCode}' >"$RUN/run.json"
bash "$TC_ROOT/scripts/report.sh" --coverage-tool "$provider" --input "$input" --scope "$scope" --tests "$RUN/tests.json" --coverage "$target" --output "$RUN/report" ${report_args[@]+"${report_args[@]}"}
