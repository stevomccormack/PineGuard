#!/usr/bin/env bash
# Normalize native evidence. All numbers remain provider-specific.
set -euo pipefail
# Handle UI entry modes before common.sh can create directories or install tools.
if [ "$#" -eq 0 ]; then bash "$(dirname "${BASH_SOURCE[0]}")/help.sh"; exit 0; fi
for ui_arg in "$@"; do
  if [ "$ui_arg" = --help ]; then bash "$(dirname "${BASH_SOURCE[0]}")/help.sh"; exit 0; fi
done
for ui_arg in "$@"; do
  if [ "$ui_arg" = --dry-run ] || [ "$ui_arg" = --check ]; then
    printf '%s\n' 'Preview/check must use root install.sh for installation, or the agent skill --dry-run for test/report planning. No actions performed.' >&2
    exit 2
  fi
done
for ui_arg in "$@"; do
  if [ "$ui_arg" = --interactive ]; then
    printf '%s\n' 'Interactive questions run in the agent UI. Invoke $test-coverage --interactive.' >&2
    exit 2
  fi
done
source "$(dirname "${BASH_SOURCE[0]}")/common.sh"
trap 'printf "Coverage input could not be normalized; inspect the parser diagnostic above.\n" >&2; exit 2' ERR
source "$(dirname "${BASH_SOURCE[0]}")/validate.sh"
provider= input= scope= output= tests= prefix= target='line=100,branch=100'
seen=' '
while [ "$#" -gt 0 ]; do
  [[ "$seen" != *" $1 "* ]] || fail "Duplicate report option: $1"
  seen="$seen$1 "
  [ "$#" -ge 2 ] && [ -n "$2" ] && [[ "$2" != --* ]] || fail "Missing value for $1"
  case "$1" in
    --coverage-tool) provider=$2;; --input) input=$2;; --scope) scope=$2;;
    --output) output=$2;; --tests) tests=$2;; --coverage) target=$2;; --source-prefix) prefix=$2;;
    *) fail "Unknown report option: $1";;
  esac
  shift 2
done
[ -n "$provider" ] && [ -f "$input" ] && [ -f "$scope" ] && [ -n "$output" ] || fail 'Required: --coverage-tool --input --scope --output; optional --tests --coverage'
case "$provider" in coverlet|dotcover|v8|istanbul|pester|kcov) :;; *) fail "Unknown provider: $provider";; esac
ensure_jq
validate_target "$target" >/dev/null
validate_scope "$scope"
input=$(absolute_path "$input"); scope=$(absolute_path "$scope")
mkdir -p "$output"; output=$(absolute_path "$output")
[ ! -e "$output/coverage.json" ] || fail 'Use a fresh output directory; an existing report is never overwritten'
work=$(mktemp -d); trap 'rm -f "$work/native.json" "$work/items.json" "$work/tests.json" "$work/targets.json"; rmdir "$work"' EXIT
[ -n "$prefix" ] || prefix=$(native_path "$root")

case "$provider" in
  coverlet|kcov)
    xml_json "$input" >"$work/native.json"
    jq '
      def arr: if .==null then [] elif type=="array" then . else [.] end;
      (.coverage.sources.source|arr) as $sources |
      def filename($f): if ($f|test("^([A-Za-z]:[/\\\\]|/)")) or ($sources|length)==0 then $f
        elif ($sources|length)==1 then ($sources[0]|sub("[/\\\\]+$";""))+"/"+$f
        else error("Multiple Cobertura source roots require explicit source mapping") end;
      [.coverage.packages.package|arr[]|.classes.class|arr[]|. as $c|
        .lines.line|arr[]|. as $l|
        {file:filename($c."@filename"),metric:"line",line:($l."@number"|tonumber),
         id:($l."@number"|tostring),hits:($l."@hits"|tonumber)},
        (if ($l."@branch"|tostring|ascii_downcase)=="true" then
           ($l."@condition-coverage"|capture("\\((?<covered>[0-9]+)/(?<total>[0-9]+)\\)")) as $b|
           {file:filename($c."@filename"),metric:"branch",line:($l."@number"|tonumber),
            id:($l."@number"|tostring),covered:($b.covered|tonumber),total:($b.total|tonumber)}
         else empty end)]' "$work/native.json" >"$work/items.json"
    capabilities='["line","branch"]'; [ "$provider" != kcov ] || capabilities='["line"]'
    ;;
  v8|istanbul)
    jq '[to_entries[]|.value as $f|
      ($f.s|to_entries[]|{file:$f.path,metric:"line",line:$f.statementMap[.key].start.line,
       id:($f.statementMap[.key].start.line|tostring),hits:.value}),
      ($f.b|to_entries[]|. as $b|.value|to_entries[]|
       {file:$f.path,metric:"branch",line:$f.branchMap[$b.key].line,
        id:($b.key+":"+(.key|tostring)),covered:(if .value>0 then 1 else 0 end),total:1})]' "$input" >"$work/items.json"
    capabilities='["line","branch"]'
    ;;
  pester)
    jq -e '.items|type=="array"' "$input" >/dev/null || fail 'Expected the Pester collector command export'
    jq '.items' "$input" >"$work/items.json"; capabilities='["command"]'
    ;;
  dotcover)
    # dotCover native JSON summary has no reliable file-to-line/branch mapping.
    # Retain the native report, but leave scoped counters unresolved.
    jq -e 'type=="object"' "$input" >/dev/null || fail 'Invalid dotCover JSON'
    printf '[]\n' >"$work/items.json"; capabilities='["statement"]'
    ;;
  *) fail "Unknown provider: $provider";;
esac
jq -e 'type=="array" and all(.[]; (.file|type=="string") and (.id|type=="string" and length>0) and (.line|type=="number" and isfinite and .>0 and floor==.) and (.metric=="line" or .metric=="branch" or .metric=="command") and (if .metric=="branch" then (.covered|type=="number") and (.total|type=="number") and .covered>=0 and .total>=.covered and .total>0 and (.covered|floor)==.covered and (.total|floor)==.total else (.hits|type=="number" and isfinite and floor==.) and .hits>=0 and (.line|type=="number") and .line>0 end))' "$work/items.json" >/dev/null || fail 'Malformed native coverage counters or locations'
if [ -n "$tests" ]; then
  validate_tests "$tests"
  cp "$tests" "$work/tests.json"
else printf '{"total":0,"failed":0,"exitCode":null,"verified":false}\n' >"$work/tests.json"; fi
validate_target "$target" >"$work/targets.json"
jq -n --slurpfile items "$work/items.json" --slurpfile scope "$scope" --slurpfile tests "$work/tests.json" --slurpfile targets "$work/targets.json" \
  --arg root "$prefix" --arg provider "$provider" --arg input "$(native_path "$input")" --argjson capabilities "$capabilities" '
  def norm: gsub("\\\\";"/")|sub("^\\./";"");
  def relative($r): norm|if startswith($r+"/") then .[($r|length)+1:] else . end;
  ($root|norm) as $r |
  ($items[0]|map(.file=(.file|relative($r)))|group_by([.file,.metric,.id])|
    map(if .[0].metric=="branch" then
       if length>1 then .[0]+{conflict:true} else .[0] end
      else max_by(.hits) end)) as $all |
  ($scope[0].files) as $files |
  ($all|map(select(.file as $f|$files|index($f)))) as $selected |
  ($files-($selected|map(.file)|unique)) as $missing |
  ($tests[0]) as $t | ($targets[0]) as $targets |
  {schemaVersion:1,provider:$provider,scope:$scope[0],nativeReport:$input,capabilities:$capabilities,
   tests:$t,targets:$targets,missingFiles:$missing,unmatchedFiles:($all|map(.file)|unique|.-$files),
   conflicts:[$selected[]|select(.conflict==true)],
   metrics:[$capabilities[] as $metric|($selected|map(select(.metric==$metric))) as $rows|
     {metric:$metric,total:([$rows[]|if $metric=="branch" then .total else 1 end]|add//0),
      covered:([$rows[]|if $metric=="branch" then .covered elif .hits>0 then 1 else 0 end]|add//0)}|
      .+{percent:(if .total>0 then 100*.covered/.total else null end)}],
   gaps:[$selected[]|select(if .metric=="branch" then .covered<.total else .hits==0 end)],
   items:$selected} |
  .unsupported=[$targets|keys[] as $m|select($capabilities|index($m)|not)|$m] |
  .status=(if ($t.exitCode!=null and $t.exitCode!=0) or ($t.failed//0)>0 then "test-failed"
    elif (.unsupported|length)>0 then "unsupported"
    elif (.missingFiles|length)>0 or (.conflicts|length)>0 or $provider=="dotcover" then "unresolved"
    elif ($t.verified!=true or $t.total<=0 or ($t.total-($t.skipped//0))<=0 or $t.exitCode!=0) then "unverified"
    elif any(.metrics[]; . as $m|($targets[$m.metric]!=null) and
       (if $m.total==0 then $m.metric!="branch" else $m.covered*100<$targets[$m.metric]*$m.total end)) then "gap"
    else "pass" end)' >"$output/coverage.json"
cp "$scope" "$output/scope.json"
{
  printf '<!doctype html><html lang="en"><meta charset="utf-8"><title>Coverage report</title><style>body{font:16px system-ui;max-width:1100px;margin:40px auto;padding:20px}table{border-collapse:collapse;width:100%%}th,td{text-align:left;border-bottom:1px solid #ccc;padding:8px}code{overflow-wrap:anywhere}details{margin:18px 0}.status{font-size:24px;font-weight:bold}</style><h1>Coverage report</h1>'
  jq -r '"<p class=\"status\">"+(.status|@html)+"</p><p>Provider: "+(.provider|@html)+". Percentages describe the declared scope only.</p><table><tr><th>Metric</th><th>Covered</th><th>Total</th><th>Percent</th></tr>",(.metrics[]|"<tr><td>"+.metric+"</td><td>"+(.covered|tostring)+"</td><td>"+(.total|tostring)+"</td><td>"+(.percent//"N/A"|tostring)+"</td></tr>"),"</table><h2>Uncovered locations</h2>",(.gaps[]|"<p><code>"+(.file|@html)+":"+(.line//0|tostring)+"</code> — "+.metric+" "+(.id|@html)+"</p>"),"<h2>Evidence and limitations</h2><pre>"+({tests,unsupported,missingFiles,conflicts}|tojson|@html)+"</pre></html>"' "$output/coverage.json"
} >"$output/coverage.html"
status=$(jq -r .status "$output/coverage.json")
printf '%s: %s\n' "$status" "$(native_path "$output/coverage.html")"
case "$status" in pass) exit 0;; gap) exit 1;; test-failed) exit 3;; unsupported) exit 4;; *) exit 5;; esac
