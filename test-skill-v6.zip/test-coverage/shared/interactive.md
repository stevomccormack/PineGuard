# Interactive coverage

Follow [question flow](questions.md). This wizard configures measurement; test generation remains with test:tdd.

## 1. Goal

Ask: **What would you like to do?**

- **Measure existing tests:** use collect.sh.
- **Create reports from existing coverage:** use report.sh.
- **Install coverage tools only:** use install.sh.

If the user instead wants new tests, route to test:tdd while retaining supplied repository and preferences. Do not pretend collection creates tests.

## 2. Inputs

For collection, discover the repository and runnable test project/package. Let the user select from real candidates or enter paths. Infer language/framework/runtime; ask only unresolved choices. In .NET resolve one exact TFM per run.

For reporting, ask for the native coverage file and its producer if not identifiable, then the matching test evidence file if available. Explain that evidence without a verified matching test run can produce a report but cannot pass a gate.

For install-only, ask language/provider and the package directory if needed for Vitest. Skip scope and threshold questions; proceed to review with the actual installation destination and dependency changes.

## 3. Source inventory

For collection/reporting ask: **How should we select the source inventory?**

- **Use an existing manifest:** choose/enter an actual JSON manifest path.
- **Prepare an inventory from selected files:** choose/enter source files or an area for read-only discovery.

Review the concrete discovered file list or a concise count/summary with its manifest path before execution. Prepare the manifest after Run, within the selected output area. A manifest supplied by TDD retains its classification. Standalone source selection is labelled source-scope coverage, not automatically strong code. Mixed-file method-only selection remains unsupported; explain that before running.

## 4. Provider and target

Recommend a compatible provider: Coverlet for .NET line/branch, V8 for Vitest, Pester for PowerShell, kcov for Bash. If a choice is needed, offer compatible providers only and explain relevant limits. Never imply dotCover supports line/branch or that its scoped statement normalization is complete.

Explain the default 100/100 target against the selected inventory. Offer recommended supported metrics versus custom percentages; preserve existing explicit requests. For unsupported defaults, explicitly offer the supported metric target or retaining the original request with an unsupported outcome. For a report import, use its actual producer rather than changing the producer to manufacture a capability.

Ask for an output location only if the user needs to choose; otherwise propose a fresh artifacts directory. For imported path mismatches, ask for a concrete `--source-prefix` only after examining the real paths. Do not guess from basenames.

## 5. Review

Show the selected script, concrete argument values, expected JSON/HTML paths and limitations. If preparing a new manifest, show its proposed contents/path; command-only must also return those contents so the command is usable. Use the shared Run / Change / Command-only choices. On Run, create the approved configuration artifacts and execute the ordinary skill workflow.

The install-only action uses the **root** `install.sh`; do not call the positional internal adapter from the wizard. With `--dry-run`, review produces a preview without creating the manifest or report directories.
