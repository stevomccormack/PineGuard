# Capabilities

This is the current implementation boundary. Provider documentation is not proof that this skill has implemented every provider feature.

| Capability | Current support |
|---|---|
| C# NUnit / xUnit | Coverlet convenience collector for documented tested runner combinations; other runner setups use native collection/import |
| TypeScript | Vitest V8/Istanbul JSON normalization; source maps must resolve to the selected TypeScript files |
| PowerShell | Pester command coverage; line/branch targets remain unsupported |
| Bash | Bats + kcov line coverage; Ubuntu WSL2 recommended on Windows with native tools. Git Bash coverage fallback uses Docker. No branch gate |
| Bash concurrency | Native Bats jobs documented; convenience collection stays serial with no `--jobs` forwarding or parallel-backend installation. Native parallel coverage requires separate verification |
| dotCover | Native collection attempt and retained evidence; scoped statement normalization unresolved, line/branch unsupported |
| Reports | Both normalized JSON and standalone summary HTML on a completed normalization run; no CLI report selection or browser-opening switch yet |
| Shared ReportGenerator template | Compatible upstream route for Coverlet/dotCover native reports; not integrated into the current pipeline |
| Diff-only measurement | Changed-line and changed-branch gates are not implemented. Selecting changed files measures their whole contents and must be labelled that way |
| Strong methods in mixed files | Test generation supported; isolated coverage attribution unresolved |
| Dry run | Root installer dependency preview; other workflow previews are agent planning, not executable script planners |
| macOS / Windows | Bash 3.2-compatible orchestration; Git Bash paths exercised. Native macOS and WSL2 end-to-end/performance checks remain outstanding |

Before presenting a command, distinguish supported options from proposals. In particular do not emit `--diff`, `--base`, `--report` or `--open` as implemented flags. A user asking for these capabilities gets the precise limitation plus the closest explicitly labelled existing workflow; do not silently substitute changed-file coverage for changed-line coverage.

[ReportGenerator](https://github.com/danielpalme/ReportGenerator) accepts multiple native formats for common HTML rendering. [dotCover's metric](https://www.jetbrains.com/help/dotcover/dotCover__Basic_Concepts.html) is statement coverage. A common template does not make metrics equivalent. Verified against primary documentation during the 2026-09-10 review.
