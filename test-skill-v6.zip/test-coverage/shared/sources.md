# Sources

Checked 2026-09-09; recheck stable releases and compatibility when installing or changing adapters.

- [Coverlet](https://github.com/coverlet-coverage/coverlet), [console tool](https://github.com/coverlet-coverage/coverlet/blob/master/Documentation/GlobalTool.md).
- [dotCover CLI](https://www.jetbrains.com/help/dotcover/Coverage-Analysis-with-Command-Line-Tool.html), [statement coverage](https://www.jetbrains.com/help/dotcover/Getting_Started_with_dotCover.html).
- [Vitest coverage](https://vitest.dev/guide/coverage).
- [Pester configuration](https://pester.dev/docs/usage/configuration), [coverage](https://pester.dev/docs/usage/code-coverage), [v6 migration](https://pester.dev/docs/migrations/v5-to-v6).
- [kcov](https://github.com/SimonKagstrom/kcov), [Bats](https://bats-core.readthedocs.io/en/stable/).
- [jq releases](https://github.com/jqlang/jq/releases), [yq XML](https://mikefarah.gitbook.io/yq/usage/xml).

PineGuard supplied the useful separation of measurement from test generation and known-count parser fixtures. Its library architecture, historical tool limitations and broad exclusions were not copied as universal policy. Detailed provenance remains in [test:tdd research](../../test-tdd/research/pineguard.md).
