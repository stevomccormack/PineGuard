# Reports

Collection writes `install.json`, `build.log` where applicable, `log.txt`, `run.json`, before/after source hashes, `tests.json`, native files under `raw/`, and normalized `report/coverage.json` plus `report/coverage.html`. HTML is standalone, escapes native filenames and exposes limitations. JSON is the AI contract.

Schema version 1 contains provider, declared scope, native report path, capabilities, test evidence, requested targets, exact metric counters, source items, uncovered gaps, missing/unmatched files, attribution conflicts and status. Missing or unsupported values are never converted into 100%.

| Status / exit | Meaning | TDD response |
|---|---|---|
| `pass` / 0 | Measured requested counters meet target and test evidence is valid | Review assertion quality and report scoped completion |
| `gap` / 1 | Supported metrics below target | Classify each gap, add justified VIBE cases, collect again |
| configuration/tool error / 2 | Invocation, installation, build or input invalid | Fix the concrete collection problem; raw diagnostics may exist without a final report |
| `test-failed` / 3 | Tests or instrumented target failed | Diagnose before using percentages |
| `unsupported` / 4 | Provider cannot measure a requested metric | Keep target; select capable provider or report limitation |
| `unresolved` or `unverified` / 5 | Missing attribution/inventory or insufficient test evidence | Resolve evidence; never add tests merely to hide this status |

100% uses integer counts: every measured item covered. Other thresholds use covered × 100 against target × total, without rounded display percentages. A branchless measured scope has branch total 0 and percent null; it can satisfy a branch target only while meaningful line/command evidence exists. An empty or missing source inventory does not pass.

Coverlet Cobertura aggregates branches by source line, so gaps expose missed branch counts per line, not a guaranteed true/false identity. Multiple branch records with the same file/line identity remain unresolved, even if their counters match: this format cannot establish whether they are duplicates or distinct decisions. TypeScript uses Istanbul source-mapped records; executable lines derive from statement starting lines, branch arms retain their native IDs. Pester measures commands. kcov measures lines. dotCover's native report is retained but the current normalizer does not certify file-scoped statement attribution.

For imported reports, `--tests` accepts `{ "total": 7, "failed": 0, "skipped": 0, "exitCode": 0, "verified": true }`. Set verified only from matching test-run evidence. This is a trusted caller attestation, not cryptographic verification. Without it the report cannot pass. Never reuse evidence from another source revision/run.

Coverage is execution evidence, not assertion quality, exhaustive input testing, MC/DC, or proof of business intent. The coverage skill does not decide exclusions or semantically classify source. TDD owns those judgments.

Test evidence requires integer counts, failed + skipped no greater than total, a boolean verification marker and an integer/null exit status. Duplicate target metrics are invalid rather than last-value-wins. Existing outputs remain protected. Imported evidence still relies on the caller linking tests and native coverage to the same source/run; these validations cannot prove semantic provenance.
