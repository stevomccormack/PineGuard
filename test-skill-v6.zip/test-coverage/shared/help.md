# test:coverage — measure tests and produce reports

Use this skill for measurement and JSON/HTML reports. To create tests, use test:tdd.

| What do you want to do? | Choose |
|---|---|
| Run existing tests and measure coverage | `scripts/collect.sh` |
| Turn an existing native report into JSON/HTML | `scripts/report.sh` |
| Install coverage tools only | `--install --language …` or root `install.sh` |
| Be guided through the choices | `$test-coverage --interactive` |

For **collection**, supply `--repo`, `--project`, `--scope` and `--output`. Optional: `--language`, `--framework`, `--runtime`, `--coverage-tool`, `--coverage`.

For **an existing report**, supply `--coverage-tool`, `--input`, `--scope` and `--output`. Optional: `--tests`, `--coverage`, `--source-prefix`. Matching test evidence is needed for a passing gate.

Here `--scope` is a **JSON source-inventory file**, not a folder or symbol. The agent can help prepare it. `--project` selects executable tests; `--output` identifies a fresh run. The .NET collector needs an exact runtime such as `net8.0`, not `dotnet8.0+`.

The default `--coverage line=100,branch=100` applies to the declared inventory, not automatically the whole repository. TDD supplies its classified local scope. This skill does not decide which business rules are strong or write more tests.

Coverlet and Vitest support line/branch evidence. Pester measures commands; kcov measures lines. Choosing `command=100` or `line=100` is an explicit different target. dotCover does not establish line/branch coverage and has documented implementation/host limitations. Unsupported targets never silently pass.

```text
$test-coverage --interactive
```

```bash
bash "$HOME/.codex/skills/test-coverage/scripts/collect.sh" --help
bash "$HOME/.codex/skills/test-coverage/install.sh" --language csharp --dry-run
```

Providers: `coverlet`, `dotcover`, `v8`, `istanbul`, `pester`, `kcov`. See [all options](options.md) for the exact arguments and [capabilities](capabilities.md) for current limitations.

`--help` takes no value and only displays help. A bare skill invocation or a script with no arguments also shows help. Interactive questions run in the agent's UI, not inside Bash. Help never installs tools or runs tests.

Dependency setup: `--install --language csharp` (or typescript/powershell/bash). Add `--dry-run` to list dependencies without installing. For normal testing/reporting, `--dry-run` previews scope, actions and outputs without running them.

Bash tests use Bats. On Windows, Ubuntu WSL2 is recommended for full suites; Git Bash is retained for focused Windows compatibility checks. Resolve the environment before running installation or tests.
