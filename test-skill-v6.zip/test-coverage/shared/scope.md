# Scope

The manifest is a source inventory supplied before measurement:

```json
{
  "version": 1,
  "root": "D:/Work/MyApi",
  "files": ["Api/Validation/Range.cs", "Model/Parsing/Identifier.cs"],
  "classification": "strong",
  "reasons": {
    "Api/Validation/Range.cs": "Inclusive bounds contract; pure public function"
  },
  "suite": "unit"
}
```

On macOS use the absolute POSIX root. `files` contains unique relative forward-slash paths. No globs, drive prefixes, parent traversal or directory entries. Scripts validate structure and existence; the agent owns whether each file is semantically strong. `classification`, `reasons` and `suite` are preserved metadata, not a machine proof.

Whole-file source attribution is implemented. For mixed files, retain the method-level classification in the TDD inventory and report a measurement blocker. You may still test strong methods there, but this reporter cannot certify their separate coverage. Do not reclassify the file, relocate production code, add exclusions or redefine the denominator solely to reach 100%.

The reporter reconciles selected files with native records. Missing files are unresolved, including sources omitted by instrumentation or exclusions. Files with no executable items need an explicit classification outside the executable target before the run; they cannot be silently dropped afterward.

The collector hashes declared sources before and after execution. A change invalidates the run. This covers source content, not a complete reproducible-build attestation: retain build output, runtime, package locks, git identity and effective exclusion configuration in the agent's evidence. Do not merge frameworks, suites or older reports.

Normalized paths must map exactly to the manifest. Path mismatches are unresolved, not uncovered zeroes or evidence of success. SourceLink and container path mapping require a reviewed explicit mapping; never match only on basename.

Scope validation rejects relative roots, duplicate/noncanonical file paths, control characters and symlinked source entries. If a repository intentionally uses source symlinks, this adapter reports an attribution limitation rather than following them silently. Validation runs before collection; a malformed inventory must never reach the test runner.
