# Execution modes

This file owns entry order for both skills. Language and testing policies are resolved only after this order.

1. `--help`, or a bare invocation without a task/options: read the calling skill's help and stop. Help wins even with invalid options. No repository inspection or tool installation.
2. Validate other switches; reject contradictory duplicates and unsupported combinations. Do not infer a new language/framework or silently discard options.
3. `--interactive`: follow the calling skill's interactive guide using the available structured question tool. Preserve supplied options. Install-only skips test scope/coverage questions; dry-run changes the final action to Preview. Once choices are answered, continue at step 4.
4. `--dry-run`: follow [dry run](dry-run.md). For install-only invoke root `install.sh --dry-run`; otherwise create a read-only plan in the conversation. Stop.
5. `--install`: invoke the calling skill's root `install.sh` with resolved language/provider and package directory when required. Stop on success or failure; do not enter testing.
6. Execute the ordinary selected workflow.

`--check` is a root installer flag, not a new TDD execution mode. `--install` combined with testing-only options (coverage targets, interaction tests, characterization, mutation or a TDD mode) is conflicting; report the conflict. Framework/runtime constraints may be inspected by the agent before install but are not forwarded to the root installer. Its language is explicit; agent invocations can infer it from the selected project.

Native scripts only accept their documented arguments. `scripts/collect.sh` and `scripts/report.sh` reject dry-run before cache initialization with agent-preview guidance. The provider installer under scripts is internal; root `install.sh` is the public installation entrypoint. Do not imply an unimplemented script flag works because the agent can interpret it.
