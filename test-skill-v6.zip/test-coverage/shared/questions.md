# Question flow

This file owns the shared interaction mechanics for both skills. Each skill's interactive.md owns its task-specific questions. Their options.md files own switch semantics. Do not duplicate those policies in questions.

## Tool and pacing

Use the host's structured question tool: `ask_questions` if actually available, otherwise its equivalent. In this host, use `request_user_input_async`; do not invent a callable tool named ask_questions. In Plan mode a supported blocking question tool may be used. If no structured tool exists, ask one concise numbered question in ordinary conversation.

Ask one logical step at a time, at most three closely related questions in a batch. Provide two or three concise options where useful and allow free text for paths, thresholds and requirements. Prefix the question with its step name. Display only real discovered paths as choices, with enough context to distinguish them. Never invent a project, manifest or test suite.

For asynchronous tools, a preselected option is not an answer. Wait for the user's answer before dependent work; do not finalize the wizard while a question is pending. Read-only discovery can continue independently. If the turn must yield, keep the pending step and collected answers visible for resumption. Silence is not consent to start a run.

## Defaults and supplied values

Explicit switches and previous answers prefill the flow. Skip already-resolved questions. Inspect only the supplied/current repository, read-only, to discover languages, targets and test projects. No package installation, builds, test runs, production edits or coverage collection during the choice phase.

Show inferred defaults as recommendations, not as decisions already made. Preserve an explicitly requested threshold even when unsupported. Explain the limitation and let the user keep it with an unsupported result or explicitly choose a supported alternative. Do not call a line-only target equivalent to 100% line/branch.

Validate paths, framework/provider compatibility, runtime constraints and target percentages before the review step. Correct only the invalid field; retain other answers. If the user edits an upstream choice, invalidate dependent inferred values and recompute them, preserving explicit values unless incompatible. Cancel ends setup without execution.

## Review and handoff

Show a compact summary: action, repository/source scope, tests/runtime, test scope if applicable, provider/metrics, relevant limitations and outputs. Include a copyable skill invocation or script argument list. This is the user's requested interactive setup review, not an additional repository-policy approval requirement.

Ask **Run with these choices**, **Change a choice**, or **Show command only**. A run answer triggers the ordinary skill workflow using the resolved configuration; do not ask the same setup approval again. Command-only returns the configuration without installing or running anything. If essential information is unresolved, ask for that information instead of presenting a runnable command.

Never translate an explanation, path or user expression into shell evaluation. Build argument arrays using the existing scripts. Agent-only switches (`--interactive`, `--include-interaction-tests`, etc.) are not forwarded to native test runners or coverage scripts.

When `--dry-run` was supplied, replace Run with **Preview these choices** and retain the flag in the generated invocation. The answer produces a conversation plan only. When `--install` was supplied, ask only installation-relevant questions and show no test/coverage gate. The shared [execution order](execution.md) remains authoritative.
