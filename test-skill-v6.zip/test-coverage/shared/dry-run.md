# Dry run

`--dry-run` is a read-only planning mode for both skills. Help wins first. Interactive mode may gather missing choices, but its final action remains Preview when dry-run was supplied; it must never silently become Run.

For `--install --dry-run`, invoke the root `install.sh` with the language, provider, optional TypeScript project and `--dry-run`. It checks local prerequisites and lists intended dependency changes. Do not call `scripts/install.sh` directly for a preview.

For other dry runs, inspect source, project manifests and existing reports only. Display resolved repo/project, language/framework/provider, requested coverage metrics, eligible scope and deferred areas, planned commands in order, dependency changes, and intended report paths. Distinguish observed facts from assumptions and unresolved inputs. Do not create a manifest, output directory or report file; print the plan in the conversation. Never fabricate coverage percentages or assert that the target is achievable.

Do not restore, install, build, execute tests, import executable project configuration, change exclusions, open a browser or enter the TDD loop. An existing report may be read but must be identified as existing evidence, not a fresh result. The collection and report scripts do not implement a dry-run planner; the agent must not invoke them with this flag. Installation preview is the only executable dry-run entrypoint.

Without dry-run, use the normal workflow. No additional approval is imposed by this mode; the user can request execution in a later invocation.
