# Options

At the skill level, `--help` (no value) displays [help](help.md), and `--interactive` guides choices through [questions](interactive.md). A bare invocation with no task/options also shows help. Help takes precedence and does not inspect repositories or execute work. The wizard is an agent UI flow, not a Bash interaction loop.

The arguments below are actual Bash script arguments. The coverage agent also resolves language/runtime constraints; test eligibility and interaction scope belong to test:tdd. No globally installed `test:coverage` command is implied.

Agent switches include `--install`, `--dry-run`, `--help` and `--interactive`; use [execution order](execution.md). Source paths supplied conversationally must be translated to the explicit manifest below. Root `install.sh` accepts `--language`, `--coverage-tool`, optional `--project` for TypeScript, `--install`, `--check` and `--dry-run`. No arguments or `--help` displays installer help.

| Script | Required | Optional |
|---|---|---|
| `scripts/install.sh` (internal provider adapter) | positional provider: `base`, `coverlet`, `dotcover`, `v8`, `istanbul`, `pester`, `kcov` | TypeScript package directory as second positional argument |
| `scripts/collect.sh` | `--repo`, `--project`, `--scope`, `--output` | `--language csharp` (default), `--framework`, `--runtime`, `--coverage-tool auto`, `--coverage line=100,branch=100` |
| `scripts/report.sh` | `--coverage-tool`, `--input`, `--scope`, `--output` | `--tests`, `--coverage line=100,branch=100`, `--source-prefix` |

`--project` selects ONE test csproj for C#, package directory for TypeScript, test path for Pester, or Bats test directory. Supply absolute paths; quote paths containing spaces. `--repo` is the absolute source root, matching the manifest. `--scope` is a JSON manifest file, not a glob. `--output` must be a fresh directory for collection. Report generation refuses to overwrite an existing `coverage.json`.

`--runtime` currently applies only to .NET and accepts one exact TFM such as `net8.0` or `net10.0`. The agent resolves a user constraint such as `.NET 8+` against the project first. Do not pass that constraint verbatim to the collector. Other runtimes are selected by the project's installed environment.

The installed framework must match `--framework`: `nunit`, `xunit`, `vitest`, `pester`, `bats`. It is a compatibility assertion, not a migration request. The script does not prove a .NET package graph uses the requested framework; the agent inspects it.

`100%` means `line=100,branch=100`. For a deliberately different metric use `command=100`, `statement=100` or `line=100`; this is an explicit different target, never an automatic fallback. Provider names are `coverlet`, `dotcover`, `v8`, `istanbul`, `pester`, `kcov`.

The coverage skill has no `--all`, collaboration, characterization, fixture or test-generation switches. Those choices belong to test:tdd and arrive as an already classified manifest.

`--source-prefix` supplies an explicit absolute path prefix from the native report when different from the manifest root, for example `/work` for the Docker adapter. Relative paths must still match the manifest exactly. This mapping does not allow basename matching or rewriting the declared scope.

Example from Git Bash or macOS Bash:

```bash
bash "$HOME/.codex/skills/test-coverage/scripts/collect.sh" \
  --repo "$PWD" --project "$PWD/tests/Api.Tests/Api.Tests.csproj" \
  --language csharp --framework nunit --runtime net8.0 \
  --coverage-tool coverlet --coverage line=100,branch=100 \
  --scope "$PWD/artifacts/unit-scope.json" --output "$PWD/artifacts/coverage/run-001"
```

All three scripts accept --help without a value and show the same concise help before any cache initialization, tool installation or execution. No arguments also shows help (install.sh no longer defaults to installing base when invoked without arguments). Help wins when combined with other options. --interactive is agent-only: scripts reject it with guidance to invoke $test-coverage --interactive. They never try to call a question UI from Bash.

See [current capabilities](capabilities.md) before proposing diff selection, report format or browser-opening options.
