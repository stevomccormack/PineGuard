# Installation

[Root INSTALL.md](../INSTALL.md) is the single owner of setup instructions, prerequisites, dependency installation, preview/check semantics and cache policy. Both skill entrypoints and installers use it.

Collection uses the internal provider installer after invocation and source-inventory validation. Use one collection process per output directory; do not run concurrent installs into an initially empty shared cache. Retain native diagnostics on failure. Current platform verification is recorded in [evaluation results](../evaluation/results.md).
