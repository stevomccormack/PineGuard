# Implementation plan

Implemented: Bash installers, single-run collectors, native report normalization, explicit file inventory reconciliation, test-evidence gates and standalone JSON/HTML. No Python, PowerShell or JavaScript orchestration files are delivered.

Remaining improvements must preserve the measurement boundary:

1. Add exact method-level attribution, starting with Coverlet native JSON and stable method IDs. Reconcile every selected method against the assembly/source inventory before certifying mixed files. Never approximate by class/file percentages.
2. Add scoped dotCover statement normalization against a verified current native schema. Keep line and branch unsupported regardless of normalization success.
3. Extend native MTP collection with validated runner/provider detection across central project properties. Keep VSTest and MTP command paths separate.
4. Exercise every adapter on macOS and Windows runners. Keep real end-to-end evidence separate from fixture/parser tests. Add deterministic failure tests for corrupt native reports and partial collection.
5. Add run-level tool versions, exclusion manifests and complete source/build/test identity to the machine report. Existing source hashes and raw logs provide partial provenance, not a full reproducible-build guarantee.
6. Add explicit local tool-version locks and offline artifact resolution; support concurrent cache installation safely before advertising parallel bootstrap.
7. Before adding a Bats parallel-collection switch, validate backend detection/provisioning, child-process coverage, case accounting, worker failure propagation and separate output ownership on supported environments. Compare against the serial baseline. Native runner flags are not automatically collector capabilities.

Test generation remains agent work in test:tdd. Do not create a shell loop that invents tests from line numbers. Both skills should remain independently discoverable and installed together for the combined workflow.

The authoritative current support matrix is [capabilities](shared/capabilities.md). Next reporting work includes explicit report selection/opening, verified ReportGenerator native-format integration and genuine changed-line/branch attribution. These remain design work, not supported flags.
