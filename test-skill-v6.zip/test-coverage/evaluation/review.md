# Holistic review — 2026-09-10

Scope: both skills, their shared contract, language adapters, Bash entrypoints, installation, normalization and handoff. This was an author review with executable checks, not an independent model evaluation.

| Finding | Revision |
|---|---|
| Entry precedence was split across appended sections | One shared execution document routes help, interactive, preview and install-only before normal work |
| Installation had two documentation owners | Root INSTALL.md owns setup; help directs users to the root installer |
| Invalid preview forwarding could initialize the cache | Common helpers are read-only on load; execution scripts reject preview/check early |
| Repeated target keys silently overwrote earlier values | Shared validation rejects duplicate targets and duplicate script options |
| Test evidence accepted fractional or inconsistent counts | Enforce integer counts and failed + skipped no greater than total |
| Source validation happened after collection setup | Validate inventory before the test runner; reject traversal, aliases and source symlinks |
| Equal branch totals at one file/line could hide distinct decisions | Repeated branch identities remain unresolved |
| Pester failed-count did not describe every failed run state | Native Result controls failure exit evidence |
| Bats skipped tests were absent from evidence | Count TAP skip markers so all-skipped evidence cannot pass |
| Preflight accepted an unrelated yq executable | Check Mike Farah yq identity |
| Installed macOS kcov/Bats still needed another provisioning route | Reuse native tools before selecting Homebrew or Docker |
| A subset pass could imply all requested strong code was complete | Include unresolved mixed-file strong methods in task-level status |
| Suite metadata could be mistaken for runner filtering | Require separate evidence; use native filtered collection/import for mixed suites |
| Proposed features were insufficiently distinguished from implementation | One capabilities table states the current boundary |

See [verification](results.md). Remaining gaps: exact method attribution, scoped dotCover statement normalization, changed-line/branch gates, report selection/opening, ReportGenerator integration, complete version locks and physical macOS validation. Documenting these does not implement them.

Prioritize method attribution and native suite filtering next: they directly limit strong-only coverage in ordinary API projects. Follow with diff gates and richer HTML rendering. Keep native counters, semantic scope and overall task completion distinct.
