# Validation

## Holistic revision — 2026-09-10

The [review record](review.md) maps findings to revisions. Windows Git Bash verification: 27 input/preview cases, 15 help cases, 8 installation entry cases and 11 report cases (61 total). Report fixtures include ambiguous repeated branch identities. Bash syntax and local documentation links were checked; SKILL.md frontmatter remained unchanged.

Fresh native runs with the revised collector/reporter: NUnit net8.0 (7 passed; 4/4 lines, 4/4 branches), xUnit net10.0 (7 passed; 4/4 lines, 4/4 branches), Vitest V8 (6 passed; line/branch gate passed), Pester (5 passed; 1/1 commands). An intentionally failing Pester setup produced failed test evidence and test-failed JSON/HTML. These are isolated smoke fixtures, not coverage measurements of PineGuard or the skill implementation.

No fresh macOS, Docker/kcov, successful dotCover or independent model-execution evidence was established. The macOS installer routing and Bats TAP skip parsing were inspected but not exercised with those native tools. Host readiness remains distinct from runtime compatibility and successful collection.

Actual validation on 2026-09-09, Windows Git Bash 5.3.15. Syntax targets macOS Bash 3.2; physical macOS execution is not established.

| Check | Observed result |
|---|---|
| Named VIBE report fixtures | 10 passed: full coverage, failed tests, missed branch, missing file inventory, zero tests, branchless source, unsupported branches, all tests skipped, native capitalized branch flag, explicit source root |
| NUnit 4.6.1, adapter 6.3.0, net8.0, SDK 10.0.400 | 7 tests passed; Coverlet 10.0.1 measured 4/4 lines and 4/4 branches; JSON/HTML gate passed |
| xUnit.v3 package 4.0.0, net10.0 | 7 tests passed through its in-process runner; Coverlet measured 100% lines and branches; JSON/HTML gate passed |
| xUnit in-process net8.0 with Coverlet console 10.0.1 | Failed with a missing System.Runtime 10 assembly during instrumented execution; report correctly said test-failed. Do not change application runtime automatically to bypass this |
| Vitest/V8 4.1.11 | 6 fixture rows passed; line-and-branch JSON/HTML gate passed |
| Pester 6.1.0 | 5 fixture rows passed; 1/1 measured commands; explicit command=100 JSON/HTML gate passed |
| dotCover 2025.3.3 and current 2026.2.1 | Native collection failed with Snapshot container is not initialized. No successful dotCover coverage report established on this host |
| Windows Docker/kcov | Docker engine unavailable; end-to-end collection not exercised |
| macOS | No physical execution; not claimed tested |
| Skill structure | Both skill frontmatters passed bundled validation; local Markdown links resolved |

Known-count synthetic fixtures verify report decisions, not provider correctness. Native smoke artifacts are in the authoring workspace under artifacts/coverage-smoke, artifacts/typescript-smoke and artifacts/pester-smoke; they are not installed as application dependencies in PineGuard. PineGuard was not modified.

The script package contains Bash files only. Native test fixtures used for validation were written in their respective languages outside the skill package. No independent model execution evaluation has been performed. Remaining improvements belong to [PLAN.md](../PLAN.md).

A separate collection-failure fixture verified exit 2, empty metrics, collection-failed JSON and HTML escaping. All five delivered Bash files passed Bash syntax checks.

## v3 help and interactive entry — 2026-09-10

Fifteen VIBE entry-mode fixtures passed across install.sh, collect.sh and report.sh: explicit help, no arguments, help precedence over interactive/unknown flags, help with incomplete execution arguments, and guidance for agent-only interactive mode. These checks also verify no coverage cache is initialized. All Bash files passed syntax checks.

Both skill entrypoints route help before work and interactive setup through the host question UI. Live interactive user execution has not been tested. All local Markdown links resolve; previously validated frontmatter is unchanged. Interactive behavior is agent-driven, not a shell questionnaire.

The 10 existing report regression fixtures also passed after the entry dispatch changes, using staged local jq/yq tools. No provider end-to-end runs were required for these help-routing changes.

## WSL2 recommendation — 2026-09-10

Bats remains selected. The environment guide recommends Ubuntu WSL2 for full Bash suites on Windows and preserves a separate Git Bash compatibility suite. Native Bats/kcov selection now includes Linux; missing Linux tools fail preflight instead of silently choosing Docker. This is runtime-routing support, not WSL provisioning. Synthetic routing checks and Bash syntax validation are recorded for this change; no actual WSL2 timing or native kcov run has been established.

Validation on the Windows authoring host passed 52 cases: 29 argument/evidence/routing fixtures, 15 help fixtures and 8 installation fixtures. The two new native-routing cases simulate Linux and macOS with installed Bats/kcov and verify that preview neither probes Docker nor creates a cache. These are synthetic host checks, not native platform execution. All 75 Markdown documents have resolving local links; skill frontmatter is unchanged and all 12 Bash files retain LF line endings.

## Fixture concurrency documentation — 2026-09-10

Added native parallel-collection requirements and an explicit capability limit: the convenience collector stays serial and does not forward Bats jobs or install a parallel backend. All 77 Markdown documents have resolving local file links; both skill frontmatters and all 12 Bash files are unchanged from the installed baseline. The bundled validator could not run because PyYAML is unavailable; unchanged frontmatter was checked directly. No runtime code changed, so previous runtime results were not rerun or relabelled as new evidence. Parallel Bats/kcov, WSL2 performance and the new model acceptance scenarios remain unexecuted.
