#!/usr/bin/env bash
# VIBE fixtures for invalid evidence, scope identity and read-only entry modes.
set -euo pipefail
ROOT=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
source "$ROOT/scripts/common.sh"
ensure_jq
fixture=$(mktemp -d)
trap 'rm -rf "$fixture"' EXIT
printf 'subject\n' >"$fixture/logic.cs"
count=0
case_result() {
  local name=$1 expected=$2 code=0
  shift 2
  "$@" >"$fixture/result.log" 2>&1 || code=$?
  count=$((count+1))
  if [ "$code" -ne "$expected" ]; then cat "$fixture/result.log"; printf 'not ok %s - %s (%s, expected %s)\n' "$count" "$name" "$code" "$expected"; exit 1; fi
  printf 'ok %s - %s\n' "$count" "$name"
}
target_case() {
  local name=$1 target=$2 expected=$3
  case_result "$name" "$expected" bash -c 'source "$1/common.sh"; source "$1/validate.sh"; validate_target "$2"' check "$ROOT/scripts" "$target"
}
target_case Valid_Default 'line=100,branch=100' 0
target_case Boundary_Zero 'line=0' 0
target_case Edge_Fraction 'line=99.5' 0
target_case Invalid_Duplicate 'line=100,line=0' 5
target_case Invalid_Unknown 'decision=100' 5
target_case Invalid_AboveMaximum 'line=101' 5
target_case Invalid_Negative 'line=-1' 5
scope_case() {
  local name=$1 path=$2 declared=$3 expected=$4
  jq -n --arg root "$declared" --arg path "$path" '{version:1,root:$root,files:[$path]}' >"$fixture/scope.json"
  case_result "$name" "$expected" bash -c 'source "$1/common.sh"; source "$1/validate.sh"; validate_scope "$2"' check "$ROOT/scripts" "$fixture/scope.json"
}
scope_case Valid_File logic.cs "$(native_path "$fixture")" 0
scope_case Invalid_RelativeRoot logic.cs . 2
scope_case Invalid_Parent ../logic.cs "$fixture" 2
scope_case Invalid_Alias ./logic.cs "$fixture" 2
scope_case Invalid_Backslash 'a\logic.cs' "$fixture" 2
scope_case Invalid_Newline $'logic.cs\n' "$fixture" 2
scope_case Invalid_Missing absent.cs "$fixture" 2
tests_case() {
  local name=$1 evidence=$2 expected=$3
  printf '%s\n' "$evidence" >"$fixture/tests.json"
  case_result "$name" "$expected" bash -c 'source "$1/common.sh"; source "$1/validate.sh"; validate_tests "$2"' check "$ROOT/scripts" "$fixture/tests.json"
}
tests_case Valid_Evidence '{"total":2,"failed":0,"skipped":1,"exitCode":0,"verified":true}' 0
tests_case Invalid_FractionalTests '{"total":1.5,"failed":0,"exitCode":0,"verified":true}' 2
tests_case Invalid_OverlappingCounts '{"total":2,"failed":1,"skipped":2,"exitCode":0,"verified":true}' 2
tests_case Invalid_StringExit '{"total":2,"failed":0,"exitCode":"0","verified":true}' 2
tests_case Invalid_StringVerified '{"total":2,"failed":0,"exitCode":0,"verified":"true"}' 2
# An accidentally forwarded preview flag must not create a cache or output tree.
export TEST_COVERAGE_CACHE="$fixture/unused-cache"
for script in collect report install; do
  case_result "Edge_NoWrites_${script}" 2 bash "$ROOT/scripts/$script.sh" --dry-run
  [ ! -e "$TEST_COVERAGE_CACHE" ] || { printf '%s\n' 'Unexpected preview mutation'; exit 1; }
done
case_result Invalid_DuplicateInstaller 2 bash "$ROOT/install.sh" --language csharp --language bash --dry-run
case_result Invalid_DuplicateCollector 2 bash "$ROOT/scripts/collect.sh" --language csharp --language bash
case_result Invalid_DuplicateReporter 2 bash "$ROOT/scripts/report.sh" --coverage line=100 --coverage line=0
# Isolated host responses keep installer preview deterministic without network/runtime setup.
mkdir -p "$fixture/host"
printf '#!/usr/bin/env bash\nprintf "10.0.400 [fixture SDK]\\n"\n' >"$fixture/host/dotnet"
printf '#!/usr/bin/env bash\nexit 0\n' >"$fixture/host/curl"
printf '#!/usr/bin/env bash\nprintf "unrelated-yq 1.0\\n"\n' >"$fixture/host/yq"
chmod +x "$fixture/host/dotnet" "$fixture/host/curl" "$fixture/host/yq"
case_result Valid_InstallPreview 0 env PATH="$fixture/host:/usr/bin:/bin" bash "$ROOT/install.sh" --language csharp --dry-run
grep -q 'Would install: Mike Farah yq' "$fixture/result.log"
[ ! -e "$TEST_COVERAGE_CACHE" ]
case_result Boundary_CheckMissingTools 1 env PATH="$fixture/host:/usr/bin:/bin" bash "$ROOT/install.sh" --language csharp --check
[ ! -e "$TEST_COVERAGE_CACHE" ]
# Linux/WSL native routing: configured tools must not probe Docker.
printf '#!/usr/bin/env bash\nprintf "Linux\\n"\n' >"$fixture/host/uname"
printf '#!/usr/bin/env bash\nexit 0\n' >"$fixture/host/bats"
printf '#!/usr/bin/env bash\nexit 0\n' >"$fixture/host/kcov"
printf '#!/usr/bin/env bash\nprintf "unexpected Docker call" >"$TEST_COVERAGE_CACHE.docker"\nexit 99\n' >"$fixture/host/docker"
chmod +x "$fixture/host/uname" "$fixture/host/bats" "$fixture/host/kcov" "$fixture/host/docker"
case_result Valid_LinuxNativePreview 0 env PATH="$fixture/host:/usr/bin:/bin" bash "$ROOT/install.sh" --language bash --dry-run
grep -q 'Found: native kcov and Bats' "$fixture/result.log"
[ ! -e "$TEST_COVERAGE_CACHE" ] && [ ! -e "$TEST_COVERAGE_CACHE.docker" ]
# Native tools work identically on macOS; OS selection is not proof of a native run.
printf '#!/usr/bin/env bash\nprintf "Darwin\\n"\n' >"$fixture/host/uname"
case_result Valid_MacNativePreview 0 env PATH="$fixture/host:/usr/bin:/bin" bash "$ROOT/install.sh" --language bash --dry-run
grep -q 'Found: native kcov and Bats' "$fixture/result.log"
[ ! -e "$TEST_COVERAGE_CACHE" ] && [ ! -e "$TEST_COVERAGE_CACHE.docker" ]
printf '1..%s\n' "$count"
