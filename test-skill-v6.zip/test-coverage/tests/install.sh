#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
TEMP=$(mktemp -d)
trap 'rm -rf "$TEMP"' EXIT
export TEST_COVERAGE_CACHE="$TEMP/unused-cache"
run() {
  expected=$1; shift
  actual=0
  bash "$ROOT/install.sh" "$@" >"$TEMP/output" 2>&1 || actual=$?
  [ "$actual" -eq "$expected" ] || { cat "$TEMP/output"; exit 1; }
  [ ! -e "$TEST_COVERAGE_CACHE" ] || { printf '%s\n' 'Preview created a cache'; exit 1; }
}
# Valid and boundary: help bypasses missing values and unknown arguments.
run 0 --help
run 0
run 0 --language --help --unknown
# Invalid: missing values, unsupported language, incompatible provider.
run 2 --language
run 2 --language rust
run 2 --language csharp --coverage-tool v8
run 2 --language typescript --project "$TEMP/missing package"
# Edge: a delegating installation entrypoint preserves help behavior.
bash "$ROOT/../test-tdd/install.sh" --help >"$TEMP/delegated"
bash "$ROOT/install.sh" --help >"$TEMP/direct"
cmp "$TEMP/delegated" "$TEMP/direct"
printf '%s\n' 'Passed 8 installation VIBE cases; no cache created.'
