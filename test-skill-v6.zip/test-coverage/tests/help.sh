#!/usr/bin/env bash
# VIBE entry-mode fixtures: help must not initialize tools or run a workload.
set -euo pipefail
skill_root=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
fixture_root=$(mktemp -d)
export TEST_COVERAGE_CACHE="$fixture_root/cache-must-not-exist"
case_number=0
run_fixture() {
  local name=$1 expected=$2 script=$3 code=0
  shift 3
  case_number=$((case_number+1))
  bash "$skill_root/scripts/$script" "$@" >"$fixture_root/$name.out" 2>"$fixture_root/$name.err" || code=$?
  [ "$code" -eq "$expected" ] || { printf 'not ok %s - %s (exit %s)\n' "$case_number" "$name" "$code"; exit 1; }
  [ ! -e "$TEST_COVERAGE_CACHE" ] || { printf 'not ok %s - help initialized cache\n' "$case_number"; exit 1; }
  if [ "$expected" -eq 0 ]; then
    cmp -s "$skill_root/shared/help.md" "$fixture_root/$name.out" || { printf 'not ok %s - help missing\n' "$case_number"; exit 1; }
  else
    grep -q 'agent UI' "$fixture_root/$name.err" || { printf 'not ok %s - interactive guidance missing\n' "$case_number"; exit 1; }
  fi
  printf 'ok %s - %s\n' "$case_number" "$name"
}
for script in install.sh collect.sh report.sh; do
  run_fixture "valid_help_$script" 0 "$script" --help
  run_fixture "boundary_no_arguments_$script" 0 "$script"
  run_fixture "edge_help_precedence_$script" 0 "$script" --interactive --help --unknown
  run_fixture "edge_help_with_incomplete_work_$script" 0 "$script" --repo --help
  run_fixture "invalid_shell_interactive_$script" 2 "$script" --interactive
done
printf '1..%s\nFixtures: %s\n' "$case_number" "$fixture_root"
