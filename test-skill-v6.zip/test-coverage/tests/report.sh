#!/usr/bin/env bash
# Named VIBE fixtures exercise report outcomes, not implementation text.
set -euo pipefail
source "$(dirname "${BASH_SOURCE[0]}")/../scripts/common.sh"
ensure_jq; ensure_yq
fixture=$(mktemp -d)
# Keep failed fixtures for diagnosis; successful artifacts remain in this temp directory.
printf 'Source fixture\n' >"$fixture/logic.cs"
jq -n --arg root "$(native_path "$fixture")" '{version:1,root:$root,files:["logic.cs"]}' >"$fixture/scope.json"
printf '{"total":4,"failed":0,"exitCode":0,"verified":true}\n' >"$fixture/tests.json"
printf '<coverage><packages><package><classes><class filename="logic.cs"><lines><line number="1" hits="1" branch="true" condition-coverage="100%% (2/2)"/></lines></class></classes></package></packages></coverage>\n' >"$fixture/full.xml"
sed 's/100% (2\/2)/50% (1\/2)/' "$fixture/full.xml" >"$fixture/gap.xml"
printf '<coverage><packages/></coverage>\n' >"$fixture/empty.xml"
printf '{"total":0,"failed":0,"exitCode":0,"verified":true}\n' >"$fixture/zero.json"
printf '{"total":4,"failed":1,"exitCode":1,"verified":true}\n' >"$fixture/failed.json"
printf '{"total":4,"failed":0,"skipped":4,"exitCode":0,"verified":true}\n' >"$fixture/skipped.json"
printf '<coverage><packages><package><classes><class filename="logic.cs"><lines><line number="1" hits="1"/></lines></class></classes></package></packages></coverage>\n' >"$fixture/branchless.xml"
case_number=0
run_case() {
  local name=$1 xml=$2 evidence=$3 provider=$4 expected=$5 code=0
  case_number=$((case_number+1))
  bash "$TC_ROOT/scripts/report.sh" --coverage-tool "$provider" --input "$fixture/$xml" --scope "$fixture/scope.json" --tests "$fixture/$evidence" --output "$fixture/$name" >"$fixture/$name.log" 2>&1 || code=$?
  if [ "$code" -ne "$expected" ]; then cat "$fixture/$name.log"; printf 'not ok %s - %s (expected %s, got %s)\n' "$case_number" "$name" "$expected" "$code"; exit 1; fi
  [ -s "$fixture/$name/coverage.html" ] || { cat "$fixture/$name.log"; exit 1; }
  printf 'ok %s - %s\n' "$case_number" "$name"
}
run_case valid_full full.xml tests.json coverlet 0
run_case invalid_failed_tests full.xml failed.json coverlet 3
run_case boundary_one_branch_missing gap.xml tests.json coverlet 1
run_case edge_missing_inventory empty.xml tests.json coverlet 5
run_case edge_zero_tests full.xml zero.json coverlet 5
run_case edge_branchless branchless.xml tests.json coverlet 0
run_case edge_unsupported_branches full.xml tests.json kcov 4
run_case edge_all_skipped full.xml skipped.json coverlet 5
sed 's/branch="true"/branch="True"/' "$fixture/full.xml" >"$fixture/capital.xml"
run_case valid_native_branch_case capital.xml tests.json coverlet 0
# Explicit Cobertura source roots must resolve full paths, not just basenames.
source_xml=$(printf '%s' "$(native_path "$fixture")" | jq -Rrs '@html')
printf '<coverage><sources><source>%s</source></sources><packages><package><classes><class filename="logic.cs"><lines><line number="1" hits="1" branch="True" condition-coverage="100%% (2/2)"/></lines></class></classes></package></packages></coverage>\n' "$source_xml" >"$fixture/source.xml"
run_case valid_explicit_source_root source.xml tests.json coverlet 0
printf '<coverage><packages><package><classes><class filename="logic.cs"><lines><line number="1" hits="1" branch="true" condition-coverage="100%% (2/2)"/><line number="1" hits="1" branch="true" condition-coverage="100%% (2/2)"/></lines></class></classes></package></packages></coverage>\n' >"$fixture/duplicate.xml"
run_case edge_ambiguous_duplicate_branches duplicate.xml tests.json coverlet 5
jq -e '.metrics[]|select(.metric=="branch")|.total==2 and .covered==1' "$fixture/boundary_one_branch_missing/coverage.json" >/dev/null
printf '1..%s\nArtifacts: %s\n' "$case_number" "$fixture"
