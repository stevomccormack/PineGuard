# Installation

Copy the complete `test-coverage` and `test-tdd` folders into your agent's skills directory, as siblings. For Codex this is usually `$HOME/.codex/skills/`. Reload skill discovery in your host if necessary. These are agent skills, not globally registered shell commands.

Run Bash examples in the resolved shell environment. For full Bash test suites on Windows, recommend **Ubuntu on WSL2**; read [Bash environment](languages/bash/environment.md). macOS uses native Bash. Git Bash remains available for Windows-hosted tool workflows and Windows compatibility tests. Bash 3.2 or later is required for these orchestration scripts. Git Bash paths use quoted forward slashes, such as `"D:/Steve McCormack/project"`; WSL uses Linux paths and Linux-installed tools. A Bash script cannot bootstrap its own absent shell.

```bash
bash "$HOME/.codex/skills/test-coverage/install.sh" --language csharp --dry-run
bash "$HOME/.codex/skills/test-coverage/install.sh" --language csharp
bash "$HOME/.codex/skills/test-coverage/install.sh" --language csharp --coverage-tool dotcover
bash "$HOME/.codex/skills/test-coverage/install.sh" --language typescript --project "$PWD" --coverage-tool v8
bash "$HOME/.codex/skills/test-coverage/install.sh" --language powershell
bash "$HOME/.codex/skills/test-coverage/install.sh" --language bash
```

At the agent level use `$test-coverage --install --language csharp`, or `$test-tdd --install --language csharp`. Add `--dry-run` to preview. Installation ends without collecting coverage or creating tests. The root script accepts `--install` for symmetry; supplying a language already selects check-and-install.

| Language | Host prerequisites | Installed by this skill |
|---|---|---|
| C# | Project-compatible .NET SDK | jq, yq, local Coverlet or dotCover CLI |
| TypeScript | Project-compatible Node, npm and the lockfile's package manager | jq, matching Vitest coverage provider; Vitest if absent |
| PowerShell | PowerShell 7 (`pwsh`) | jq, cached Pester module |
| Bash | Preferred Windows route: Ubuntu WSL2 with native Bats/kcov. macOS: native tools or Homebrew. Git Bash coverage fallback: Git and running Docker | jq/yq; existing Homebrew or Docker tool provisioning on those routes. Native Linux Bats/kcov are currently prerequisites |

`curl` and standard shell utilities are required. Host SDKs, Node, PowerShell, Homebrew and Docker engine are prerequisites: the script reports missing prerequisites and exits before dependency installation. Install these through your organisation's approved runtime setup. The installer does not upgrade application runtimes, install system services or select a different target framework. NUnit/xUnit packages remain project-owned and are restored through the project's normal .NET workflow.

`--check` inspects local availability without writes or downloads: exit 0 means dependencies are present, 1 means installable dependencies are missing, 2 means invalid input or blocked prerequisites. `--dry-run` prints the same dependency plan and exits 0 for a valid unblocked plan, even when dependencies are missing; invalid or blocked plans return 2. Presence checks do not prove runtime compatibility, module loadability, licensing or successful coverage collection. Neither mode creates the cache, restores packages, builds, runs tests or opens reports.

Installation uses `${TEST_COVERAGE_CACHE:-${XDG_CACHE_HOME:-$HOME/.cache}/test-coverage}`. Missing tools resolve current stable releases; existing cached tools are retained, not upgraded automatically. The agent must check project/runtime compatibility: cache presence alone does not establish it. If a current tool cannot run with the installed host runtime, report that mismatch rather than upgrading the application. TypeScript matches an existing Vitest version exactly and updates the selected project's development dependencies and lockfile only when needed. Pester supports `TEST_COVERAGE_PESTER_VERSION`. jq/yq downloads are checksum-verified by the existing provider installer. A failed installation returns nonzero; dependencies installed before a later failure may remain and can be reused on retry. No automatic removal or rollback is performed.

The Git Bash kcov route requires a running Docker engine with Linux containers. WSL2 uses native Linux kcov and Bats without Docker when both are installed. The installer cannot start or license Docker Desktop. macOS native kcov depends on Homebrew availability. Actual macOS execution remains unverified; do not interpret Bash syntax compatibility as a successful platform test.

See [options](shared/options.md) for collection and [reports](shared/reports.md) for metric limitations. Current reports are HTML and structured JSON. Installing dependencies does not add ReportGenerator integration or branch coverage to a provider that lacks it.
