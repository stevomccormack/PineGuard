#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
help() {
  printf '%s\n' 'Usage: bash install.sh --language csharp|typescript|powershell|bash [--coverage-tool PROVIDER] [--project DIR] [--dry-run|--check]' 'Checks prerequisites and installs missing coverage dependencies. --dry-run and --check are read-only.' 'C#: coverlet (default) or dotcover; TypeScript: v8 (default) or istanbul; PowerShell: pester; Bash: kcov.' 'Host prerequisites and platform instructions: INSTALL.md. No arguments shows help.'
}
if [ "$#" -eq 0 ]; then help; exit 0; fi
for arg in "$@"; do if [ "$arg" = --help ]; then help; exit 0; fi; done
language= provider= project= mode=install
seen=" "
while [ "$#" -gt 0 ]; do
 if [[ "$seen" == *" $1 "* ]]; then printf 'Duplicate option: %s\n' "$1" >&2; exit 2; fi
 seen="$seen$1 "
 case "$1" in
  --install) shift ;;
  --dry-run) mode=dry; shift ;;
  --check) if [ "$mode" != dry ]; then mode=check; fi; shift ;;
  --language|--coverage-tool|--project)
   key=$1; [ "$#" -ge 2 ] && [ -n "$2" ] && [[ "$2" != --* ]] || { printf 'Missing value: %s\n' "$key" >&2; exit 2; }
   case "$key" in --language) language=$2;; --coverage-tool) provider=$2;; --project) project=$2;; esac; shift 2 ;;
  *) printf 'Unknown option: %s\n' "$1" >&2; exit 2 ;;
 esac
done
case "$language" in
 csharp) provider=${provider:-coverlet}; allowed=' coverlet dotcover ' ;;
 typescript) provider=${provider:-v8}; allowed=' v8 istanbul ' ;;
 powershell) provider=${provider:-pester}; allowed=' pester ' ;;
 bash) provider=${provider:-kcov}; allowed=' kcov ' ;;
 *) printf '%s\n' 'Supply --language csharp|typescript|powershell|bash' >&2; exit 2 ;;
esac
if [ "$provider" = auto ]; then case "$language" in csharp) provider=coverlet;; typescript) provider=v8;; powershell) provider=pester;; bash) provider=kcov;; esac; fi
[[ "$allowed" == *" $provider "* ]] || { printf 'Provider %s is incompatible with %s\n' "$provider" "$language" >&2; exit 2; }
case "$(uname -s)" in Darwin|MINGW*|MSYS*|CYGWIN*|Linux) :;; *) printf '%s\n' 'Unsupported operating system' >&2; exit 2;; esac
cache=${TEST_COVERAGE_CACHE:-${XDG_CACHE_HOME:-$HOME/.cache}/test-coverage}
export PATH="$cache/bin:$cache/dotnet:$PATH"
missing=0; blocked=0
check() { if command -v "$1" >/dev/null 2>&1; then printf 'Found: %s\n' "$1"; else printf 'Missing prerequisite: %s (see INSTALL.md)\n' "$1"; blocked=1; fi; }
dependency_yq() { if command -v yq >/dev/null 2>&1 && yq --version 2>/dev/null | grep -q mikefarah; then printf '%s\n' 'Found: Mike Farah yq'; else printf '%s\n' 'Would install: Mike Farah yq'; missing=1; fi; }
dependency() { if command -v "$1" >/dev/null 2>&1; then printf 'Found: %s\n' "$1"; else printf 'Would install: %s\n' "$1"; missing=1; fi; }
printf 'Language: %s; provider: %s; cache: %s\n' "$language" "$provider" "$cache"
check curl
dependency jq
case "$provider" in
 coverlet|dotcover)
  check dotnet; dependency_yq
  if command -v dotnet >/dev/null 2>&1 && ! dotnet --list-sdks | grep -q '[0-9]'; then printf '%s\n' 'Missing prerequisite: .NET SDK'; blocked=1; fi
  executable=coverlet; [ "$provider" != dotcover ] || executable=dotCover
  if [ -x "$cache/dotnet/$executable" ] || [ -x "$cache/dotnet/$executable.exe" ]; then printf 'Found cached tool: %s\n' "$executable"; else printf 'Would install local .NET tool: %s\n' "$executable"; missing=1; fi ;;
 v8|istanbul)
  check node; check npm
  [ -n "$project" ] && [ -f "$project/package.json" ] || { printf '%s\n' 'Supply --project with an existing package.json directory' >&2; exit 2; }
  if [ -f "$project/pnpm-lock.yaml" ]; then check pnpm; elif [ -f "$project/yarn.lock" ]; then check yarn; elif [ -f "$project/bun.lock" ] || [ -f "$project/bun.lockb" ]; then check bun; fi
  if command -v node >/dev/null 2>&1 && (cd "$project"; node -e 'const v=require("vitest/package.json").version; process.exit(require("@vitest/coverage-"+process.argv[1]+"/package.json").version===v?0:1)' "$provider") 2>/dev/null; then printf '%s\n' 'Found matching Vitest/provider'; else printf 'Would install matching Vitest/%s dev dependencies in %s (package manifest and lockfile may change)\n' "$provider" "$project"; missing=1; fi ;;
 pester)
  check pwsh
  # Importing modules can execute initialization code. Read-only modes only inspect cache presence.
  found=0
  for manifest in "$cache"/modules/Pester/*/Pester.psd1; do
   [ -f "$manifest" ] || continue
   if [ -z "${TEST_COVERAGE_PESTER_VERSION:-}" ] || [[ "$manifest" == */"$TEST_COVERAGE_PESTER_VERSION"/Pester.psd1 ]]; then found=1; fi
  done
  if [ "$found" -eq 1 ]; then printf '%s\n' 'Found cached Pester manifest (loadability not verified)'; else printf '%s\n' 'Would save Pester in the skill cache'; missing=1; fi ;;
 kcov)
  dependency_yq
  if { [ "$(uname -s)" = Darwin ] || [ "$(uname -s)" = Linux ]; } && command -v kcov >/dev/null 2>&1 && command -v bats >/dev/null 2>&1; then printf '%s\n' 'Found: native kcov and Bats'
  elif [ "$(uname -s)" = Linux ]; then
   check bats; check kcov
   printf '%s\n' 'Linux/WSL2 uses native Bats/kcov; see languages/bash/environment.md for setup.'
  elif [ "$(uname -s)" = Darwin ] && command -v brew >/dev/null 2>&1; then dependency kcov; dependency bats
  else
   check docker; check git
   if command -v docker >/dev/null 2>&1; then
    if docker info >/dev/null 2>&1; then
     if ! docker image inspect kcov/kcov:latest >/dev/null 2>&1; then printf '%s\n' 'Would pull kcov/kcov:latest'; missing=1; fi
    else printf '%s\n' 'Blocked: start Docker engine'; blocked=1; fi
   fi
   if [ ! -d "$cache/bats/.git" ]; then printf '%s\n' 'Would clone latest stable bats-core into cache'; missing=1; fi
  fi ;;
esac
if [ "$blocked" -ne 0 ]; then exit 2; fi
if [ "$mode" = dry ]; then printf '%s\n' 'Dry run: no changes made; installability and network access are not verified.'; exit 0; fi
if [ "$mode" = check ]; then exit "$missing"; fi
exec bash "$ROOT/scripts/install.sh" "$provider" "$project"
