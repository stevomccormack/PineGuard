# PowerShell coverage

The Bash collector invokes Pester's native API through `pwsh -Command`. It imports a cached module, supplies explicit source paths and exports hit/missed command records alongside native coverage. No `.ps1` orchestration files are delivered.

Pester command coverage cannot certify branch coverage or be relabelled as line coverage. The default line-and-branch request therefore returns unsupported; explicitly request `command=100` only when that is the desired target. Preserve the limitation in HTML and AI output.

Use the repository-compatible Pester major version. Check actual exported command fields before trusting a new major. An empty command export becomes unresolved. Collection needs local, reproducible fixtures and must avoid concurrent coverage over shared session state. VIBE and native Pester test syntax belong to [test:tdd](../../../test-tdd/languages/powershell/testing.md).
