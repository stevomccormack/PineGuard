# TypeScript coverage

Use Vitest with the matching `@vitest/coverage-v8` or `@vitest/coverage-istanbul` package. The collector requests Istanbul JSON and JSON test results in a fresh directory, including the declared source files so unimported files cannot disappear. Existing project configuration, aliases and transpilation must remain valid.

Inspect source maps: counters must map to original `.ts` files, not generated JavaScript. Wrong paths or missing files are unresolved. V8 and Istanbul counter shapes can differ; compare exact counts only within the same provider/configuration. Type-only declarations are compile-time contracts, not executable unit coverage targets.

The convenience collector uses the package's `vitest run`; it does not implement arbitrary monorepo orchestration. Select one package per run. Preserve the package lock and review the provider dependency installation. Test design, typed fixture rows and VIBE are owned by [test:tdd](../../../test-tdd/languages/typescript/testing.md).
