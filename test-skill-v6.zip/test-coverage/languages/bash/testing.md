# Bash coverage

Use Bats for tests and kcov for coverage. For full suites on Windows, prefer Ubuntu on WSL2 with native Linux Bash/Bats/kcov. Follow [environment](environment.md) for setup and performance guidance. On macOS use native tools or the existing Docker path. Git Bash coverage retains the Docker fallback; Windows-native kcov is not claimed.

Container tests execute Linux shell semantics; they do not prove Windows-specific behavior. Run separate Git Bash functional tests when Windows path/process behavior matters. The scripts avoid Bash 4+ features so macOS Bash 3.2 can orchestrate; a project may explicitly require a newer shell for the code under test.

kcov line coverage does not establish branches. Keep `line=100,branch=100` unsupported, or explicitly request a line-only target. kcov may report only observed scripts; missing declared files remain unresolved. Inspect native generated HTML as well as the common report.

The Docker adapter requires test paths within the repository, mounts the repository, reports and Bats checkout, and disables Git Bash path rewriting for container arguments. Source path attribution must map `/work/` back to the declared root. See [validation](../../evaluation/results.md) for which paths have actually been exercised. VIBE fixtures and independent Bats case discovery belong to [test:tdd](../../../test-tdd/languages/bash/testing.md).

## Parallel collection

Bats supports parallel test execution, but `scripts/collect.sh` currently invokes its serial route and does not accept or forward `--jobs`. The installer does not provision a parallel backend. Do not pass native Bats flags to these scripts or claim parallel coverage is implemented.

Fixture design and background process rules belong to [Bash concurrency](../../../test-tdd/languages/bash/concurrency.md). For a requested native parallel collection workflow:

1. Establish a serial baseline with the same source, cases, filters, environment and tool versions. Keep test-only timing separate from instrumented timing.
2. Verify the chosen kcov/runtime setup traces the relevant child processes. Reconcile known exercised source locations and the declared inventory; a valid HTML file alone does not establish complete collection.
3. Retain complete runner evidence, including every case outcome, worker failure and the final exit status. Wait for workers and collection to finish before importing the report; partial output cannot pass.
4. Use a fresh output directory per run or shard. If sharding requires a merge, use a verified provider-supported operation with matching source identity; never sum percentages or allow competing writers in one directory. Install shared dependencies before starting workers because concurrent cache installation is not supported.
5. Normalize verified native evidence through the existing report import path. If any of these requirements cannot be established, collect serially and state the limitation. Parallelism supplies neither branch coverage nor proof that the production code is race-free.
