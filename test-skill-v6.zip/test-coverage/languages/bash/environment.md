# Bash environment

Bats is the selected framework. For full Bash test suites on Windows, recommend **WSL2 with Ubuntu and Linux-native Bash**. Git Bash remains a supported compatibility environment; it is not the preferred full-suite runtime for fixtures that create many processes. macOS uses native Bash with the project's supported version.

This document owns environment selection and performance guidance for both skills. It does not change VIBE, strength gates or coverage metrics.

## Resolve the environment

1. On Windows, inspect available distributions with `wsl --list --verbose` before constructing a launch command. Confirm the selected Ubuntu distribution uses version 2. Never infer WSL2 from `wsl.exe` presence, the distribution name, or a WSL environment variable alone.
2. Prefer an existing, configured Ubuntu WSL2 environment for the full Bats suite. If unavailable, report the prerequisite and the Git Bash fallback's process overhead. The skill does not install WSL, convert distributions, reboot Windows or relocate a repository automatically.
3. Keep the Bash-test working copy, fixtures, temporary files, Bats, kcov and caches inside WSL's Linux filesystem, for example `~/projects/repo`. Running Linux tools against `/mnt/c` or `/mnt/d` can exchange process overhead for filesystem overhead. Paths under `/mnt` may use configurable mount locations: inspect rather than hardcode mappings.
4. Work on the actual requested source revision. A separate WSL checkout must include the intended uncommitted changes when they are in scope. Compare identities; never measure a stale clone and report it as coverage of current Windows edits. Do not move or overwrite the user's existing checkout.
5. Run the entire suite inside one WSL invocation/session, using the distribution's Bash, Bats and Linux utilities. Do not launch `wsl.exe`, Windows `bash.exe`, or Windows tools per fixture. Install the two skill folders as siblings inside that environment when executing their scripts there; the Windows and Linux `$HOME` and tool caches are different.

Use normal native commands **inside the selected WSL terminal**:

```bash
cd "$HOME/projects/repo"
bash "$HOME/.codex/skills/test-coverage/install.sh" --language bash --dry-run
bats --formatter tap tests/unit
```

These paths illustrate layout; resolve real paths before execution. No Windows-to-WSL auto-launch flag is implemented. The agent chooses the session and passes ordinary documented script arguments.

## Preserve Windows compatibility evidence

WSL executes Linux behaviour. Keep a small, separate Git Bash suite for Windows path conversion, spaces in paths, executable discovery, quoting and Windows-process integration where relevant. Run macOS checks for BSD utility differences and the supported shell version. A full WSL pass does not establish Git Bash or macOS compatibility. Record results by environment instead of merging them into a single platform claim.

## Avoid unnecessary process creation

Keep fixtures as named Bash values, arrays and functions; prefer builtins for simple setup work. Avoid spawning `cat`, `sed`, `awk`, `jq` or a new shell for each scalar fixture field. Cache immutable suite metadata once where valid; retain fresh mutable state per case. Keep each VIBE case independently discovered. Do not combine all cases into one test or disable isolation just to improve timing. Follow [Bash concurrency](../../../test-tdd/languages/bash/concurrency.md) for bounded jobs, background fixture handling and framework alternatives; [parallel collection](testing.md#parallel-collection) owns measurement requirements.

The expected performance benefit is a recommendation, not a benchmark result on the user's machine. Measure the same suite and source in each relevant environment, with coverage separately from plain test execution; cold WSL startup and warm execution are different costs.

## Coverage setup

Inside Linux/WSL2, the convenience collector uses native Bats and kcov when both are installed. Missing native tools produce a prerequisite error, without silently switching to Docker. Install approved compatible releases using the distribution's package manager or upstream installation instructions; distro packages can lag current releases. Current `--install` checks these two Linux prerequisites and installs the reporting helpers; it does not provision Linux system packages.

Bats alone does not require kcov or Docker. Full test runs can use Bats while coverage is unavailable. Git Bash coverage retains its existing Docker route. kcov remains line-only for this skill: WSL2 does not supply branch coverage.

Sources: [Bats process-creation guidance](https://github.com/bats-core/bats-core/blob/master/docs/CONTRIBUTING.md#command-substitution), [Microsoft filesystem guidance](https://learn.microsoft.com/en-us/windows/wsl/filesystems), [WSL version differences](https://learn.microsoft.com/en-us/windows/wsl/compare-versions). Checked 2026-09-10.
