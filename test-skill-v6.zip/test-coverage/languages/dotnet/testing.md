# .NET coverage

Use the existing NUnit or xUnit project and runner. Framework choice does not determine coverage capability. The current convenience collector builds one test csproj then uses Coverlet console or dotCover to run `dotnet test --no-build` with TRX output. Select one exact TFM for multi-target projects. Build failure, zero tests and multiple TRX files cannot pass.

Default to Coverlet for line-and-branch targets. Read [Coverlet](coverlet.md) for native collector/MTP choices. Console instrumentation must not rebuild the instrumented assembly. Existing exclusions must be inventoried separately; a scoped file disappearing from native evidence is unresolved.

Read [dotCover](dotcover.md) when explicitly selected. It reports statement coverage, not branch coverage. The convenience collector retains native JSON and a snapshot, and produces the common HTML/JSON status report. Its file-scoped statement normalization is currently unresolved; use native details for diagnosis. Do not call this a working 100% line-and-branch gate.

The default convenience path targets VSTest; current xUnit in-process executables have a separate detected path. For native Microsoft.Testing.Platform projects, use the documented provider integration and import native reports with `report.sh`. Inspect project and central build configuration; a text check in one csproj is not complete runner detection. No automatic runner migration is authorized by choosing coverage.

Current xUnit in-process runners are detected from resolved dependencies and their advertised TRX switches. This path is tested on net10.0. A net8.0 in-process run with Coverlet console 10.0.1 failed because instrumented code requested System.Runtime 10; select a verified compatible provider integration instead of upgrading the application without instruction. See evaluation/results.md for exact evidence.

The convenience collector runs the selected project in full. Select a unit-only project. If unit and BDD tests share one project, use the repository's native filtered collection command and import its report with matching test evidence; the convenience command does not yet expose suite filters.
