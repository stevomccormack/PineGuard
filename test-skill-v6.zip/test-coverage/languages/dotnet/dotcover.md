# dotCover

This file owns dotCover collection. Facts checked 2026-09-09; inspect the installed version/help because CLI behaviour has changed between releases.

## Capability boundary

JetBrains documents statement coverage, including a ternary limitation where one executed arm can appear fully covered. This cannot establish the skill's line-and-branch target. Report statement results accurately; obtain separate branch-capable evidence if available within task scope. A converted report format does not create missing branch observations. [Coverage definitions](https://www.jetbrains.com/help/dotcover/dotCover__Basic_Concepts.html)

## Collection

Inspect `dotCover version` and `dotCover help cover`, or the equivalent installed command. Use a local tool manifest if the repository has one. Adapt the documented target-executable/target-arguments interface to the real `dotnet test` command, selected test project, framework, unit filters and output paths. Avoid brittle nested quoting; verify the constructed command starts the intended tests.

CLI documentation notes that class/method/file filters were removed starting with 2025.2. Do not reuse legacy filter syntax without checking the installed version. Attribute-based exclusions are supported through explicit options such as `--exclude-attributes`; exclusion policy remains in [test:tdd exclusions](../../../test-tdd/shared/exclusions.md). [CLI documentation](https://www.jetbrains.com/help/dotcover/Coverage-Analysis-with-Command-Line-Tool.html)

Inspect exported detail and available scopes before computing a selected subset. If statement detail cannot represent the strong inventory, show the available method/type results and mark subset attribution unresolved. Do not alter production attributes to compensate for tool filtering limitations.

## Result

Return actual statement counts and the tool version. Mark line/branch target unsupported by this evidence. If a separate Coverlet run is available, report it separately with its own counts/configuration; do not average or merge percentages between tools.

Do not download or upgrade dotCover merely because a remembered command failed. Read installed help, correct version-specific invocation and report licensing/environment limitations if present.

Local verification on 2026-09-09: both 2025.3.3 and latest stable 2026.2.1 failed with Snapshot container is not initialized. This is a host/run observation, not a claim that every dotCover installation is broken. Preserve the native log and report collection failure.
