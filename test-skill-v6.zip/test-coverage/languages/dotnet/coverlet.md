# Coverlet

This file owns Coverlet collection. Apply [reports](../../shared/reports.md) to judge the result. Facts checked 2026-09-09; repository documentation can describe unreleased versions, so verify against the installed package/release.

## Select a compatible driver

Inspect package references, runner settings and CLI help. Coverlet measures lines, branches and methods. Its VSTest collector and MSBuild drivers do not run natively under MTP v2; use a compatible released MTP integration when available. Do not infer compatibility solely from the .NET target. [Coverlet](https://github.com/coverlet-coverage/coverlet)

Reuse one compatible driver per run. Do not add both collector and MSBuild integration to "improve" coverage. Preserve central package versions and runner conventions.

## VSTest collector

With a compatible `coverlet.collector` already referenced, adapt this command to the real test project and target:

```bash
dotnet test ./tests/Api.UnitTests/Api.UnitTests.csproj --framework net8.0 --collect:"XPlat Code Coverage;Format=json,cobertura" --results-directory ./artifacts/unit-coverage
```

The path is illustrative. Locate fresh attachments from this run; do not glob and merge old results. The collector does not provide the MSBuild driver's native threshold gate. Use verified report counts for the selected scope. [Collector documentation](https://github.com/coverlet-coverage/coverlet/blob/master/Documentation/VSTestIntegration.md)

Use a task-specific runsettings file if filters are needed. Inspect all effective defaults and existing filters. Do not copy broad sample exclusions. Ensure non-executed eligible types remain in the denominator.

## MSBuild driver

With compatible `coverlet.msbuild`, a minimal collection command is:

```bash
dotnet test ./tests/Api.UnitTests/Api.UnitTests.csproj --framework net8.0 -p:CollectCoverage=true -p:CoverletOutput=./artifacts/unit-coverage/coverage.json
```

Resolve the actual output path reported by the tool; relative property paths can be project-relative. The driver supports threshold types and assembly/type filters. Those filters cannot represent arbitrary mixed-method scope. If native scope exactly matches the inventory, a 100 threshold on line and branch can enforce it; otherwise evaluate detailed report data. Check shell escaping and threshold aggregation against the installed release. [MSBuild documentation](https://github.com/coverlet-coverage/coverlet/blob/master/Documentation/MSBuildIntegration.md)

Prefer a configuration file or verified argument handling over a long, shell-sensitive expression. Never assume `/p:Threshold=100` means only the two desired metrics.

## Verify evidence

Check test count, zero unexpected skips, exit status, source/build identity, included production assemblies and nonempty report. Inspect one known covered branch and one known gap when first setting up the pipeline. Diagnose missing modules/PDBs before treating absence as no eligible code. Avoid concurrent instrumentation of the same binaries.

If MTP is present and the installed Coverlet release lacks a supported driver, retain that limitation. Do not silently switch the project's runner or pretend the VSTest collector worked.
